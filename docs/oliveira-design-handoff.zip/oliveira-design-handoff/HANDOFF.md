# Oliveira Platform — Design handoff for Claude Code (v1.1)

Status: **design approved, ready for implementation.** Source of truth: the canvas "Oliveira — Design System".
This file and its siblings (`oliveira-tokens.css`, `oliveira-components.css`, `brand/*.svg`) are exported from that canvas.

> Scope of this handoff: **visual design and UX behaviour only.**
> Business rules — member administration, product access, seats, company settings, how Oliveira ERP access
> profiles are assigned — are defined in the project's **ADRs, specifications and backend**. Read them first;
> where a screen here and an ADR disagree about behaviour, the ADR wins and the design adapts.
> The new frontend is built from these prototypes; existing functionality, integrations and the backend are preserved (see ★ below).

---

## ★ Priority of the new design — read first

1. **Build the new frontend from the approved prototypes and this Design System.** The goal is not to patch a few
   screens of the current frontend: the canvas (boards 01–07, screens S01–S17 and M01–M05) is the reference for
   every visual and UX decision.
2. **Analyse the existing frontend first** to inventory what must be preserved: features, integrations, data
   flows, state management, existing components with behaviour (e.g. the Toast), tests and routes.
3. **When old and new differ only visually or in UX, the new design wins.**
4. **Preserve** the current architecture, backend, business rules, API contracts, authentication and authorization.
5. **Backend changes** only when truly required by the new frontend: identify, justify and plan each one before
   implementing, and avoid unnecessary ones.
6. **Before implementing administration, access or permission features, read the ADRs and specifications.** If a
   screen and an ADR disagree about behaviour, the ADR wins and the UI adapts.

---

## 0. How to use the canvas

| Board | Content |
|---|---|
| 01 · Identity | Brand architecture, official decisions, colour roles, shell anatomy |
| 02 · Typography | Archivo + JetBrains Mono, scale, rules |
| 03 · Design tokens | Colour, spacing, sizing, radius, focus, elevation, motion, **themes** |
| 04 · Components | Buttons, forms, tables, badges/tags, alerts, **toasts**, stats — every state |
| 04b · Patterns | Navigation, tabs, cards, overlays, data formats, responsive, a11y, product differences, validation, open rules |
| 05 · Internationalization | EN default, pt-BR, glossary, formats, layout rules |
| 06 · Logo & mark | Crest, compact crest, tree tile, sizes, lockups, files |
| 07 · Handoff | This summary, visually |
| S01–S17, M01–M05 | Screens (desktop 1440 × 900, mobile 390 × 844) |

Implementation order suggested: analyse existing frontend + ADRs → tokens → fonts → shell (global bar, sidebar) → buttons/forms/tags → alerts + toast restyle → tables/pagination → Platform screens (auth, Home, no access, company admin) → Oliveira ERP screens → FSM placeholder → responsive/mobile → i18n + a11y QA.

---

## 1. Identity

- **Brand architecture:** "Oliveira" + crest never change; product name and accent change.
  - Oliveira Platform — identity, company, members, product access. Navy `#1E2C47` + gold `#C8AE72`.
  - Oliveira ERP — existing product, keeps olive `#4F6B3A`; migrates its dark-green shell to the shared shell.
  - Oliveira FSM — future product, terracotta `#A4502B`; placeholder only, no features.
- **Carmine `#7D2331`** belongs to the logo only. Never an error or state colour.
- **Product names are proper nouns, always English**, never in translation files: Oliveira Platform, Oliveira ERP, Oliveira FSM.
- **Logo** (`brand/`):
  | Use | File | Size |
  |---|---|---|
  | Global bar, sidebar, mobile bar/drawer (dark shell) | `oliveira-mark-dark.svg` | 26–28px high |
  | Light surfaces (product switcher, drawers, dialogs, email) | `oliveira-mark-light.svg` | 24–32px |
  | Favicon | `favicon.svg` → export 16/32 PNG + `.ico` | 16/32 |
  | Apple touch / PWA | `app-icon.svg` → 180, 192, 512 PNG | — |
  | Institutional, ≥ 96px | `oliveira-crest-{light,dark}.svg` or the original raster | ≥ 64 |
  | One colour | `oliveira-mark-mono.svg` (currentColor) | ≥ 24 |
  Auth brand panel keeps the original raster artwork. Minimum sizes: compact crest 24px, crest 64px, tile 16px. Clear space = ½ crest height. Never recolour the crest with product accents.

## 2. Tokens

Use `oliveira-tokens.css` as the source. Key rules:
- Components consume **semantic** tokens (`--olv-bg`, `--olv-surface`, `--olv-text*`, `--olv-border*`, tone tokens, `--olv-accent-*`), never palette values.
- `[data-product="platform|erp|fsm"]` on the product root sets `--olv-accent-{600,700,800,300,100,50}` and disabled tints. That is the only per-product difference.
- Product **access** UI (access badges, access switches) always uses the Platform scope.
- **Themes:** light is the only official theme (`data-theme="light"`). Dark mode is reserved: semantic layer ready, not designed, not enabled, no toggle.

## 3. Typography

- Archivo (variable, wght 400–600, wdth 88–118) for everything; JetBrains Mono for codes, IDs, CPF/CNPJ, dates, overlines, badges, kbd.
- Display (Archivo 600, `font-stretch: 118%`) only in Oliveira Platform: sign in / create account panel headline and Home greeting.
- Scale: display 38/42 · title-l 32/38 · h1 28/34 · h2 18/24 · h3 16/22 · body-l 16/24 · body 14/21 · label 13/18 · caption 12.5/18 · overline mono 11/14 +0.12em uppercase · data mono 13/18.
- Weights 400/500/600 only. Sentence case everywhere; uppercase only via CSS. Tabular figures in numeric columns and stats.
- `wdth 88` allowed only in table headers, sidebar labels and badges when pt-BR overflows.
- Self-host variable woff2, `font-display: swap`.

## 4. Components (see board 04; reference CSS in `oliveira-components.css`)

| Component | Variants | States | Notes |
|---|---|---|---|
| Button | primary, secondary, ghost (tertiary), link, destructive, destructive-soft, icon, shell | default, hover (600→700), focus (2px surface gap + 2px ring), pressed (translateY 1px + inset), disabled (accent tint, not grey), loading (label hidden, centred spinner, same width, `aria-busy`) | sizes sm 32 / md 36 / lg 44. One primary per region, rightmost. **Cancel is ghost** in footers, drawers and dialogs. Filled destructive only inside a confirmation. |
| Text input | default, lead icon, trail action, mono | hover, focus (navy + 3px ring), filled, error (`aria-invalid`, message with icon replaces help), disabled, read-only | 40px (44 on auth and mobile). Label above; "(optional)" on optional fields. |
| Search | lead icon, 36px in toolbars | — | Filters open from a secondary sm button; active filters are removable tags. |
| Select | native select styled as input + chevron | open list = menu surface, 38px options, check on selected | Browser-drawn popup not specified. |
| Password | lock lead icon + eye / eye-off icon button | `aria-pressed` on toggle | "Forgot password?" link in the label row. |
| Checkbox | — | checked, hover, focus, disabled | Multi-select, permission matrix, consent. |
| Switch | `input[type=checkbox][role=switch]` | on, off, hover, focus, disabled | On/off settings, product access. Saved with the form's Save. |
| Radio card | — | selected (accent border + tint) | One of a few described options (member role). |
| Status badge | success, warning, danger, info, neutral | — | Mono uppercase, dot + text, radius 4. States only. |
| Access badge | granted, none (lock), soon | — | Platform-owned colours only. |
| Tag | role Admin (navy tint + shield-check), Member (neutral + person), type (Client/Supplier), filter (removable) | — | Archivo, sentence case, pill. Categories only. |
| Tabs | underline in accent; count pill | selected, hover pill, focus ring, unavailable | Scroll horizontally on narrow screens; never wrap. |
| Segmented control | light, dark | pressed | Language switch on auth and in the account menu/drawer. |
| Table | row 48 (58 with avatar), header 40 | hover `--olv-surface-hover`, selected `--olv-accent-50` | Sortable headers = ghost sm buttons. Codes/docs/dates mono; amounts right + tabular; empty = "—". |
| Pagination | summary · rows per page · prev / pages / … / last / next | current page accent tint | Single page: no ellipsis, next disabled. |
| Card | informational, clickable (whole card is the link), product card | clickable hover: border + elev-hover + lift 2px + arrow moves 3px | No buttons inside clickable cards. |
| Product card | access (link) · no access · coming soon | disabled = `button[aria-disabled=true]`, greyscale art, lock badge; tooltip on hover (hover-capable devices only); inline message on tap / keyboard focus | Art: ERP = ledger of records; FSM = route with stops. |
| Alert | danger, success, warning, info | optional action (secondary sm or link) | In-page, stays while the situation lasts. Tinted fill + tone border. `role="alert"` for errors, `role="status"` otherwise. |
| Toast | success, info, warning, danger | entering, visible (timer), hover/focus paused, leaving, error (no timer) | **The existing frontend Toast, restyled** — see § 4a. Not replaced by Alert. |
| Tooltip | dark, 13px, arrow | 200ms delay on hover | Needs a tap alternative on touch. |
| Drawer | 480px right | — | Header + close, scroll body, footer: destructive-soft left, ghost Cancel + primary right. |
| Modal | 520px, radius 12 | — | Focus trap, Esc closes. Scrim 48%. |

## 4a. Toast — restyle of the existing component (board 04 § 05)

The frontend already has a Toast with its own behaviour. **Keep the component, its API, queue, types and triggers; replace only its visual layer.** Alert and Toast coexist:

| | Alert | Toast |
|---|---|---|
| Where | inside the page, form or panel | floating, outside the layout |
| Lifetime | while the situation lasts | temporary (errors stay until dismissed) |
| Examples | form errors, info about permissions, pending invitation | "Changes saved", "Invitation sent", background failure, undo |
| Look | tinted fill + tone border | white elevated card, tone chip, dismiss, timer bar |

Visual spec: width 380px (mobile: full width − 32px) · surface white, 1px `--olv-border`, radius 10, `--olv-elev-menu` · tone chip 28px radius 8 with the Alert icon in tone-600 on tone-50 · title 14/600 · optional message 13 `--olv-text-3` · at most one link action · Dismiss ghost icon button (28px, `aria-label`) · 2px timer bar in tone-600 at 55% that shrinks while visible.

Behaviour (apply where the existing component supports it or it is compatible):
- Types: success, info, warning, danger only (Alert tones and icons). No product-coloured toasts.
- Durations: **keep existing timings**; if undefined: success/info 5s, warning 7s, with action ≥ 8s; danger has no timer.
- Timer pauses on hover, keyboard focus and hidden window. Esc dismisses the focused toast.
- Position: desktop/tablet bottom-right, 24px from edges, above content and below modals, newest nearest the edge, max 3 visible (queue the rest, collapse duplicates). Mobile: bottom, full width minus 16px, above the safe area, one at a time.
- Motion: enter 200ms (rise 8px + fade), leave 160ms (slide 16px + fade); reduced motion = fade only.
- Accessibility: one persistent live region (`role="region" aria-label="Notifications"`); success/info/warning polite (`role="status"`), danger assertive (`role="alert"`); never move focus; anything important in a toast is also reachable elsewhere.
- Text from the i18n catalogue; product names in English.
- Tokens: `--olv-toast-*` in `oliveira-tokens.css`; reference CSS `.olv-toast*` in `oliveira-components.css`.

## 5. Navigation

- **Global bar** (Platform-owned, identical in every product, 52px / 56 mobile): compact crest + "Oliveira", product switcher (product name in its 300 accent; menu lists every product with its access state), global search (Ctrl Shift F), company switcher, account menu (language lives here).
- **Sidebar** (product-owned, 232px): mono overlines, 38px items; active = shell-active fill + 3px accent marker + accent icon + `aria-current="page"`. Items without View permission are hidden; direct links show the in-product "You can't view …" page.
- **Breadcrumbs** at the top of the page, product first, no repeated segments (fixes the current ERP "Records › People › Records › People").
- **Page header:** breadcrumbs, H1, mono meta line, actions right (destructive-soft · secondary · primary).

## 6. Responsive

| Width | Shell | Content |
|---|---|---|
| ≥ 1280 | global bar full, sidebar 232 | gutter 48, all table columns |
| 1024–1279 | sidebar → 64px icon rail with tooltips | gutter 32, low-priority columns via Customize |
| 768–1023 | sidebar → drawer, search → icon | gutter 32, drawers → full-height sheets |
| < 768 | bar 56: menu · crest · product · search · account; drawer 320 with company, products, nav, language | gutter 16, tables → card lists, tabs scroll, controls 44, product cards stack, tooltips → tap messages, auth hides brand panel |

## 7. Internationalization (board 05)

- `en` default and fallback; `pt-BR` alternative; one interface, no separate layouts. Reserve up to +35% text length.
- Keys by domain (`auth.signIn.title`), ICU plurals, named variables, never concatenated sentences.
- Product/brand names never translated. Glossary: Home/Início · Company/Empresa · Members/Membros · Product access/Acesso ao produto · Permissions/Permissões · Access profile/Perfil de acesso · Person/Pessoa · Sign in/Entrar · Create account/Criar conta.
- Language ≠ data: currency comes from the company, document format from the data's country, time zone from the user. Format with `Intl` by UI language.
- First visit: browser language, fallback English; saved on the user profile; switch on auth screens and in the account menu. Root `lang` follows the UI.
- QA: add a pseudo-locale (+40%, accented) to the E2E suite.

## 8. Accessibility

WCAG 2.2 AA: text ≥ 4.5:1 (3:1 from 24px); input/checkbox borders ≥ 3:1; gold never as text on white. Visible focus on every control (navy ring on light, gold on shell). Never colour alone (status, access, roles, errors carry text/icon). Real elements: `button`, `a`, `input` + `label`, `role="switch"`, `tablist/tab`, dialogs with `aria-modal` + labelled title. Disabled product cards stay focusable and explain why. `prefers-reduced-motion` respected. 44px targets on touch.

## 9. Screens and behaviour

| ID | Screen | Product | Behaviour to implement |
|---|---|---|---|
| S01 | Sign in | Platform | Language segmented control (EN/PT, persists). Validation only after submit, then live. Loading keeps button width. Wrong credentials → generic danger alert. "Forgot password?" and "Create an account" links. |
| S02 | Create account | Platform | Name, work email, password (live rules: 8+ chars, letters and numbers — confirm against backend policy), terms consent. States: validation, email already in use (link to Sign in), loading, created → "create or join a company" (no product access granted). |
| S03–S06 | Home | Platform | Greeting (display type). Product cards reflect **product access**: access → whole card links to the product; no access → visible, disabled, tooltip / tap message, never opens; FSM → coming soon. Admins also see the compact company strip (members, pending invitations, ERP access) linking to Company admin. No company → create company / join by invitation. |
| S07–S08 | No access | Platform (on a product URL) | Global bar only, no product sidebar. Explains that account and membership are fine but the product is not enabled; lists company admins; Back to Home, Switch company. |
| S09 | No permission | inside Oliveira ERP | Product shell. Explains the missing View permission from the ERP access profile; link back; note that this differs from product access. |
| S10 | Members | Platform admin | Search, role/status filters, table (member, role tag, status, per-product access badge, joined), row actions, Invite member. |
| S11 | Member details | Platform admin | Drawer: role (radio cards), product access switches (ERP; FSM disabled/coming soon), link to manage permissions inside Oliveira ERP, remove member (destructive-soft → confirmation), Cancel / Save changes. |
| S12 | Invite member | Platform admin | Modal: email, role, product access switches (none selected by default) + info alert, Send invitation. |
| S13 | Product access | Platform admin | Explains access vs permissions; tabs per product; switch per member; unsaved-change indicator; Discard / Save changes. |
| S14 | People | Oliveira ERP | Tabs All/Clients/Suppliers with counts, search + filters + removable filter tags, ghost tools, table with selection, header actions (Delete soft, Edit, Add person), pagination. |
| S15 | New person | Oliveira ERP | Tabs for sections, section layout (title left, fields right), error summary alert + inline CNPJ error, ghost Cancel + Save person. |
| S16 | Access profile | Oliveira ERP | Code (read-only), name, status switch; permission matrix View/Create/Edit/Delete by screen; info alert pointing to Platform product access. |
| S17 | Oliveira FSM | FSM | Coming soon placeholder; no modules; back to Platform. |
| M01–M05 | Mobile | — | Sign in, Home, drawer menu, People as cards, no-access tap message. |

## 9a. Screen → route mapping (proposed)

Routes are **proposals**. Read the current router first: keep existing URLs where they exist (especially Oliveira ERP), and map these screens onto them.

| Screen | Proposed route | Notes |
|---|---|---|
| S01 Sign in | `/sign-in` | redirect to Home after sign-in |
| S02 Create account | `/sign-up` | then Home (no company state) |
| S03–S06 Home | `/` | state depends on company membership, role and product access |
| S07–S08 No access | rendered at the product URL (e.g. `/erp/...`) | a guard state, not its own route; global bar only |
| S09 No permission | rendered at the denied ERP URL | product shell + message |
| — Company (settings) | `/company` | content defined by ADRs/specs — not designed |
| S10 Members | `/company/members` | |
| S11 Member details | `/company/members/:memberId` | drawer over the list; deep-linkable |
| S12 Invite member | `/company/members` + modal state (`?invite=1` optional) | |
| S13 Product access | `/company/product-access/:product?` | default tab = first product |
| S14 People | `/erp/people` | tabs as query (`?type=client`) |
| S15 New person | `/erp/people/new` | edit likely `/erp/people/:id` |
| S16 Access profile | `/erp/access-profiles/:id` | list screen not designed; reuse table pattern |
| S17 Oliveira FSM | `/fsm` | placeholder |
| M01–M05 | same routes | responsive states of the screens above |

## 10. Platform · ERP · FSM differences

| | Platform | ERP | FSM |
|---|---|---|---|
| Accent (light / on dark) | `#1E2C47` / `#C8AE72` | `#4F6B3A` / `#A3BE85` | `#A4502B` / `#E39A70` |
| Uses accent for | primary button, active nav marker, product name in shell, tabs, selected rows, tints | same | same |
| Voice | institutional (display type on auth, Home) | operational, dense, table-first | open |
| Owns | identity, company, members, product access, global bar | records, people, access profiles | placeholder |

## 11. Pending during implementation

1. **Read the ADRs, specs and backend** for member administration, product access, seats, company settings and ERP access-profile assignment; wire the screens to those rules without inventing new behaviour.
2. Inventory the existing frontend (features, integrations, components with behaviour — especially the Toast, routes, tests) and map it to this system; replace hex with tokens. Restyle the Toast, don't replace it.
3. Fonts: self-host Archivo (variable, wdth + wght) and JetBrains Mono; verify real glyph widths (prototypes were checked with a fallback font).
4. Export favicon PNG/ICO and app icons from `brand/*.svg`; replace the cropped raster mark everywhere.
5. Password policy copy on Create account must match the backend.
6. Save model for access changes follows the ADRs (screens show an explicit Save).
7. Native select popup, Windows high-contrast mode, real touch devices and screen-reader order were not validated in design.
8. Not designed on purpose: dark theme, page transitions, charts palette, FSM features, company settings content, access-profile list screen.
9. Confirm proposed routes (§ 9a) against the current router.
10. Compare the existing Toast's durations, queue and positioning with § 4a and keep what is compatible.
11. Any backend change must be identified, justified and planned first.

## 12. Files and where they are

All files live **inside the canvas artifact** under `project/handoff/` (open them from board 07 or read them with the artifact tools) and are also delivered as **`oliveira-design-handoff.zip`** in the Claude conversation.

| File | Purpose |
|---|---|
| `HANDOFF.md` | this spec |
| `oliveira-tokens.css` | all tokens: palette, semantic light theme, reserved dark theme, product scopes, type, spacing, sizing, radius, elevation, motion, toast |
| `oliveira-components.css` | exact prototype CSS for every component and state (hex values — map to tokens) |
| `brand/oliveira-crest-light.svg`, `brand/oliveira-crest-dark.svg` | full crest |
| `brand/oliveira-mark-light.svg`, `brand/oliveira-mark-dark.svg`, `brand/oliveira-mark-mono.svg` | compact crest |
| `brand/favicon.svg`, `brand/app-icon.svg` | favicon and app icon sources |
| `brand/oliveira-logo-original.jpg` | official logo artwork (raster) |
| zip only: `screens/*.png` | rendered captures of every board and screen (fallback fonts — see limitations) |
| zip only: `canvas-source/` | the canvas source files (`*.dc.html`, `canvas.json`) for reference |

Limitations of the canvas as a source:
- The `.dc.html` prototypes run in the Claude Design runtime; they are **references, not production code**. Rebuild them with the project's stack.
- The original raster logo is included as `brand/oliveira-logo-original.jpg` (1408 × 768, dark ground) for the auth panel and institutional uses; it has no transparent background.
- Screens were verified in a local render with fallback fonts (Archivo/JetBrains Mono could not be downloaded there).
