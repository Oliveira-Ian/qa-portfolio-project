# Oliveira — design handoff package (v1.1)

Exported from the Claude Design canvas "Oliveira — Design System" (the visual source of truth).

- `HANDOFF.md` — start here (priority of the new design, specs, routes, pending items)
- `oliveira-tokens.css` — design tokens (CSS custom properties)
- `oliveira-components.css` — reference CSS of every prototyped component and state
- `brand/` — crest, compact crest, favicon, app icon (SVG) and the original logo (JPG)
- `screens/` — captures of all 30 boards and screens (rendered with fallback fonts; Archivo/JetBrains Mono were unavailable in the render environment)
- `canvas-source/` — the canvas source (`*.dc.html` prototypes + `canvas.json`); reference only, they need the Claude Design runtime
