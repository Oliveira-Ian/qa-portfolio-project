// Oliveira FSM — visual redesign (round 2). Sidebar (F01) and top bar stay as approved.
import fs from 'node:fs';
import { I, ICONS, navExpanded, board, HEADER, SCRATCH } from './lib.mjs';

Object.assign(ICONS, {
  idCard: '<path d="M16 10h2"></path><path d="M16 14h2"></path><path d="M6.17 15a3 3 0 0 1 5.66 0"></path><circle cx="9" cy="11" r="2"></circle><rect x="2" y="5" width="20" height="14" rx="2"></rect>',
  trendUp: '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline><polyline points="16 7 22 7 22 13"></polyline>',
  zap: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path>',
  file: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path>',
  map: '<path d="M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z"></path><path d="M15 5.764v15"></path><path d="M9 3.236v15"></path>',
  mail: '<rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>',
  external: '<path d="M15 3h6v6"></path><path d="M10 14 21 3"></path><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>',
  chevUp: '<path d="m18 15-6-6-6 6"></path>',
  chevsUp: '<path d="m17 11-5-5-5 5"></path><path d="m17 18-5-5-5 5"></path>',
  minus: '<path d="M5 12h14"></path>',
  lock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>',
  save: '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"></path><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"></path><path d="M7 3v4a1 1 0 0 0 1 1h7"></path>',
  sparkles: '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"></path>',
  gauge: '<path d="m12 14 4-4"></path><path d="M3.34 19a10 10 0 1 1 17.32 0"></path>',
  hourglass: '<path d="M5 22h14"></path><path d="M5 2h14"></path><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"></path><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"></path>',
});

const CSS = `
.fx{--bg:#F2F4F7;--sf:#FFFFFF;--sf2:#F8F9FB;--sfh:#F5F7FA;--bd:#E3E6EB;--bd2:#CDD2DA;--bdi:#8A92A0;--t1:#111827;--t2:#384152;--t3:#5B6474;--t4:#8A92A0;--acc:#A4502B;--acc7:#8A4221;--acc5:#FBF1EB;--acc1:#F5DCCD;--acc3:#E39A70;color:#111827}
.fx-page{flex-grow:1;min-width:0;padding:24px 32px 32px;display:flex;flex-direction:column;gap:20px;overflow:hidden;box-sizing:border-box;background:var(--bg)}
.fx-h1{font-size:24px;line-height:32px;font-weight:600;letter-spacing:-0.015em;margin:0;color:var(--t1)}
.fx-h2{font-size:16px;line-height:24px;font-weight:600;margin:0;color:var(--t1)}
.fx-h3{font-size:14px;line-height:20px;font-weight:600;margin:0;color:var(--t1)}
.fx-sub{font-size:13.5px;line-height:20px;color:var(--t3);margin:0}
.fx-small{font-size:12.5px;line-height:18px;color:var(--t3)}
.fx-over{font-size:11px;line-height:16px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--t3)}
.fx-id{font-family:'JetBrains Mono',ui-monospace,monospace;font-size:12.5px;color:var(--t3);font-weight:500}
.fx-num{font-variant-numeric:tabular-nums}
.fx-card{background:var(--sf);border:1px solid var(--bd);border-radius:12px;box-shadow:0 1px 2px rgba(16,24,40,.04);box-sizing:border-box;min-width:0}
.fx-cardh{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 20px}
.fx-cardb{padding:0 20px 20px}
.fx-tile{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:var(--acc5);color:var(--acc);flex-shrink:0}
.fx-tile--slate{background:#EEF0F3;color:#384152}
.fx-tile--lg{width:48px;height:48px;border-radius:12px}
.fx-crumbs{list-style:none;margin:0;padding:0;display:flex;align-items:center;gap:6px;font-size:13px;color:var(--t3)}
.fx-crumbs li{display:flex;align-items:center;gap:6px}
.fx-crumbs a{color:var(--t3);text-decoration:none}
.fx-crumbs [aria-current]{color:var(--t1);font-weight:500}
.fx-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;height:36px;padding:0 14px;border-radius:8px;border:1px solid var(--bd2);background:#FFFFFF;color:var(--t1);font-family:inherit;font-size:14px;font-weight:500;white-space:nowrap;cursor:pointer;box-shadow:0 1px 2px rgba(16,24,40,.05);text-decoration:none;box-sizing:border-box;flex-shrink:0}
.fx-btn:hover,.fx-btn.is-hover{background:var(--sfh);border-color:#B9BFC9}
.fx-btn--confirm{background:var(--acc);border-color:var(--acc);color:#FFFFFF;box-shadow:0 1px 2px rgba(16,24,40,.12),inset 0 1px 0 rgba(255,255,255,.14)}
.fx-btn--confirm:hover,.fx-btn--confirm.is-hover{background:var(--acc7);border-color:var(--acc7)}
.fx-btn--create{color:#0F6B4A;border-color:#9FD6C0}
.fx-btn--create:hover,.fx-btn--create.is-hover{background:#F0FAF5;border-color:#6CC3A0}
.fx-btn--edit{color:#7A4E0C;border-color:#E3C48C}
.fx-btn--edit:hover,.fx-btn--edit.is-hover{background:#FDF7EC;border-color:#D4A85A}
.fx-btn--danger{color:#B42318;border-color:#F0B9B3}
.fx-btn--danger:hover,.fx-btn--danger.is-hover{background:#FEF3F2;border-color:#E58A80}
.fx-btn--ghost{background:transparent;border-color:transparent;box-shadow:none;color:var(--t2)}
.fx-btn--ghost:hover,.fx-btn--ghost.is-hover{background:#EAEDF1;border-color:transparent}
.fx-btn--sm{height:32px;padding:0 10px;font-size:13px;border-radius:7px;gap:6px}
.fx-btn--lg{height:44px;padding:0 18px;font-size:15px}
.fx-btn--icon{width:36px;padding:0}
.fx-btn--sm.fx-btn--icon{width:32px}
.fx-btn.is-focus{box-shadow:0 0 0 2px #FFFFFF,0 0 0 4px var(--acc)}
.fx-btn:disabled,.fx-btn.is-disabled{opacity:.45;cursor:not-allowed}
.fx-pill{display:inline-flex;align-items:center;gap:6px;height:24px;padding:0 10px 0 8px;border-radius:999px;font-size:12.5px;font-weight:500;white-space:nowrap;box-sizing:border-box}
.fx-pill i{width:7px;height:7px;border-radius:50%;display:block;flex-shrink:0}
.p-open{background:#F1F3F6;color:#384152}.p-open i{background:#8A92A0}
.p-sched{background:#EAF2FC;color:#1C4F95}.p-sched i{background:#2A78D6}
.p-prog{background:#FDF3DC;color:#6E4A00}.p-prog i{background:#EDA100}
.p-hold{background:#F0EEFB;color:#4636B0}.p-hold i{background:#6250D6}
.p-done{background:#E5F5EE;color:#0F6B4A}.p-done i{background:#1BAF7A}
.p-cancel{background:#F1F3F6;color:#5B6474}.p-cancel i{background:#C3C8D0}
.p-active{background:#E5F5EE;color:#0F6B4A}.p-active i{background:#1BAF7A}
.p-crit{background:#FEECEB;color:#B42318}.p-crit i{background:#D03B3B}
.p-warn{background:#FDF3DC;color:#6E4A00}.p-warn i{background:#EDA100}
.fx-prio{display:inline-flex;align-items:center;gap:5px;font-size:13px;color:var(--t2);white-space:nowrap}
.fx-chip{display:inline-flex;align-items:center;gap:6px;height:26px;padding:0 9px;border-radius:7px;background:#F1F3F6;color:var(--t2);font-size:12.5px;font-weight:500;white-space:nowrap;box-sizing:border-box}
.fx-tabs{display:flex;gap:2px;border-bottom:1px solid var(--bd)}
.fx-tab{position:relative;display:inline-flex;align-items:center;gap:8px;height:46px;padding:0 14px;border:none;background:none;font-family:inherit;font-size:14px;font-weight:500;color:var(--t3);cursor:pointer;border-radius:8px 8px 0 0;white-space:nowrap}
.fx-tab svg{color:var(--t4)}
.fx-tab:hover,.fx-tab.is-hover{color:var(--t1);background:var(--sfh)}
.fx-tab[aria-selected=true]{color:var(--t1);font-weight:600}
.fx-tab[aria-selected=true] svg{color:var(--acc)}
.fx-tab[aria-selected=true]::after{content:"";position:absolute;left:12px;right:12px;bottom:-1px;height:2px;border-radius:2px 2px 0 0;background:var(--acc)}
.fx-tab.is-focus{box-shadow:inset 0 0 0 2px var(--acc)}
.fx-tab[aria-disabled=true]{color:#A7AEB9;cursor:not-allowed;background:none}
.fx-tab[aria-disabled=true] svg{color:#C3C8D0}
.fx-count{font-size:11.5px;font-weight:600;min-width:20px;height:20px;padding:0 6px;border-radius:999px;background:#EEF0F3;color:var(--t3);display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;font-variant-numeric:tabular-nums}
.fx-tab[aria-selected=true] .fx-count{background:var(--acc5);color:var(--acc7)}
.fx-count--err{background:#FEE4E2 !important;color:#B42318 !important}
.fx-seg{display:inline-flex;gap:2px;padding:3px;background:#E7EAEE;border-radius:10px;box-sizing:border-box}
.fx-seg button{display:inline-flex;align-items:center;gap:7px;height:30px;padding:0 12px;border:none;border-radius:7px;background:transparent;font-family:inherit;font-size:13px;font-weight:500;color:var(--t3);cursor:pointer;white-space:nowrap}
.fx-seg button:hover,.fx-seg button.is-hover{color:var(--t1);background:rgba(255,255,255,.5)}
.fx-seg button[aria-pressed=true]{background:#FFFFFF;color:var(--t1);font-weight:600;box-shadow:0 1px 2px rgba(16,24,40,.1),0 0 0 1px rgba(16,24,40,.04)}
.fx-seg button.is-focus{box-shadow:0 0 0 2px var(--acc)}
.fx-seg button:disabled{color:#A7AEB9;cursor:not-allowed}
.fx-seg .fx-count{height:18px;min-width:18px;font-size:11px;background:rgba(17,24,39,.06)}
.fx-filt{display:inline-flex;align-items:center;gap:8px;height:32px;padding:0 10px 0 9px;border-radius:999px;border:1px solid var(--bd2);background:#FFFFFF;font-family:inherit;font-size:13px;font-weight:500;color:var(--t2);cursor:pointer;white-space:nowrap;box-sizing:border-box}
.fx-filt i{width:8px;height:8px;border-radius:50%;display:block}
.fx-filt[aria-pressed=true]{border-color:var(--t1);background:#111827;color:#FFFFFF}
.fx-filt[aria-pressed=true] .fx-count{background:rgba(255,255,255,.18);color:#FFFFFF}
.fx-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:18px 20px}
.c2{grid-column:span 2}.c3{grid-column:span 3}.c4{grid-column:span 4}.c5{grid-column:span 5}.c6{grid-column:span 6}.c7{grid-column:span 7}.c8{grid-column:span 8}.c9{grid-column:span 9}.c12{grid-column:span 12}
.fx-f{display:flex;flex-direction:column;gap:6px;min-width:0}
.fx-l{font-size:13px;font-weight:500;color:var(--t2);display:flex;align-items:center;gap:5px;line-height:18px}
.fx-l svg{color:var(--t4)}
.fx-req{color:#B42318;font-weight:600}
.fx-in{height:40px;width:100%;box-sizing:border-box;border:1px solid var(--bdi);border-radius:8px;background:#FFFFFF;padding:0 12px;font-family:inherit;font-size:14px;color:var(--t1);display:flex;align-items:center;gap:8px;box-shadow:0 1px 2px rgba(16,24,40,.04);outline:none;min-width:0}
.fx-in::placeholder{color:var(--t4)}
.fx-in.is-hover{border-color:#5B6474}
.fx-in.is-focus{border-color:var(--acc);box-shadow:0 0 0 3px rgba(164,80,43,.18)}
.fx-in.is-error,.fx-in[aria-invalid=true]{border-color:#D92D20;box-shadow:0 0 0 3px rgba(217,45,32,.12)}
.fx-in:disabled,.fx-in.is-disabled{background:#F1F3F6;border-color:#DDE1E7;color:var(--t4);box-shadow:none}
.fx-in .ph{color:var(--t4)}
.fx-in .chev{margin-left:auto;color:var(--t3);display:flex}
.fx-ta{height:auto;min-height:88px;padding:10px 12px;align-items:flex-start;line-height:21px;resize:none}
.fx-ro{min-height:40px;display:flex;align-items:center;gap:8px;font-size:14.5px;font-weight:500;color:var(--t1);border-bottom:1px solid var(--bd);box-sizing:border-box;padding:0 0 2px;min-width:0}
.fx-ro.is-empty{color:var(--t4);font-weight:400}
.fx-ro.is-multi{align-items:flex-start;padding:9px 0 10px;line-height:21px;font-weight:400}
.fx-sec{background:var(--sf);border:1px solid var(--bd);border-radius:12px;box-shadow:0 1px 2px rgba(16,24,40,.04)}
.fx-sech{display:flex;align-items:flex-start;gap:12px;padding:18px 22px 4px}
.fx-secb{padding:16px 22px 22px}
.fx-new{display:inline-flex;align-items:center;height:20px;padding:0 7px;border-radius:999px;background:var(--acc5);color:var(--acc7);font-size:11px;font-weight:600;letter-spacing:.02em}
.fx-table{background:#FFFFFF;border:1px solid var(--bd);border-radius:12px;overflow:hidden;box-shadow:0 1px 2px rgba(16,24,40,.04)}
.fx-tr{display:grid;align-items:center;gap:16px;padding:0 16px;min-height:60px;border-bottom:1px solid #EEF0F3;font-size:14px;color:var(--t1);position:relative}
.fx-tr:last-child{border-bottom:none}
.fx-thead{min-height:40px;background:var(--sf2);font-size:12px;font-weight:600;color:var(--t3);border-bottom:1px solid var(--bd)}
.fx-th{display:flex;align-items:center;gap:4px;white-space:nowrap}
.fx-th svg{color:#A7AEB9}
.fx-tr.is-sel{background:#FDF6F2}
.fx-tr.is-sel::before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--acc)}
.fx-tr.is-hover{background:var(--sfh)}
.fx-cell{min-width:0;display:flex;flex-direction:column;gap:2px}
.fx-ell{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.fx-av{width:26px;height:26px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:10.5px;font-weight:600;flex-shrink:0;letter-spacing:.02em}
.fx-av--lg{width:36px;height:36px;font-size:12.5px}
.av1{background:#DCE9FA;color:#1C4F95}.av2{background:#F5DCCD;color:#71361B}.av3{background:#DDF3EA;color:#0F6B4A}.av4{background:#ECE9FB;color:#4636B0}.av0{background:#EEF0F3;color:#5B6474}
.fx-who{display:inline-flex;align-items:center;gap:8px;min-width:0;font-size:13.5px}
.fx-check{appearance:none;-webkit-appearance:none;width:16px;height:16px;border:1.5px solid var(--bdi);border-radius:4px;background:#FFFFFF;margin:0;display:inline-grid;place-content:center;flex-shrink:0}
.fx-check:checked{background:var(--acc);border-color:var(--acc)}
.fx-check:checked::after{content:"";width:8px;height:4px;border-left:2px solid #FFFFFF;border-bottom:2px solid #FFFFFF;transform:translateY(-1px) rotate(-45deg)}
.fx-stat{padding:18px 20px;display:flex;flex-direction:column;gap:6px;min-width:0;text-decoration:none;color:inherit}
.fx-stat__v{font-size:30px;line-height:36px;font-weight:600;letter-spacing:-0.02em;color:var(--t1);font-variant-numeric:tabular-nums}
.fx-stat__l{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:500;color:var(--t2)}
.fx-delta{display:inline-flex;align-items:center;gap:4px;font-size:12.5px;font-weight:600}
.fx-meter{height:6px;border-radius:999px;background:#EEF0F3;overflow:hidden;display:flex;gap:2px}
.fx-meter span{display:block;height:100%}
.fx-meter span:first-child{border-radius:999px 0 0 999px}
.fx-meter span:last-child{border-radius:0 999px 999px 0}
.fx-kv{display:grid;grid-template-columns:116px minmax(0,1fr);gap:12px 12px;font-size:13.5px;margin:0;line-height:20px}
.fx-kv dt{color:var(--t3)}
.fx-kv dd{margin:0;color:var(--t1);min-width:0}
.fx-facts{display:flex;border-top:1px solid var(--bd)}
.fx-fact{flex:1;padding:14px 22px;display:flex;flex-direction:column;gap:3px;min-width:0;border-right:1px solid var(--bd)}
.fx-fact:last-child{border-right:none}
.fx-fact b{font-size:15px;font-weight:600;color:var(--t1);font-variant-numeric:tabular-nums}
.fx-legend{display:flex;flex-wrap:wrap;gap:14px;font-size:12.5px;color:var(--t2)}
.fx-legend span{display:inline-flex;align-items:center;gap:6px}
.fx-legend i{width:10px;height:10px;border-radius:3px;display:block}
.fx-tip{position:absolute;background:#111827;color:#FFFFFF;border-radius:8px;padding:8px 10px;font-size:12px;line-height:17px;box-shadow:0 8px 24px rgba(16,24,40,.25);white-space:nowrap;z-index:2}
.fx-callout{display:flex;gap:12px;padding:14px 16px;border-radius:10px;background:#FBF1EB;border:1px solid #F5DCCD;font-size:13.5px;line-height:20px;color:var(--t1)}
.fx-callout b{display:block;font-size:12.5px;color:var(--acc7);margin-bottom:2px}
.fx-info{display:flex;gap:10px;padding:12px 14px;border-radius:10px;background:#EAF2FC;border:1px solid #CFE0F7;font-size:13px;line-height:19px;color:#1C3E6E}
.fx-hl{display:flex;flex-direction:column;gap:4px;padding:12px 14px;border-radius:10px;background:var(--sf2);border:1px solid #EEF0F3;min-width:0}
.fx-list a,.fx-row{display:grid;align-items:center;gap:12px;text-decoration:none;color:inherit}
.fx-divide > * + *{border-top:1px solid #EEF0F3}
.fx-steps{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
.fx-step{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;border:1px solid var(--bd);background:#FFFFFF;text-align:left;font-family:inherit;cursor:pointer;min-width:0;box-sizing:border-box}
.fx-step__n{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:600;border:1.5px solid var(--bd2);color:var(--t3);flex-shrink:0;box-sizing:border-box;background:#FFFFFF}
.fx-step.is-done .fx-step__n{background:#1BAF7A;border-color:#1BAF7A;color:#FFFFFF}
.fx-step.is-current{border-color:var(--acc);box-shadow:0 0 0 3px rgba(164,80,43,.12)}
.fx-step.is-current .fx-step__n{background:var(--acc);border-color:var(--acc);color:#FFFFFF}
.fx-step.is-todo{background:transparent;border-style:dashed}
.fx-prog{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));padding:16px 22px 18px;border-top:1px solid var(--bd);gap:0}
.fx-prog__i{display:flex;flex-direction:column;gap:6px;position:relative;padding-right:12px}
.fx-prog__bar{height:4px;border-radius:999px;background:#E3E6EB}
.fx-prog__i.is-done .fx-prog__bar{background:#1BAF7A}
.fx-prog__i.is-current .fx-prog__bar{background:linear-gradient(90deg,var(--acc) 55%,#E3E6EB 55%)}
.fx-prog__t{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:600;color:var(--t1)}
.fx-prog__i.is-todo .fx-prog__t{color:var(--t4);font-weight:500}
.fx-sticky{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 22px;background:#FFFFFF;border:1px solid var(--bd);border-radius:12px;box-shadow:0 -1px 0 rgba(16,24,40,.02),0 8px 24px rgba(16,24,40,.08)}
.fx-switch{width:36px;height:20px;border-radius:999px;background:var(--acc);position:relative;flex-shrink:0;display:inline-block}
.fx-switch::after{content:"";position:absolute;right:2px;top:2px;width:16px;height:16px;border-radius:50%;background:#FFFFFF;box-shadow:0 1px 2px rgba(16,24,40,.2)}
.fx-dash{border:1px dashed var(--bd2);border-radius:10px}
.fx-spec{font-size:13.5px;line-height:21px;color:var(--t2);margin:0;padding-left:18px}
.fx-spec li{margin-bottom:5px}
.fx-sw{display:flex;flex-direction:column;gap:6px;min-width:0}
.fx-sw__c{height:56px;border-radius:10px;box-shadow:inset 0 0 0 1px rgba(16,24,40,.08)}
.fx-cap{font-size:11px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--t3)}
.fx-mcard{background:#FFFFFF;border:1px solid var(--bd);border-radius:12px;padding:14px;display:flex;flex-direction:column;gap:10px;text-decoration:none;color:inherit;box-shadow:0 1px 2px rgba(16,24,40,.04)}
.fx-btn--confirm{background:#44C38A !important;border-color:#2FA56F !important;color:#053D27 !important;font-weight:600;box-shadow:0 1px 2px rgba(16,24,40,.10),inset 0 1px 0 rgba(255,255,255,.25)}
.fx-btn--confirm:hover,.fx-btn--confirm.is-hover{background:#36B27A !important;border-color:#25915F !important}
.fx-btn--confirm.is-focus{box-shadow:0 0 0 2px #FFFFFF,0 0 0 4px #1F8A5B !important}
.fx-tabs[data-fill]{display:flex}
.fx-tabs[data-fill] .fx-tab{flex:1 1 0;justify-content:center}

`;

// ---------------------------------------------------------------- tiny helpers
const made = [];
const B = (o) => made.push(board({ ...o, css: CSS, bg: '#F2F4F7' }));
const PILL = {
  OPEN: ['p-open', 'Open'], SCHEDULED: ['p-sched', 'Scheduled'], IN_PROGRESS: ['p-prog', 'In progress'],
  ON_HOLD: ['p-hold', 'On hold'], COMPLETED: ['p-done', 'Completed'], CANCELLED: ['p-cancel', 'Cancelled'],
};
const pill = (s) => `<span class="fx-pill ${PILL[s][0]}"><i></i>${PILL[s][1]}</span>`;
const tone = (cls, label) => `<span class="fx-pill ${cls}"><i></i>${label}</span>`;
const prio = (p) => {
  const m = {
    LOW: [I('chevRight', 14, 'transform: rotate(90deg); color: #A7AEB9'), 'Low', ''],
    NORMAL: [I('minus', 14, 'color: #8A92A0'), 'Normal', ''],
    HIGH: [I('chevUp', 14, 'color: #C4320A'), 'High', 'color: #93370D; font-weight: 600'],
    URGENT: [I('chevsUp', 14, 'color: #D03B3B'), 'Urgent', 'color: #B42318; font-weight: 600'],
  }[p];
  return `<span class="fx-prio" style="${m[2]}">${m[0]}${m[1]}</span>`;
};
const late = (txt) => `<span style="display: inline-flex; align-items: center; gap: 5px; color: #B42318; font-weight: 600; font-size: 12.5px">${I('alarm', 13)}${txt}</span>`;
const av = (i, c) => `<span class="fx-av ${c}">${i}</span>`;
const TECH = { JA: ['Juliana Alves', 'av1'], RS: ['Rafael Souza', 'av2'], BF: ['Bruno Ferreira', 'av3'], MC: ['Marina Costa', 'av4'] };
const who = (k) => (k ? `<span class="fx-who">${av(k, TECH[k][1])}<span class="fx-ell">${TECH[k][0]}</span></span>` : `<span class="fx-who" style="color: #8A92A0">${av('—', 'av0')}Unassigned</span>`);
const b = (variant, label, icon = null, extra = '') => `<button type="button" class="fx-btn ${variant}"${extra}>${icon ? I(icon, 16) : ''}${label ? `<span>${label}</span>` : ''}</button>`;
const crumbs = (list) =>
  `<nav aria-label="Breadcrumb"><ol class="fx-crumbs">${list.map((c, i) => (i === list.length - 1 ? `<li><span aria-current="page">${c}</span></li>` : `<li><a href="#">${c}</a>${I('chevRight', 14, 'color: #A7AEB9')}</li>`)).join('')}</ol></nav>`;
const tabs = (list, sel, extra = '') =>
  `<div role="tablist" class="fx-tabs"${extra}>${list.map(([label, icon, count, state], i) => `<button type="button" role="tab" class="fx-tab${state === 'hover' ? ' is-hover' : ''}${state === 'focus' ? ' is-focus' : ''}" aria-selected="${i === sel}"${state === 'disabled' ? ' aria-disabled="true"' : ''}>${icon ? I(icon, 16) : ''}${label}${count !== undefined && count !== null ? `<span class="fx-count${String(count).startsWith('!') ? ' fx-count--err' : ''}">${String(count).replace('!', '')}</span>` : ''}</button>`).join('')}</div>`;
const seg = (list, sel) => `<div class="fx-seg" role="group">${list.map(([l, c], i) => `<button type="button" aria-pressed="${i === sel}">${l}${c !== undefined ? `<span class="fx-count">${c}</span>` : ''}</button>`).join('')}</div>`;
const lbl = (t, { req = false, help = false, isNew = false } = {}) => `<span class="fx-l">${t}${req ? '<span class="fx-req" aria-hidden="true">*</span>' : ''}${help ? I('info', 14) : ''}${isNew ? '<span class="fx-new">New</span>' : ''}</span>`;
const inp = (label, value, o = {}) =>
  `<label class="fx-f ${o.c ?? 'c6'}">${lbl(label, o)}<span class="fx-in${o.state ? ' is-' + o.state : ''}${o.ta ? ' fx-ta' : ''}"${o.state === 'error' ? ' aria-invalid="true"' : ''}>${o.icon ? I(o.icon, 16, 'color: #5B6474') : ''}${value ? `<span class="${o.ta ? '' : 'fx-ell'}"${o.mono ? ' style="font-family: \'JetBrains Mono\', monospace; font-size: 13.5px"' : ''}>${value}</span>` : `<span class="ph">${o.ph ?? ''}</span>`}${o.select ? `<span class="chev">${I('chevDown', 16)}</span>` : ''}</span></label>`;
const ro = (label, value, o = {}) =>
  `<div class="fx-f ${o.c ?? 'c6'}">${lbl(label, o)}<div class="fx-ro${value ? '' : ' is-empty'}${o.multi ? ' is-multi' : ''}"${o.mono ? ' style="font-family: \'JetBrains Mono\', monospace; font-size: 13.5px"' : ''}>${value || '—'}</div></div>`;
const sec = (icon, title, desc, inner, { isNew = false, opt = false } = {}) =>
  `<section class="fx-sec"><div class="fx-sech"><span class="fx-tile">${I(icon, 17)}</span><div style="display: flex; flex-direction: column; gap: 2px; min-width: 0"><div style="display: flex; align-items: center; gap: 8px"><h2 class="fx-h2" style="font-size: 15px">${title}</h2>${opt ? '<span class="fx-small">Optional</span>' : ''}${isNew ? '<span class="fx-new">New fields</span>' : ''}</div><p class="fx-sub" style="font-size: 13px">${desc}</p></div></div><div class="fx-secb"><div class="fx-grid">${inner}</div></div></section>`;
const card = (title, sub, inner, { action = '', pad = true, style = '' } = {}) =>
  `<section class="fx-card" style="display: flex; flex-direction: column${style ? '; ' + style : ''}"><div class="fx-cardh"><div style="display: flex; flex-direction: column; gap: 2px; min-width: 0"><h2 class="fx-h2" style="font-size: 15px">${title}</h2>${sub ? `<span class="fx-small">${sub}</span>` : ''}</div>${action}</div><div${pad ? ' class="fx-cardb"' : ''}>${inner}</div></section>`;
const page = (nav, inner, h) =>
  `<div class="fx" style="width: 100%; height: ${h}px; display: flex; flex-direction: column; overflow: hidden">${HEADER}<div style="display: flex; flex-grow: 1; min-height: 0">${nav}<main class="fx-page">${inner}</main></div></div>`;
const linkS = (t) => `<span style="color: var(--acc); font-weight: 600; font-size: 13px; display: inline-flex; align-items: center; gap: 4px">${t}${I('chevRight', 14)}</span>`;
const linkA = (t) => `<a href="#" style="color: var(--acc); font-weight: 600; font-size: 13px; text-decoration: none; display: inline-flex; align-items: center; gap: 4px">${t}${I('chevRight', 14)}</a>`;

// ---------------------------------------------------------------- charts (static SVG; hover layer specified in FSM-02)
function columns({ w, h, data, color, highlight = -1, unit = '' }) {
  const pad = { t: 22, b: 26 };
  const max = Math.max(...data.map((d) => d[1]), 1);
  const slot = w / data.length;
  const bw = Math.min(24, slot * 0.5);
  const base = h - pad.b;
  let s = `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" role="img" aria-label="${data.map((d) => `${d[0]} ${d[1]}${unit}`).join(', ')}" style="display: block">`;
  s += `<line x1="0" x2="${w}" y1="${base + 0.5}" y2="${base + 0.5}" stroke="#E3E6EB" stroke-width="1"></line>`;
  data.forEach(([label, v], i) => {
    const x = i * slot + (slot - bw) / 2;
    const bh = v === 0 ? 0 : Math.max(6, ((base - pad.t) * v) / max);
    const y = base - bh;
    const r = Math.min(4, bh);
    if (bh > 0) s += `<path d="M${x},${base} V${y + r} Q${x},${y} ${x + r},${y} H${x + bw - r} Q${x + bw},${y} ${x + bw},${y + r} V${base} Z" fill="${color}" opacity="${highlight === -1 || highlight === i ? 1 : 0.55}"></path>`;
    s += `<text x="${x + bw / 2}" y="${y - 6}" text-anchor="middle" font-size="12" font-weight="600" fill="#111827" font-family="Archivo, sans-serif">${v}</text>`;
    s += `<text x="${x + bw / 2}" y="${h - 8}" text-anchor="middle" font-size="11.5" fill="#5B6474" font-family="Archivo, sans-serif">${label}</text>`;
  });
  return s + '</svg>';
}

function hbars({ w, rows, color, max: mx }) {
  const max = mx ?? Math.max(...rows.map((r) => r[1]));
  return `<div style="display: flex; flex-direction: column; gap: 12px">${rows
    .map(([label, v, sub]) => {
      const pct = (v / max) * 100;
      return `<div style="display: grid; grid-template-columns: 132px minmax(0, 1fr) 36px; align-items: center; gap: 12px"><span style="font-size: 13px; color: #384152" class="fx-ell">${label}${sub ? ` <span style="color: #8A92A0">${sub}</span>` : ''}</span><span style="height: 14px; display: flex"><span style="width: ${pct}%; height: 14px; background: ${color}; border-radius: 0 4px 4px 0; display: block"></span></span><span class="fx-num" style="font-size: 13px; font-weight: 600; text-align: right">${v}</span></div>`;
    })
    .join('')}</div>`;
}

const SC = { OPEN: '#8A92A0', SCHEDULED: '#2A78D6', IN_PROGRESS: '#EDA100', ON_HOLD: '#6250D6', COMPLETED: '#1BAF7A' };
function stackRow(segs, max) {
  const total = segs.reduce((a, s) => a + s[1], 0);
  return `<span style="display: flex; gap: 2px; height: 14px; width: ${(total / max) * 100}%">${segs
    .map(([k, v], i) => `<span title="${PILL[k][1]} ${v}" style="flex: ${v} 1 0; background: ${SC[k]}; border-radius: ${i === segs.length - 1 ? '0 4px 4px 0' : '0'}; display: block"></span>`)
    .join('')}</span>`;
}

// ---------------------------------------------------------------- round 3 helpers
const fillTabs = (list, sel) => tabs(list, sel, ' data-fill="1" style="border-bottom: none; border-top: 1px solid #E3E6EB"');
const recordHead = ({ tile, over, title, chips, actions, facts }) =>
  `<section class="fx-card"><div style="display: flex; gap: 18px; padding: 22px; align-items: flex-start">${tile}<div style="display: flex; flex-direction: column; gap: 8px; flex-grow: 1; min-width: 0"><span class="fx-over">${over}</span><h1 class="fx-h1" style="font-size: 22px; line-height: 28px">${title}</h1><div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap">${chips}</div></div><div style="display: flex; gap: 8px; flex-shrink: 0">${actions}</div></div><div class="fx-facts">${facts.map(([l, v, s]) => `<div class="fx-fact"><span class="fx-small">${l}</span><b>${v}</b>${s ? `<span class="fx-small">${s}</span>` : ''}</div>`).join('')}</div>`;
const twoCol = (left, right, rw = 340) => `<div style="display: grid; grid-template-columns: minmax(0, 1fr) ${rw}px; gap: 20px; align-items: start"><div style="display: flex; flex-direction: column; gap: 20px; min-width: 0">${left}</div><aside style="display: flex; flex-direction: column; gap: 20px">${right}</aside></div>`;
const stack = (inner, max = 1128) => `<div style="display: flex; flex-direction: column; gap: 16px; max-width: ${max}px">${inner}</div>`;
const roSec = (icon, title, desc, inner, o = {}) => sec(icon, title, desc, inner, o);
const dashTile = (label, icon = 'plus') => `<button type="button" class="fx-dash" style="min-height: 64px; display: flex; align-items: center; justify-content: center; gap: 8px; background: transparent; font-family: inherit; font-size: 14px; font-weight: 600; color: #384152; cursor: pointer; width: 100%">${I(icon, 16)}${label}</button>`;
const tbl = (cols, head, rows) => `<div role="table" class="fx-table" style="box-shadow: none"><div role="row" class="fx-tr fx-thead" style="${cols}">${head.map((h) => `<span class="fx-th">${h}</span>`).join('')}</div>${rows.map((r) => `<div role="row" class="fx-tr" style="${cols}">${r.join('')}</div>`).join('')}</div>`;
const cell2 = (a, b2) => `<div class="fx-cell"><span class="fx-ell" style="font-weight: 600">${a}</span><span class="fx-small fx-ell">${b2}</span></div>`;
const woT = (id, t) => `<span class="fx-id">${id}</span>&#160; ${t}`;

// ================================================================ FSM-01 Foundations
{
  const h = 1680;
  const sw = (hex, name, note = '') => `<div class="fx-sw"><span class="fx-sw__c" style="background: ${hex}"></span><span style="font-size: 12.5px; font-weight: 600">${name}</span><span class="fx-id" style="font-size: 11.5px">${hex}${note ? ` · ${note}` : ''}</span></div>`;
  const group = (title, desc, items, cols = 6) => `<section class="fx-card" style="padding: 22px 24px; display: flex; flex-direction: column; gap: 16px"><div style="display: flex; flex-direction: column; gap: 4px"><h2 class="fx-h2">${title}</h2><p class="fx-sub">${desc}</p></div><div style="display: grid; grid-template-columns: repeat(${cols}, minmax(0, 1fr)); gap: 14px">${items}</div></section>`;
  const tline = (spec, sample, style) => `<div style="display: grid; grid-template-columns: 200px minmax(0, 1fr); gap: 20px; align-items: baseline; padding: 12px 0; border-top: 1px solid #EEF0F3"><span class="fx-id" style="font-size: 12px">${spec}</span><span style="${style}">${sample}</span></div>`;
  const body = `<div class="fx" style="padding: 56px 64px; display: flex; flex-direction: column; gap: 24px; box-sizing: border-box; background: #F2F4F7; height: 100%">
<div style="display: flex; flex-direction: column; gap: 10px; max-width: 980px"><span class="fx-over" style="color: #A4502B">FSM-01 · Oliveira FSM design system · foundations</span><h1 class="fx-h1" style="font-size: 36px; line-height: 44px">A calmer, cooler workspace for field operations</h1><p class="fx-sub" style="font-size: 16px; line-height: 25px">The shell (top bar and the approved sidebar) stays exactly as the Platform defines it. Everything inside the FSM’s content area moves to a cool slate ground with white surfaces, so dense operational data reads clean and the terracotta accent is reserved for what you can act on. Archivo stays the voice; mono is only for codes.</p></div>
${group('Neutrals — ground, surfaces, lines, ink', 'Replaces the beige #F4F2ED in the FSM content area. Same dark shell. Text steps all pass AA on white and on the ground.', [
    sw('#F2F4F7', 'Ground', 'content area'), sw('#FFFFFF', 'Surface', 'cards, tables'), sw('#F8F9FB', 'Surface 2', 'table head, footers'), sw('#F5F7FA', 'Hover', 'rows, tabs'), sw('#E3E6EB', 'Border', 'cards, dividers'), sw('#8A92A0', 'Control border', 'inputs ≥ 3:1'),
    sw('#111827', 'Ink 1', '17.7:1'), sw('#384152', 'Ink 2', '10.6:1'), sw('#5B6474', 'Ink 3', '6.0:1'), sw('#8A92A0', 'Ink 4', 'placeholder only'), sw('#12151B', 'Shell', 'unchanged'), sw('#1A1E26', 'Sidebar', 'unchanged'),
  ].join(''))}
${group('Accent — terracotta, used with intent', 'The product colour marks selection: the selected tab, the current step, focus, links. Confirming actions (Complete, Save, Continue, Create) use the mint confirm green — see FSM-02. Never a background for large areas, never a status.', [
    sw('#FBF1EB', 'Accent 50', 'selected tint'), sw('#F5DCCD', 'Accent 100', 'borders on tint'), sw('#E39A70', 'Accent 300', 'on the dark shell'), sw('#A4502B', 'Accent 600', 'primary · 5.6:1'), sw('#8A4221', 'Accent 700', 'hover / text on tint'), sw('#71361B', 'Accent 800', 'pressed'),
  ].join(''))}
<div style="display: grid; grid-template-columns: minmax(0, 1.3fr) minmax(0, 1fr); gap: 24px">
<section class="fx-card" style="padding: 22px 24px; display: flex; flex-direction: column; gap: 16px"><div style="display: flex; flex-direction: column; gap: 4px"><h2 class="fx-h2">Work order lifecycle — one colour per status, everywhere</h2><p class="fx-sub">The same hue is the pill dot, the chart series and the timeline marker. Validated as a categorical set (light): CVD ΔE worst adjacent 27.1, normal-vision 32.8 — pass. Amber and aqua sit below 3:1 on white, so they always come with a label or legend.</p></div>
<div style="display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 12px">${['OPEN', 'SCHEDULED', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED', 'CANCELLED'].map((s) => `<div class="fx-sw"><span class="fx-sw__c" style="height: 40px; background: ${SC[s] ?? '#C3C8D0'}"></span>${pill(s)}<span class="fx-id" style="font-size: 11px">${SC[s] ?? '#C3C8D0'}</span></div>`).join('')}</div></section>
<section class="fx-card" style="padding: 22px 24px; display: flex; flex-direction: column; gap: 16px"><div style="display: flex; flex-direction: column; gap: 4px"><h2 class="fx-h2">Signals — reserved, always with an icon</h2><p class="fx-sub">Overdue and urgent use the critical red; at-risk uses amber; done uses green. They never colour a chart series.</p></div>
<div style="display: flex; flex-direction: column; gap: 12px"><div style="display: flex; gap: 18px; align-items: center">${prio('URGENT')}${prio('HIGH')}${prio('NORMAL')}${prio('LOW')}</div><div style="display: flex; gap: 12px; align-items: center">${late('3 d late')}${tone('p-warn', 'Due in 15 h')}${tone('p-crit', 'High criticality')}${tone('p-active', 'Active')}</div></div></section>
</div>
<div style="display: grid; grid-template-columns: minmax(0, 1.3fr) minmax(0, 1fr); gap: 24px">
<section class="fx-card" style="padding: 22px 24px; display: flex; flex-direction: column; gap: 6px"><h2 class="fx-h2" style="margin-bottom: 8px">Type — Archivo, tuned for data</h2>
${tline('Page title · 24/32 · 600 · −1.5%', 'Work orders', 'font-size: 24px; line-height: 32px; font-weight: 600; letter-spacing: -0.015em')}
${tline('Record title · 22/28 · 600', 'VRF system quarterly maintenance', 'font-size: 22px; line-height: 28px; font-weight: 600; letter-spacing: -0.01em')}
${tline('Card title · 15/22 · 600', 'Today’s dispatch', 'font-size: 15px; font-weight: 600')}
${tline('Body · 14/20 · 400', 'Report to the maintenance desk before going to the roof.', 'font-size: 14px; line-height: 20px')}
${tline('Label · 13/18 · 500', 'Scheduled for', 'font-size: 13px; font-weight: 500; color: #384152')}
${tline('Overline · 11/16 · 600 · caps', 'Work order · preventive', 'font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: #5B6474')}
${tline('KPI · 30/36 · 600 · tabular', '19 · 4 · 92%', 'font-size: 30px; font-weight: 600; letter-spacing: -0.02em; font-variant-numeric: tabular-nums')}
${tline('Code · JetBrains Mono 12.5', '#1014 · HSC-CH01 · 11.222.333/0001-81', "font-family: 'JetBrains Mono', monospace; font-size: 12.5px; color: #5B6474")}
</section>
<section class="fx-card" style="padding: 22px 24px; display: flex; flex-direction: column; gap: 16px"><h2 class="fx-h2">Space, radius, depth</h2>
<div style="display: flex; align-items: flex-end; gap: 10px">${[4, 8, 12, 16, 20, 24, 32].map((n) => `<div style="display: flex; flex-direction: column; align-items: center; gap: 6px"><span style="width: ${n}px; height: ${n}px; background: #F5DCCD; border-radius: 2px; display: block"></span><span class="fx-id" style="font-size: 11px">${n}</span></div>`).join('')}</div>
<ul class="fx-spec"><li>Page padding 24/32 · card padding 20–22 · grid gap 16–20 · field gap 18×20.</li><li>Radius: controls 8 · cards 12 · pills 999 · small chips 7.</li><li>Depth: cards = 1 px border + <span class="fx-id">0 1px 2px /4%</span>; floating (sticky save bar, menus) = <span class="fx-id">0 8px 24px /8%</span>. No heavy shadows on resting surfaces.</li><li>Focus: 2 px white gap + 2 px accent ring on every control.</li><li>Motion 120–160 ms, off with reduced motion.</li></ul>
<div style="display: flex; gap: 14px"><div class="fx-card" style="flex: 1; height: 64px; display: flex; align-items: center; justify-content: center"><span class="fx-small">Resting card</span></div><div class="fx-card" style="flex: 1; height: 64px; display: flex; align-items: center; justify-content: center; box-shadow: 0 8px 24px rgba(16,24,40,.08)"><span class="fx-small">Floating</span></div></div>
</section>
</div>
</div>`;
  B({ file: 'FsmDsFoundations.dc.html', title: 'FSM design system — foundations', w: 1440, h, body });
}

// ================================================================ FSM-02 Components
{
  const h = 2500;
  const st = (cap, html) => `<div style="display: flex; flex-direction: column; gap: 8px; min-width: 0"><span class="fx-cap">${cap}</span>${html}</div>`;
  const blk = (title, desc, inner) => `<section class="fx-card" style="padding: 22px 24px; display: flex; flex-direction: column; gap: 16px"><div style="display: flex; flex-direction: column; gap: 4px"><h2 class="fx-h2">${title}</h2>${desc ? `<p class="fx-sub">${desc}</p>` : ''}</div>${inner}</section>`;
  const tabState = (cap, cls, sel, dis = false) => st(cap, `<div class="fx-tabs" style="border-bottom-color: #E3E6EB"><button type="button" role="tab" class="fx-tab ${cls}" aria-selected="${sel}"${dis ? ' aria-disabled="true"' : ''}>${I('clipboard', 16)}Execution<span class="fx-count">3</span></button></div>`);
  const segState = (cap, attrs) => st(cap, `<div class="fx-seg"><button type="button" ${attrs}>7 days</button></div>`);
  const body = `<div class="fx" style="padding: 56px 64px; display: flex; flex-direction: column; gap: 24px; box-sizing: border-box; background: #F2F4F7; height: 100%">
<div style="display: flex; flex-direction: column; gap: 10px; max-width: 980px"><span class="fx-over" style="color: #A4502B">FSM-02 · Oliveira FSM design system · components</span><h1 class="fx-h1" style="font-size: 36px; line-height: 44px">Components and their states</h1><p class="fx-sub" style="font-size: 16px; line-height: 25px">Built on shadcn/Radix primitives already in the app — new looks, same behaviour. Every interactive piece has normal, hover, selected, focus and disabled states.</p></div>
${blk('Tabs — record and page navigation', 'Underline tabs with an optional icon and a count. The selected tab takes ink + 600 + a 2 px accent bar; hover gets a soft fill; keyboard focus a 2 px accent ring; disabled stays visible but greyed. A tab whose fields have errors shows a red count.', `<div style="display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 16px">${tabState('Normal', '', false)}${tabState('Hover', 'is-hover', false)}${tabState('Selected', '', true)}${tabState('Focus', 'is-focus', false)}${tabState('Disabled', '', false, true)}${st('With errors', `<div class="fx-tabs"><button type="button" role="tab" class="fx-tab" aria-selected="false">${I('user', 16)}Contacts<span class="fx-count fx-count--err">2</span></button></div>`)}</div>
${tabs([['Overview', 'gauge'], ['Details', 'idCard'], ['Sites', 'pin', 2], ['Contacts', 'user', 1], ['Equipment', 'wrench', 4], ['Work orders', 'clipboard', 9]], 0)}`)}
<div style="display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 24px">
${blk('Segmented control — views and ranges', 'For switching a view of the same data (date range, saved views). Never for navigation between pages.', `<div style="display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px">${segState('Normal', 'aria-pressed="false"')}${segState('Hover', 'aria-pressed="false" class="is-hover"')}${segState('Selected', 'aria-pressed="true"')}${segState('Focus', 'aria-pressed="false" class="is-focus"')}</div>${seg([['Today'], ['7 days'], ['30 days'], ['Quarter']], 2)}`)}
${blk('Filter chips — combinable', 'Status filters with counts. Several can be on at once (they combine); “on” is ink-filled so it reads as a filter, not a status.', `<div style="display: flex; flex-wrap: wrap; gap: 8px">${['OPEN', 'SCHEDULED', 'IN_PROGRESS', 'ON_HOLD'].map((s, i) => `<button type="button" class="fx-filt" aria-pressed="${i < 2}"><i style="background: ${SC[s]}"></i>${PILL[s][1]}<span class="fx-count">${[7, 8, 2, 2][i]}</span></button>`).join('')}</div>`)}
</div>
${blk('Section tabs — reusable for long records', 'Equal-width tabs across the card, used where one record is split by subject (customer edit: Details · Sites · Contacts). Not used by work orders, which keep the stepper.', fillTabs([['Customer and site', 'contact'], ['Service', 'clipboard', '!1'], ['Schedule', 'calendar'], ['References', 'file']], 1).replace(' style="border-bottom: none; border-top: 1px solid #E3E6EB"', ''))}
${blk('Buttons', 'Confirm (mint green, dark text — AA 5.3:1) for Complete, Save, Continue and Create; create outline green, edit amber, destructive red. Terracotta is no longer a button colour: it marks selection and focus.', `<div style="display: grid; grid-template-columns: 140px repeat(5, minmax(0, 1fr)); gap: 14px 16px; align-items: center">
<span></span>${['Normal', 'Hover', 'Focus', 'Disabled', 'Small'].map((c) => `<span class="fx-cap">${c}</span>`).join('')}
${[['Confirm', 'fx-btn--confirm', 'Complete', 'checkCircle'], ['Create', 'fx-btn--create', 'New work order', 'plus'], ['Edit', 'fx-btn--edit', 'Edit', 'pencil'], ['Destructive', 'fx-btn--danger', 'Cancel order', 'xCircle'], ['Secondary', '', 'Put on hold', 'pause'], ['Ghost', 'fx-btn--ghost', 'Back', 'arrowLeft']]
    .map(([n, v, l, ic]) => `<span class="fx-small" style="font-weight: 600; color: #384152">${n}</span>${b(v, l, ic)}${b(v + ' is-hover', l, ic)}${b(v + ' is-focus', l, ic)}${b(v + ' is-disabled', l, ic, ' disabled="{{ true }}"')}${b(v + ' fx-btn--sm', l, ic)}`)
    .join('')}</div>`)}
${blk('Fields — edit and view share one layout', 'Edit shows controls; view shows the same grid as read-only values with a hairline — no grey boxes, full-contrast text, “—” when empty. Errors: red border + ring, message in the toast (as today), so nothing moves.', `<div class="fx-grid">${inp('Default', '', { c: 'c2', ph: 'Search a customer', select: true })}${inp('Hover', 'Hospital Santa Clara', { c: 'c2', state: 'hover', select: true })}${inp('Focus', 'Rua Vergueiro', { c: 'c2', state: 'focus' })}${inp('Error', '11.222.333/0001', { c: 'c2', state: 'error', req: true, mono: true })}${inp('Disabled', '', { c: 'c2', state: 'disabled', ph: 'Choose a customer first' })}${ro('Read-only (view)', 'Rua Vergueiro, 2300', { c: 'c2' })}</div>`)}
<div style="display: grid; grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr); gap: 24px">
${blk('Stepper — creating a work order', 'Four steps on top, each a card: done (green check + summary), current (accent ring), to do (dashed). Clicking a done step goes back; Continue validates only the current step. The same steps are used to create and to edit a work order.', `<div class="fx-steps" style="grid-template-columns: repeat(3, minmax(0, 1fr))"><div class="fx-step is-done"><span class="fx-step__n">${I('check', 14, 'stroke-width: 3')}</span><span style="display: flex; flex-direction: column; min-width: 0"><span class="fx-small">Step 1</span><span style="font-size: 13.5px; font-weight: 600">Customer</span></span></div><div class="fx-step is-current"><span class="fx-step__n">2</span><span style="display: flex; flex-direction: column"><span class="fx-small">Step 2</span><span style="font-size: 13.5px; font-weight: 600">Service</span></span></div><div class="fx-step is-todo"><span class="fx-step__n">3</span><span style="display: flex; flex-direction: column"><span class="fx-small">Step 3</span><span style="font-size: 13.5px; font-weight: 600; color: #5B6474">Schedule</span></span></div></div>`)}
${blk('Status, priority and people', 'Pills carry state; priority is an arrow + word; people are avatar + name.', `<div style="display: flex; flex-wrap: wrap; gap: 10px; align-items: center">${['OPEN', 'SCHEDULED', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED', 'CANCELLED'].map(pill).join('')}</div><div style="display: flex; gap: 18px; align-items: center">${prio('URGENT')}${prio('HIGH')}${prio('NORMAL')}${prio('LOW')}<span style="width: 10px"></span>${who('JA')}${who(null)}</div>`)}
</div>
${blk('Table rows', 'Rows are 60 px with a title + one quiet line. Hover tints; selection tints with a 3 px accent edge. Header 40 px on Surface 2. Overdue shows in the Due cell only.', `<div class="fx-table">${(() => {
    const cols = 'grid-template-columns: 16px minmax(0, 2fr) minmax(0, 1.4fr) 130px 100px 170px 120px';
    const row = (cls, chk, id, t, s, c, city, st2, pr2, tk, due) => `<div class="fx-tr ${cls}" style="${cols}"><input type="checkbox" class="fx-check"${chk ? ' defaultChecked="{{ true }}"' : ''} aria-label="Select ${id}"><div class="fx-cell"><span class="fx-ell" style="font-weight: 600"><span class="fx-id">${id}</span>&#160; ${t}</span><span class="fx-small fx-ell">${s}</span></div><div class="fx-cell"><span class="fx-ell">${c}</span><span class="fx-small">${city}</span></div><span>${pill(st2)}</span>${prio(pr2)}${who(tk)}<span>${due}</span></div>`;
    return `<div class="fx-tr fx-thead" style="${cols}"><span></span><span class="fx-th">Work order</span><span class="fx-th">Customer</span><span class="fx-th">Status</span><span class="fx-th">Priority</span><span class="fx-th">Technician</span><span class="fx-th">Due</span></div>${row('', false, '#1024', 'Compressor 2,000-hour service', 'Preventive maintenance · Air compressor 1', 'Indústria Metalúrgica Forte S.A.', 'Santo André', 'SCHEDULED', 'NORMAL', 'JA', '<span style="font-size: 13px">Nov 24</span>')}${row('is-hover', false, '#1015', 'Crane hoist stops mid-lift', 'Corrective maintenance · Overhead crane', 'Indústria Metalúrgica Forte S.A.', 'Santo André', 'ON_HOLD', 'URGENT', 'RS', late('2 d late'))}${row('is-sel', true, '#1028', 'Elevator A stopping between floors', 'Corrective maintenance · Elevator A', 'Edifício Comercial Faria Lima', 'São Paulo', 'OPEN', 'URGENT', null, late('3 d late'))}`;
  })()}</div>`)}
<div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 24px">
${blk('KPI tile', 'Label, value, one context line, optional meter. The whole tile links to the filtered list.', `<a href="#" class="fx-card fx-stat" style="box-shadow: none"><span class="fx-stat__l">${I('alarm', 16, 'color: #D03B3B')}Overdue</span><span class="fx-stat__v">4</span><span class="fx-small">2 urgent · oldest 3 days late</span></a>`)}
${blk('Callouts', 'Accent tint for instructions the technician must read; blue for system hints.', `<div class="fx-callout">${I('info', 17, 'color: #A4502B; margin-top: 2px')}<span><b>Service instructions</b>Service entrance on Rua Domingos de Morais.</span></div><div class="fx-info">${I('sparkles', 16, 'margin-top: 1px')}<span>Suggested by the type: High · 3 h · due in 24 h.</span></div>`)}
${blk('Empty state', 'Says what is missing and offers the next step when the member may take it.', `<div class="fx-dash" style="padding: 22px; display: flex; flex-direction: column; align-items: center; gap: 8px; text-align: center"><span class="fx-tile fx-tile--slate">${I('clipboard', 17)}</span><span style="font-weight: 600; font-size: 14px">No work orders yet</span><span class="fx-small">Open the first one for this customer.</span>${b('fx-btn--create fx-btn--sm', 'New work order', 'plus')}</div>`)}
</div>
</div>`;
  B({ file: 'FsmPatterns.dc.html', title: 'FSM design system — components', w: 1440, h, body });
}

// ================================================================ FSM-03 Dashboard
{
  const h = 1740;
  const nav = navExpanded({ active: 'overview', open: ['operations'] });
  const statusBar = `<div class="fx-meter" style="height: 8px; margin-top: 4px">${[['OPEN', 7], ['SCHEDULED', 8], ['IN_PROGRESS', 2], ['ON_HOLD', 2]].map(([k, v]) => `<span style="flex: ${v} 1 0; background: ${SC[k]}"></span>`).join('')}</div>`;
  const kpis = `<section class="fx-card" style="display: grid; grid-template-columns: 1.35fr 1fr 1fr 1fr">
<a href="#" class="fx-stat" style="border-right: 1px solid #E3E6EB"><span class="fx-stat__l">${I('clipboard', 16, 'color: #5B6474')}Open backlog</span><span class="fx-stat__v">19</span>${statusBar}<div class="fx-legend" style="gap: 10px; font-size: 12px"><span><i style="background: #8A92A0"></i>Open 7</span><span><i style="background: #2A78D6"></i>Scheduled 8</span><span><i style="background: #EDA100"></i>In progress 2</span><span><i style="background: #6250D6"></i>On hold 2</span></div></a>
<a href="#" class="fx-stat" style="border-right: 1px solid #E3E6EB"><span class="fx-stat__l">${I('alarm', 16, 'color: #D03B3B')}Overdue</span><span class="fx-stat__v" style="color: #B42318">4</span><span class="fx-small">2 urgent · oldest 3 days late</span><span style="margin-top: auto">${linkS('Review')}</span></a>
<a href="#" class="fx-stat" style="border-right: 1px solid #E3E6EB"><span class="fx-stat__l">${I('circleDashed', 16, 'color: #5B6474')}Without technician</span><span class="fx-stat__v">7</span><span class="fx-small">All open · 1 urgent</span><span style="margin-top: auto">${linkS('Assign')}</span></a>
<a href="#" class="fx-stat"><span class="fx-stat__l">${I('checkCircle', 16, 'color: #1BAF7A')}Completed · 30 days</span><span class="fx-stat__v">10</span><span class="fx-small">Latest Nov 12 · #1010</span><span style="margin-top: auto">${linkS('History')}</span></a>
</section>`;
  const throughput = card('Completed per week', 'Last 4 weeks · by completion date', `<div style="position: relative">${columns({ w: 300, h: 168, data: [['Oct 19', 2], ['Oct 26', 1], ['Nov 2', 4], ['Nov 9', 3]], color: '#1BAF7A', highlight: 2 })}<div class="fx-tip" style="left: 150px; top: 18px"><b style="display: block">Week of Nov 2</b>4 completed · #1004–#1007</div></div>`);
  const ahead = card('Scheduled ahead', 'Next 7 days · work orders per day', columns({ w: 330, h: 168, data: [['Sun', 2], ['Mon', 1], ['Tue', 1], ['Wed', 1], ['Thu', 1], ['Fri', 0], ['Sat', 1]], color: '#2A78D6', highlight: 0 }));
  const mix = card('Work mix', 'All 31 work orders by type', `${hbars({ rows: [['Preventive', 13], ['Corrective', 12], ['Technical visit', 4], ['Installation', 2]], color: '#A4502B' })}<div class="fx-hl" style="margin-top: 16px; flex-direction: row; align-items: center; gap: 10px">${I('trendUp', 16, 'color: #0F6B4A')}<span class="fx-small" style="color: #384152"><b style="color: #111827">42%</b> preventive — the share to grow</span></div>`);
  // dispatch timeline, full width (card body 1088 px)
  const tl = (() => {
    const total = 1080, x0 = 196, W = total - x0 - 28, hours = 12;
    const xFor = (hh) => x0 + ((hh - 7) / hours) * W;
    const rowsT = [
      ['JA', [[7, 18, 'IN_PROGRESS', '#1014 VRF system quarterly maintenance · in progress since Nov 14'], [10, 12, 'SCHEDULED', '#1019 Elevator B']]],
      ['RS', [[9, 11, 'SCHEDULED', '#1018 Chiller 02']]],
      ['BF', []],
    ];
    const rowH = 76;
    let s = `<div style="position: relative; width: ${total}px; max-width: 100%; height: ${40 + rowsT.length * rowH}px; overflow: hidden">`;
    for (let hh = 7; hh <= 19; hh += 1) {
      const major = hh % 2 === 1;
      if (major) s += `<span class="fx-small" style="position: absolute; left: ${xFor(hh) - 18}px; top: 0; width: 36px; text-align: center">${String(hh).padStart(2, '0')}:00</span>`;
      s += `<span style="position: absolute; left: ${xFor(hh)}px; top: 24px; bottom: 0; width: 1px; background: ${major ? '#E3E6EB' : '#F1F3F6'}"></span>`;
    }
    rowsT.forEach(([k, blocks], r) => {
      const top = 32 + r * rowH;
      s += `<span style="position: absolute; left: 0; top: ${top}px; width: ${x0 - 16}px; height: ${rowH - 8}px; display: flex; flex-direction: column; justify-content: center; gap: 2px">${who(k)}<span class="fx-small" style="padding-left: 34px">${blocks.length ? `${blocks.length} today` : 'Free today'}</span></span>`;
      if (r > 0) s += `<span style="position: absolute; left: 0; right: 0; top: ${top - 4}px; height: 1px; background: #F1F3F6"></span>`;
      if (!blocks.length) s += `<span class="fx-small" style="position: absolute; left: ${x0 + 10}px; top: ${top + 26}px">Next: Mon, Nov 16 · 08:00 · #1020 Dental compressor service</span>`;
      blocks.forEach(([a, z, st2, label]) => {
        const prog = st2 === 'IN_PROGRESS';
        const twoLanes = blocks.length > 1;
        const y = top + (twoLanes ? (prog ? 4 : 38) : 18);
        const hgt = twoLanes ? 30 : 34;
        s += `<span style="position: absolute; left: ${xFor(a) + 2}px; width: ${xFor(z) - xFor(a) - 4}px; top: ${y}px; height: ${hgt}px; border-radius: 6px; background: ${prog ? 'repeating-linear-gradient(135deg, #FDF3DC 0 6px, #FBE8BF 6px 12px)' : '#EAF2FC'}; box-shadow: inset 3px 0 0 ${SC[st2]}; display: flex; align-items: center; padding: 0 10px 0 12px; box-sizing: border-box; font-size: 12.5px; font-weight: 500; color: ${prog ? '#6E4A00' : '#1C4F95'}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">${label}</span>`;
      });
    });
    s += `<span style="position: absolute; left: ${xFor(9.67)}px; top: 24px; bottom: 0; width: 2px; background: #A4502B"></span><span style="position: absolute; left: ${xFor(9.67) - 22}px; top: 0; padding: 1px 6px; border-radius: 999px; background: #A4502B; color: #FFFFFF; font-size: 11px; font-weight: 600">09:40</span>`;
    return s + '</div>';
  })();
  const dispatch = card('Today’s dispatch', 'Sunday, Nov 15 · each block = scheduled start + estimated duration', tl, { action: `<div style="display: flex; gap: 8px; align-items: center">${tone('p-sched', '2 scheduled')}${tone('p-prog', '1 in progress')}${tone('p-open', '1 technician free')}${linkA('Open schedule')}</div>` });
  const attCols = 'grid-template-columns: minmax(0, 2fr) minmax(0, 1.4fr) 130px 96px 170px 150px 40px';
  const attRow = (id, t, s, c, city, st2, p, tk, why) => `<div role="row" class="fx-tr" style="${attCols}">${cell2(woT(id, t), s)}<div class="fx-cell"><span class="fx-ell">${c}</span><span class="fx-small">${city}</span></div><span>${pill(st2)}</span>${prio(p)}${who(tk)}<div class="fx-cell">${why}</div>${b('fx-btn--ghost fx-btn--sm fx-btn--icon', '', 'chevRight', ` aria-label="Open ${id}"`)}</div>`;
  const attention = `<section class="fx-card" style="display: flex; flex-direction: column"><div class="fx-cardh"><div style="display: flex; flex-direction: column; gap: 2px"><h2 class="fx-h2" style="font-size: 15px">Needs attention</h2><span class="fx-small">Overdue first, then on hold · 5 work orders</span></div>${linkA('All overdue')}</div><div class="fx-table" style="border-radius: 0; border-left: none; border-right: none; border-bottom: none; box-shadow: none"><div role="row" class="fx-tr fx-thead" style="${attCols}"><span class="fx-th">Work order</span><span class="fx-th">Customer</span><span class="fx-th">Status</span><span class="fx-th">Priority</span><span class="fx-th">Technician</span><span class="fx-th">Why</span><span></span></div>
${attRow('#1028', 'Elevator A stopping between floors', 'Corrective maintenance · Elevator A', 'Edifício Comercial Faria Lima', 'São Paulo', 'OPEN', 'URGENT', null, `${late('3 d late')}<span class="fx-small">No technician</span>`)}
${attRow('#1015', 'Crane hoist stops mid-lift', 'Corrective maintenance · Overhead crane', 'Indústria Metalúrgica Forte S.A.', 'Santo André', 'ON_HOLD', 'URGENT', 'RS', `${late('2 d late')}<span class="fx-small">On hold</span>`)}
${attRow('#1026', 'Split AC dripping water', 'Corrective maintenance · Split AC — Day clinic', 'Hospital Santa Clara Ltda.', 'São Paulo', 'OPEN', 'NORMAL', null, `${late('2 d late')}<span class="fx-small">No technician</span>`)}
${attRow('#1013', 'Cold room door does not seal', 'Corrective maintenance · Cold room 2', 'Supermercados Bom Preço S.A.', 'Campinas', 'IN_PROGRESS', 'HIGH', 'BF', `${late('1 d late')}<span class="fx-small">In progress</span>`)}
${attRow('#1016', 'Rooftop unit tripping the breaker', 'Corrective maintenance · Rooftop unit', 'Escola Aprender Mais Ltda.', 'Campinas', 'ON_HOLD', 'HIGH', 'JA', `<span style="font-size: 13px">Due Nov 16</span><span class="fx-small">On hold</span>`)}
</div></section>`;
  const teamRows = [['JA', [['SCHEDULED', 3], ['IN_PROGRESS', 1], ['ON_HOLD', 1]]], ['RS', [['SCHEDULED', 3], ['ON_HOLD', 1]]], ['BF', [['SCHEDULED', 2], ['IN_PROGRESS', 1]]], [null, [['OPEN', 7]]]];
  const team = card('Team load', 'Unfinished work orders per technician', `<div style="display: flex; flex-direction: column; gap: 16px">${teamRows
    .map(([k, segs]) => `<div style="display: grid; grid-template-columns: 170px minmax(0, 1fr) 28px; gap: 14px; align-items: center">${who(k)}<span style="display: flex">${stackRow(segs, 8)}</span><span class="fx-num" style="font-weight: 600; font-size: 13.5px; text-align: right">${segs.reduce((a, s) => a + s[1], 0)}</span></div>`)
    .join('')}<div class="fx-legend" style="padding-top: 6px; border-top: 1px solid #EEF0F3"><span><i style="background: #8A92A0"></i>Open</span><span><i style="background: #2A78D6"></i>Scheduled</span><span><i style="background: #EDA100"></i>In progress</span><span><i style="background: #6250D6"></i>On hold</span></div></div>`, { action: `<a href="#" class="fx-btn fx-btn--sm">Table view</a>` });
  const byPriority = card('Open by priority', 'Unfinished work orders · 19', `${hbars({ rows: [['Urgent', 2, ''], ['High', 3, ''], ['Normal', 11, ''], ['Low', 3, '']], color: '#5B6474', max: 11 })}<p class="fx-small" style="margin: 14px 0 0">Urgent: #1028, #1015 — both overdue.</p>`);
  const inner = `<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 20px"><div style="display: flex; flex-direction: column; gap: 4px"><span class="fx-over">Sunday, Nov 15 · all branches</span><h1 class="fx-h1">Operations overview</h1></div><div style="display: flex; align-items: center; gap: 10px">${seg([['Today'], ['7 days'], ['30 days'], ['Quarter']], 2)}<button type="button" class="fx-btn">${I('building', 16)}<span>All branches</span>${I('chevDown', 16, 'color: #5B6474')}</button>${b('fx-btn--create', 'New work order', 'plus')}</div></div>
${kpis}
<div style="display: grid; grid-template-columns: 1fr 1.1fr 1.1fr; gap: 20px">${throughput}${ahead}${mix}</div>
${dispatch}
${attention}
<div style="display: grid; grid-template-columns: minmax(0, 1.6fr) minmax(0, 1fr); gap: 20px; align-items: start">${team}${byPriority}</div>`;
  B({ file: 'FsmDashboard.dc.html', title: 'Oliveira FSM — operations overview', w: 1440, h, body: page(nav, inner, h) });
}

// ================================================================ FSM-04 Work orders list
{
  const h = 1080;
  const nav = navExpanded({ active: 'work-orders', open: ['operations'] });
  const cols = 'grid-template-columns: 16px minmax(0, 2.1fr) minmax(0, 1.35fr) 124px 92px 168px 112px 112px';
  const rows = [
    ['#1028', 'Elevator A stopping between floors', 'Corrective maintenance · Elevator A', 'Edifício Comercial Faria Lima', 'São Paulo', 'OPEN', 'URGENT', null, '—', ['!', '3 d late']],
    ['#1026', 'Split AC dripping water', 'Corrective maintenance · Split AC — Day clinic', 'Hospital Santa Clara Ltda.', 'São Paulo', 'OPEN', 'NORMAL', null, '—', ['!', '2 d late']],
    ['#1015', 'Crane hoist stops mid-lift', 'Corrective maintenance · Overhead crane', 'Indústria Metalúrgica Forte S.A.', 'Santo André', 'ON_HOLD', 'URGENT', 'RS', 'Nov 13 · 08:00', ['!', '2 d late']],
    ['#1013', 'Cold room door does not seal', 'Corrective maintenance · Cold room 2', 'Supermercados Bom Preço S.A.', 'Campinas', 'IN_PROGRESS', 'HIGH', 'BF', 'Nov 14 · 08:00', ['!', '1 d late']],
    ['#1017', 'Monthly preventive maintenance', 'Preventive maintenance · Chiller 01', 'Hospital Santa Clara Ltda.', 'São Paulo', 'SCHEDULED', 'NORMAL', 'RS', 'Nov 14 · 14:00', ['Today', '18:00']],
    ['#1014', 'VRF system quarterly maintenance', 'Preventive maintenance · VRF system', 'Hotel Vista Verde Ltda.', 'Campinas', 'IN_PROGRESS', 'NORMAL', 'JA', 'Nov 14 · 09:00', ['Today', '18:00']],
    ['#1018', 'Monthly preventive maintenance', 'Preventive maintenance · Chiller 02', 'Hospital Santa Clara Ltda.', 'São Paulo', 'SCHEDULED', 'NORMAL', 'RS', 'Nov 15 · 09:00', ['Nov 16', 'in 1 d']],
    ['#1016', 'Rooftop unit tripping the breaker', 'Corrective maintenance · Rooftop unit', 'Escola Aprender Mais Ltda.', 'Campinas', 'ON_HOLD', 'HIGH', 'JA', 'Nov 12 · 14:00', ['Nov 16', 'in 1 d']],
    ['#1021', 'Cold room preventive maintenance', 'Preventive maintenance · Cold room 1', 'Supermercados Bom Preço S.A.', 'São Paulo', 'SCHEDULED', 'NORMAL', 'BF', 'Nov 17 · 07:00', ['Nov 18', 'in 3 d']],
    ['#1020', 'Dental compressor service', 'Preventive maintenance · Air compressor', 'Clínica Sorriso Odontologia', 'São Paulo', 'SCHEDULED', 'LOW', 'BF', 'Nov 16 · 08:00', ['Nov 19', 'in 4 d']],
  ];
  const rowHtml = rows.map(([id, t, s, c, city, st2, p, tk, sch, due]) => {
    const sel = id === '#1028';
    const dueHtml = due[0] === '!' ? `<div class="fx-cell">${late(due[1])}</div>` : `<div class="fx-cell"><span style="font-size: 13.5px">${due[0]}</span><span class="fx-small">${due[1]}</span></div>`;
    return `<div role="row" class="fx-tr${sel ? ' is-sel' : ''}${id === '#1017' ? ' is-hover' : ''}" style="${cols}"><input type="checkbox" class="fx-check"${sel ? ' defaultChecked="{{ true }}"' : ''} aria-label="Select ${id}"><div class="fx-cell"><span class="fx-ell" style="font-weight: 600"><span class="fx-id">${id}</span>&#160; ${t}</span><span class="fx-small fx-ell">${s}</span></div><div class="fx-cell"><span class="fx-ell">${c}</span><span class="fx-small">${city}</span></div><span>${pill(st2)}</span>${prio(p)}${who(tk)}<span style="font-size: 13px; color: ${sch === '—' ? '#8A92A0' : '#384152'}">${sch}</span>${dueHtml}</div>`;
  }).join('');
  const th = (l, sort = true) => `<span class="fx-th">${l}${sort ? I('sort', 12) : ''}${I('filter', 11)}</span>`;
  const inner = `${crumbs(['Oliveira FSM', 'Operations', 'Work orders'])}
<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 20px"><div style="display: flex; flex-direction: column; gap: 4px"><h1 class="fx-h1">Work orders</h1><p class="fx-sub">31 work orders · 4 overdue · 7 without technician</p></div><div style="display: flex; gap: 8px">${b('fx-btn--ghost', 'Export', 'download')}${b('fx-btn--edit', 'Edit', 'pencil')}${b('fx-btn--create', 'New work order', 'plus')}</div></div>
<div style="display: flex; align-items: center; justify-content: space-between; gap: 16px">${seg([['All', 31], ['Unassigned', 7], ['Overdue', 4], ['Today', 2], ['Mine', 0]], 0)}<div style="display: flex; align-items: center; gap: 8px"><span class="fx-in" style="width: 300px; height: 36px">${I('search', 16, 'color: #5B6474')}<span class="ph">Number, title or customer</span><span class="fx-id" style="margin-left: auto; font-size: 11px; border: 1px solid #E3E6EB; border-radius: 4px; padding: 0 5px">/</span></span><button type="button" class="fx-btn">${I('filter', 15)}<span>Filters</span><span class="fx-count" style="background: #FBF1EB; color: #8A4221">1</span></button><button type="button" class="fx-btn fx-btn--icon" aria-label="Customize columns">${I('sliders', 16)}</button></div></div>
<div style="display: flex; flex-wrap: wrap; align-items: center; gap: 8px"><span class="fx-small" style="margin-right: 4px">Status</span>${['OPEN', 'SCHEDULED', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED', 'CANCELLED'].map((s, i) => `<button type="button" class="fx-filt" aria-pressed="${i < 4}"><i style="background: ${SC[s] ?? '#C3C8D0'}"></i>${PILL[s][1]}<span class="fx-count">${[7, 8, 2, 2, 10, 2][i]}</span></button>`).join('')}<span style="width: 1px; height: 20px; background: #CDD2DA; margin: 0 4px"></span><span class="fx-small">Sorted by due date · overdue first</span><a href="#" style="font-size: 13px; color: #5B6474; margin-left: 4px">Clear filters</a></div>
<div role="table" class="fx-table"><div role="row" class="fx-tr fx-thead" style="${cols}"><input type="checkbox" class="fx-check" aria-label="Select all">${th('Work order')}${th('Customer')}${th('Status')}${th('Priority')}${th('Technician', false)}${th('Scheduled')}<span class="fx-th" style="color: #111827">Due${I('chevDown', 13, 'color: #A4502B')}${I('filter', 11)}</span></div>${rowHtml}
<div style="display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; border-top: 1px solid #EEF0F3; background: #F8F9FB"><span class="fx-small"><b style="color: #111827">1 selected</b> · showing 1–10 of 19 matching</span><div style="display: flex; align-items: center; gap: 14px"><span class="fx-small">Rows</span><span class="fx-in" style="width: 72px; height: 32px">10<span class="chev">${I('chevDown', 14)}</span></span><div style="display: flex; gap: 4px">${b('fx-btn--sm fx-btn--icon fx-btn--ghost', '', 'arrowLeft', ' aria-label="Previous page"')}<button type="button" class="fx-btn fx-btn--sm" style="background: #FBF1EB; border-color: #F5DCCD; color: #8A4221">1</button>${b('fx-btn--sm fx-btn--ghost', '2')}${b('fx-btn--sm fx-btn--icon fx-btn--ghost', '', 'arrowRight', ' aria-label="Next page"')}</div></div></div></div>`;
  B({ file: 'FsmWorkOrders.dc.html', title: 'Work orders — list', w: 1440, h, body: page(nav, inner, h) });
}

// ================================================================ FSM-05 Work order — Overview / Execution / History
const woNav = () => navExpanded({ active: 'work-orders', open: ['operations'] });
const woProg = (cls, title, when, who2) => `<div class="fx-prog__i ${cls}"><span class="fx-prog__bar"></span><span class="fx-prog__t">${cls === 'is-done' ? I('checkCircle', 14, 'color: #1BAF7A') : cls === 'is-current' ? I('play', 14, 'color: #A4502B') : I('circleDashed', 14, 'color: #A7AEB9')}${title}</span><span class="fx-small">${when}${who2 ? ` · ${who2}` : ''}</span></div>`;
const woHeader = (sel) => `<section class="fx-card"><div style="display: flex; gap: 18px; padding: 22px 22px 18px; align-items: flex-start"><span class="fx-tile fx-tile--lg">${I('clipboard', 22)}</span><div style="display: flex; flex-direction: column; gap: 8px; flex-grow: 1; min-width: 0"><span class="fx-over"><span class="fx-id" style="font-size: 11.5px; letter-spacing: 0">#1014</span> · Preventive maintenance · CPS-01 Campinas</span><h1 class="fx-h1" style="font-size: 22px; line-height: 28px">VRF system quarterly maintenance</h1><div style="display: flex; align-items: center; gap: 10px">${pill('IN_PROGRESS')}${prio('NORMAL')}<span style="width: 1px; height: 16px; background: #E3E6EB"></span>${tone('p-warn', 'Due today 18:00 · 8 h left')}</div></div><div style="display: flex; gap: 8px; flex-shrink: 0">${b('fx-btn--edit', 'Edit', 'pencil')}${b('fx-btn--danger', 'Cancel order', 'xCircle')}<span style="width: 1px; height: 36px; background: #E3E6EB; margin: 0 4px"></span>${b('', 'Put on hold', 'pause')}${b('fx-btn--confirm', 'Complete', 'checkCircle')}</div></div>
<div class="fx-prog">${woProg('is-done', 'Opened', 'Nov 11, 09:00', 'Marina Costa')}${woProg('is-done', 'Scheduled', 'Nov 11, 10:00', 'Juliana Alves')}${woProg('is-current', 'In progress', 'since Nov 14, 09:20', '')}${woProg('is-todo', 'Completed', 'needs a resolution', '')}</div>
<div style="padding: 0 10px">${fillTabs([['Overview', 'gauge'], ['Execution', 'wrench', 1], ['History', 'history', 5]], sel)}</div></section>`;
const woAside = () => {
  const assign = card('Assignment', '', `<div style="display: flex; align-items: center; gap: 12px">${av('JA', 'av1 fx-av--lg')}<div style="display: flex; flex-direction: column; flex-grow: 1"><span style="font-weight: 600">Juliana Alves</span><span class="fx-small">Technician · CPS-01 Campinas</span></div>${b('fx-btn--ghost fx-btn--sm fx-btn--icon', '', 'phone', ' aria-label="Call Juliana Alves"')}</div><div class="fx-hl" style="margin-top: 16px"><span class="fx-small">Scheduled window</span><span style="font-weight: 600; font-size: 14px">Nov 14 · 09:00 → 11:00</span><span class="fx-small">Estimated 2 h <span class="fx-new">New</span></span></div>`);
  const sla = card('Due date', '', `<div style="display: flex; align-items: baseline; justify-content: space-between"><span style="font-weight: 600; font-size: 18px" class="fx-num">Nov 15 · 18:00</span><span class="fx-small" style="color: #6E4A00; font-weight: 600">8 h left</span></div><div class="fx-meter" style="margin-top: 12px"><span style="width: 92%; background: #EDA100"></span></div><div style="display: flex; justify-content: space-between; margin-top: 6px" class="fx-small"><span>Opened Nov 11</span><span>92% of the time used</span></div>`);
  const cust = card('Customer', '', `<div style="display: flex; flex-direction: column; gap: 4px"><a href="#" style="font-weight: 600; color: #111827; text-decoration: none">Hotel Vista Verde Ltda.</a><span class="fx-small">Campinas · <span class="fx-num">(19) 3794-1000</span></span></div><div style="display: flex; align-items: center; gap: 10px; margin-top: 14px; padding: 10px 12px; border-radius: 10px; border: 1px dashed #CDD2DA">${av('?', 'av0')}<span style="display: flex; flex-direction: column; flex-grow: 1; min-width: 0"><span style="font-size: 13.5px; font-weight: 600">[Site contact]</span><span class="fx-small">Contact on site <span class="fx-new">New</span></span></span>${b('fx-btn--sm fx-btn--icon', '', 'phone', ' aria-label="Call the site contact"')}</div>`);
  const meta = card('Details', '', `<dl class="fx-kv"><dt>Type</dt><dd>Preventive maintenance</dd><dt>Branch</dt><dd>CPS-01 · Campinas</dd><dt>Customer ref.</dt><dd style="color: #8A92A0">— <span class="fx-new">New</span></dd><dt>Opened by</dt><dd>Marina Costa · Nov 11</dd></dl>`);
  return assign + sla + cust + meta;
};
const itemsTable = (editable) => `<div class="fx-table" style="box-shadow: none"><div class="fx-tr fx-thead" style="grid-template-columns: minmax(0, 1fr) 70px 110px 110px 32px"><span class="fx-th">Item</span><span class="fx-th" style="justify-content: flex-end">Qty</span><span class="fx-th" style="justify-content: flex-end">Unit price</span><span class="fx-th" style="justify-content: flex-end">Total</span><span></span></div><div class="fx-tr" style="grid-template-columns: minmax(0, 1fr) 70px 110px 110px 32px; min-height: 56px"><div class="fx-cell"><span style="display: flex; align-items: center; gap: 8px; font-weight: 600">Preventive maintenance visit <span class="fx-chip" style="height: 22px">Service</span></span><span class="fx-small">Added by Juliana Alves · Nov 14, 10:20 · catalog price at that moment</span></div><span class="fx-num" style="text-align: right">2 H</span><span class="fx-num" style="text-align: right">R$ 180,00</span><span class="fx-num" style="text-align: right; font-weight: 600">R$ 360,00</span>${editable ? b('fx-btn--ghost fx-btn--sm fx-btn--icon', '', 'trash', ' aria-label="Remove item"') : '<span></span>'}</div><div class="fx-tr" style="grid-template-columns: minmax(0, 1fr) 110px; min-height: 48px; background: #F8F9FB"><span style="display: flex; gap: 16px; font-size: 13px; color: #5B6474"><span>Services <b class="fx-num" style="color: #111827">R$ 360,00</b></span><span>Products <b class="fx-num" style="color: #111827">R$ 0,00</b></span></span><span class="fx-num" style="text-align: right; font-weight: 700">R$ 360,00</span></div></div>`;
{
  const h = 1400;
  const job = card('Job', 'What to do and what to know before arriving', `<div style="display: flex; flex-direction: column; gap: 14px"><div class="fx-callout">${I('info', 17, 'color: #A4502B; margin-top: 2px')}<span><b>Customer service instructions · new field</b>[Example] Report to the hotel’s maintenance desk first; the VRF condensers on the roof are only reached with the hotel’s technician.</span></div><div class="fx-f">${lbl('Description')}<span class="fx-small" style="font-size: 14px; color: #8A92A0">No description — added when the work order is created.</span></div></div>`);
  const equip = card('Equipment', '', `<div style="display: flex; gap: 14px; align-items: flex-start"><span class="fx-tile fx-tile--slate">${I('wrench', 17)}</span><div style="display: flex; flex-direction: column; gap: 4px; min-width: 0"><a href="#" style="font-weight: 600; color: #111827; text-decoration: none">VRF system</a><span class="fx-id">HVV-VRF1</span><span class="fx-small">LG · Multi V 5 · HVAC</span></div></div><dl class="fx-kv" style="margin-top: 16px; grid-template-columns: 110px minmax(0, 1fr)"><dt>Criticality</dt><dd>${tone('p-warn', 'Medium')} <span class="fx-new">New</span></dd><dt>Last service</dt><dd><span class="fx-small" style="font-size: 13.5px">None completed yet</span></dd></dl>`, { action: linkA('Open') });
  const site = card('Service site', '', `<div style="display: flex; gap: 14px; align-items: flex-start"><span class="fx-tile fx-tile--slate">${I('pin', 17)}</span><div style="display: flex; flex-direction: column; gap: 4px; min-width: 0"><span style="font-weight: 600">Hotel</span><span class="fx-small" style="font-size: 13.5px; color: #384152">Av. Dr. Moraes Salles, 1500 · Centro<br>Campinas/SP · 13010-001</span></div></div><dl class="fx-kv" style="margin-top: 16px; grid-template-columns: 110px minmax(0, 1fr)"><dt>Receives techs</dt><dd>[Example] Mon–Sat 07:00–19:00 <span class="fx-new">New</span></dd></dl>`, { action: `<a href="#" class="fx-btn fx-btn--sm">${I('map', 14)}<span>Open in Maps</span></a>` });
  const items = card('Materials and services', 'Summary · managed in the Execution tab', itemsTable(false), { action: linkA('Go to Execution') });
  const inner = `${crumbs(['Oliveira FSM', 'Operations', 'Work orders', '#1014'])}${woHeader(0)}${twoCol(job + `<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px">${equip}${site}</div>` + items, woAside())}`;
  B({ file: 'FsmWorkOrderRecord.dc.html', title: 'Work order #1014 — Overview tab', w: 1440, h, body: page(woNav(), inner, h) });
}
{
  const h = 1920;
  const log = card('Work log', 'Times are recorded by the status changes — nothing to type', `<div style="display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px"><div class="fx-hl"><span class="fx-small">Started</span><span style="font-weight: 600">Nov 14 · 09:20</span><span class="fx-small">by Juliana Alves</span></div><div class="fx-hl"><span class="fx-small">Elapsed since start</span><span style="font-weight: 600" class="fx-num">24 h 20 min</span><span class="fx-small">no pauses</span></div><div class="fx-hl"><span class="fx-small">Estimated</span><span style="font-weight: 600">2 h <span class="fx-new">New</span></span><span class="fx-small">from the type</span></div><div class="fx-hl"><span class="fx-small">Completed</span><span style="font-weight: 600; color: #8A92A0">—</span><span class="fx-small">needs a resolution</span></div></div>`);
  const add = `<div style="display: grid; grid-template-columns: minmax(0, 1fr) 120px auto; gap: 12px; align-items: end; margin-top: 16px; padding: 14px; border-radius: 10px; background: #F8F9FB; border: 1px solid #EEF0F3">${inp('Add from the catalog', '', { c: '', ph: 'Search active products and services', icon: 'search', select: true })}${inp('Quantity', '1', { c: '', mono: true })}${b('', 'Add', 'plus')}</div>`;
  const items = card('Materials and services', 'Allowed while In progress or On hold · 1 item', itemsTable(true) + add);
  const notes = card('Notes', 'Visible to everyone on the work order, recorded in History', `<div style="display: flex; gap: 12px; align-items: flex-start">${av('JA', 'av1')}<div style="display: flex; flex-direction: column; gap: 10px; flex-grow: 1"><span class="fx-in fx-ta" style="min-height: 84px"><span class="ph">What happened, what is missing, what the customer said…</span></span><div style="display: flex; justify-content: space-between; align-items: center"><span class="fx-small">0 / 2,000</span>${b('fx-btn--confirm fx-btn--sm', 'Add note', 'message')}</div></div></div><div class="fx-dash" style="margin-top: 16px; padding: 18px; display: flex; align-items: center; gap: 10px; color: #5B6474; font-size: 13.5px">${I('message', 16)}No notes yet. Notes from the technician and the office appear here, newest first.</div>`);
  const outcome = card('Outcome', 'Filled when the status changes', `<dl class="fx-kv" style="grid-template-columns: 150px minmax(0, 1fr)"><dt>Resolution</dt><dd style="color: #8A92A0">— asked for when completing</dd><dt>Hold reason</dt><dd style="color: #8A92A0">— asked for when putting on hold</dd><dt>Cancellation reason</dt><dd style="color: #8A92A0">— asked for when cancelling</dd></dl>`);
  const dialog = `<div style="display: flex; flex-direction: column; gap: 8px"><span class="fx-cap">Dialog · Complete work order</span><div style="padding: 28px; border-radius: 14px; background: rgba(17,24,39,.42); display: flex; justify-content: center"><div class="fx-card" style="width: 560px; box-shadow: 0 16px 40px rgba(16,24,40,.24)"><div class="fx-cardh" style="padding: 20px 22px 8px"><div style="display: flex; gap: 12px; align-items: center"><span class="fx-tile" style="background: #E5F5EE; color: #0F6B4A">${I('checkCircle', 18)}</span><div style="display: flex; flex-direction: column"><h2 class="fx-h2">Complete #1014</h2><span class="fx-small">VRF system quarterly maintenance</span></div></div>${b('fx-btn--ghost fx-btn--sm fx-btn--icon', '', 'x', ' aria-label="Close"')}</div><div style="padding: 12px 22px 18px; display: flex; flex-direction: column; gap: 14px"><div class="fx-grid">${inp('Resolution', 'Cleaned filters and coils of the 6 indoor units; checked pressures and drains. [Example]', { c: 'c12', ta: true, req: true })}</div><div style="display: flex; gap: 16px" class="fx-small"><span>Items <b class="fx-num" style="color: #111827">R$ 360,00</b></span><span>Started <b style="color: #111827">Nov 14, 09:20</b></span></div></div><div style="display: flex; justify-content: flex-end; gap: 8px; padding: 14px 22px; border-top: 1px solid #E3E6EB; background: #F8F9FB; border-radius: 0 0 12px 12px">${b('fx-btn--ghost', 'Cancel')}${b('fx-btn--confirm', 'Complete work order', 'checkCircle')}</div></div></div></div>`;
  const inner = `${crumbs(['Oliveira FSM', 'Operations', 'Work orders', '#1014', 'Execution'])}${woHeader(1)}${twoCol(log + items + notes + outcome + dialog, woAside())}`;
  B({ file: 'FsmWorkOrderExecution.dc.html', title: 'Work order #1014 — Execution tab', w: 1440, h, body: page(woNav(), inner, h) });
}
{
  const h = 1300;
  const ev = (icon, color, title, detail, whoK, when) => `<div style="display: grid; grid-template-columns: 36px minmax(0, 1fr) auto; gap: 14px; padding: 14px 0; position: relative"><span style="width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: #FFFFFF; border: 1px solid #E3E6EB; color: ${color}; position: relative; z-index: 1">${I(icon, 16)}</span><div style="display: flex; flex-direction: column; gap: 3px; min-width: 0"><span style="font-weight: 600; font-size: 14px">${title}</span>${detail ? `<span style="font-size: 13.5px; color: #384152">${detail}</span>` : ''}<span class="fx-small" style="display: flex; align-items: center; gap: 6px">${av(whoK, TECH[whoK][1])}${TECH[whoK][0]}</span></div><span class="fx-small" style="white-space: nowrap">${when}</span></div>`;
  const day = (label, inner) => `<div style="display: flex; flex-direction: column"><span class="fx-cap" style="padding: 10px 0 4px">${label}</span><div style="position: relative"><span style="position: absolute; left: 17px; top: 20px; bottom: 20px; width: 2px; background: #EEF0F3"></span>${inner}</div></div>`;
  const hist = `<section class="fx-card" style="display: flex; flex-direction: column"><div class="fx-cardh"><div style="display: flex; flex-direction: column; gap: 2px"><h2 class="fx-h2" style="font-size: 15px">Activity</h2><span class="fx-small">Every change is recorded automatically · newest first</span></div>${seg([['All', 5], ['Status', 2], ['Assignment', 1], ['Items', 1], ['Notes', 0], ['Edits', 0]], 0)}</div><div class="fx-cardb">
${day('Saturday, Nov 14', ev('package', '#5B6474', 'Item added', '2 H · Preventive maintenance visit · R$ 360,00', 'JA', '10:20') + ev('arrows', '#EDA100', `Status ${pill('SCHEDULED')} → ${pill('IN_PROGRESS')}`, '', 'JA', '09:20'))}
${day('Wednesday, Nov 11', ev('arrows', '#2A78D6', `Status ${pill('OPEN')} → ${pill('SCHEDULED')}`, 'Automatic — technician and date were set', 'MC', '10:00') + ev('userCheck', '#6250D6', 'Assigned to Juliana Alves', 'Scheduled for Nov 14, 09:00', 'MC', '10:00') + ev('clipboard', '#A4502B', 'Work order opened', 'Preventive maintenance · Normal · due Nov 15, 18:00', 'MC', '09:00'))}
</div></section>`;
  const inner = `${crumbs(['Oliveira FSM', 'Operations', 'Work orders', '#1014', 'History'])}${woHeader(2)}${twoCol(hist, woAside())}`;
  B({ file: 'FsmWorkOrderHistory.dc.html', title: 'Work order #1014 — History tab', w: 1440, h, body: page(woNav(), inner, h) });
}

// ================================================================ FSM-06 New / edit work order — steps
const STEPS = [['Customer and site', 'Customer, site, equipment, contact'], ['Service', 'Type, priority, title'], ['Schedule', 'Technician, date, duration'], ['Review', 'Check and create']];
const stepBar = (cur, done, edit = false) => `<div class="fx-steps">${STEPS.map(([t, s], i) => {
  const n = i + 1;
  const cls = n === cur ? 'is-current' : done.includes(n) ? 'is-done' : 'is-todo';
  const sub = edit && n !== cur ? 'Saved · click to open' : s;
  return `<button type="button" class="fx-step ${cls}"${n === cur ? ' aria-current="step"' : ''}><span class="fx-step__n">${cls === 'is-done' ? I('check', 14, 'stroke-width: 3') : n}</span><span style="display: flex; flex-direction: column; min-width: 0; gap: 1px"><span class="fx-small">Step ${n}</span><span style="font-size: 14px; font-weight: 600; color: ${cls === 'is-todo' ? '#5B6474' : '#111827'}">${t}</span><span class="fx-small fx-ell">${sub}</span></span></button>`;
}).join('')}</div>`;
const sumRow = (icon, title, sub, empty = false) => `<div style="display: flex; gap: 12px${empty ? '; opacity: .55' : ''}"><span class="fx-tile fx-tile--slate">${I(icon, 16)}</span><div style="display: flex; flex-direction: column; min-width: 0"><span style="font-weight: 600">${title}</span><span class="fx-small">${sub}</span></div></div>`;
const summary = (upTo) => `<aside class="fx-card" style="display: flex; flex-direction: column"><div class="fx-cardh"><h2 class="fx-h2" style="font-size: 15px">Summary</h2>${upTo >= 3 ? tone('p-sched', 'Will open as Scheduled') : tone('p-open', 'Will open as Open')}</div><div class="fx-cardb" style="display: flex; flex-direction: column; gap: 14px">
${sumRow('contact', 'Hospital Santa Clara Ltda.', 'Main building — Rua Vergueiro, 2300')}
${sumRow('wrench', 'Chiller 01 <span class="fx-id">HSC-CH01</span>', 'Carrier 30XA-252 · High criticality')}
${sumRow('user', 'Paula Ribeiro', 'Contact on site · (11) 98123-4501')}
${upTo >= 2 ? sumRow('clipboard', 'Chiller 01 tripping on high pressure', 'Corrective maintenance · High') : sumRow('clipboard', 'Service', 'Step 2', true)}
${upTo >= 3 ? sumRow('calendar', 'Rafael Souza · Mon, Nov 16 · 08:00', 'SP-01 · 3 h · due Nov 17, 08:00') : sumRow('calendar', 'Schedule', 'Step 3', true)}
<div class="fx-callout" style="font-size: 13px">${I('info', 16, 'color: #A4502B; margin-top: 2px')}<span><b>Service instructions</b>Service entrance on Rua Domingos de Morais.</span></div>
</div></aside>`;
const stepFoot = (back, next, hint) => `<div style="display: flex; justify-content: space-between; align-items: center; padding: 16px 24px; border-top: 1px solid #E3E6EB; background: #F8F9FB; border-radius: 0 0 12px 12px">${back ? b('', 'Back', 'arrowLeft') : '<span></span>'}<div style="display: flex; gap: 10px; align-items: center"><span class="fx-small">${hint}</span>${next}</div></div>`;
const stepCard = (title, desc, inner, foot) => `<section class="fx-card"><div class="fx-cardh" style="padding: 20px 24px 6px"><div style="display: flex; flex-direction: column; gap: 2px"><h2 class="fx-h2">${title}</h2><p class="fx-sub" style="font-size: 13px">${desc}</p></div><span class="fx-small">* required</span></div><div style="padding: 18px 24px 24px"><div class="fx-grid">${inner}</div></div>${foot}</section>`;
const prioPick = (sel, c = 'c6') => `<div class="fx-f ${c}">${lbl('Priority', { req: true })}<div class="fx-seg" style="width: 100%; display: grid; grid-template-columns: repeat(4, minmax(0, 1fr))">${['LOW', 'NORMAL', 'HIGH', 'URGENT'].map((p) => `<button type="button" aria-pressed="${p === sel}" style="justify-content: center; height: 34px">${prio(p)}</button>`).join('')}</div></div>`;
const newPage = (n, head, body, edit = false) => {
  const h = edit ? 1200 : 1240;
  const inner = `${crumbs(['Oliveira FSM', 'Operations', 'Work orders', edit ? '#1014' : 'New', ...(edit ? ['Edit'] : [])])}
<div style="display: flex; align-items: flex-end; justify-content: space-between"><div style="display: flex; flex-direction: column; gap: 4px"><span class="fx-over">${edit ? 'Editing · in progress' : `Step ${n} of 4`}</span><h1 class="fx-h1">${head}</h1></div>${edit ? `<div style="display: flex; gap: 8px">${b('fx-btn--ghost', 'Cancel')}${b('fx-btn--confirm', 'Save changes', 'check')}</div>` : b('fx-btn--ghost', 'Discard', 'x')}</div>
${body}`;
  return { h, inner };
};
{
  const form = stepCard('Who and where', 'Start with the customer — the site, equipment and contact lists follow it.', `${inp('Customer', 'Hospital Santa Clara Ltda.', { c: 'c12', req: true, select: true, icon: 'search' })}
<div class="c12 fx-hl" style="flex-direction: row; align-items: center; gap: 14px"><span class="fx-tile" style="background: #DCE9FA; color: #1C4F95; font-weight: 700; font-size: 13px">HS</span><div style="display: flex; flex-direction: column; flex-grow: 1; min-width: 0"><span style="font-weight: 600">Hospital Santa Clara Ltda. <span class="fx-id">11.222.333/0001-81</span></span><span class="fx-small">2 sites · 4 equipment · default branch SP-01</span></div>${tone('p-warn', '4 open work orders')}${linkA('See them')}</div>
${inp('Service site', 'Main building — Rua Vergueiro, 2300 · Vila Mariana · São Paulo/SP', { c: 'c12', select: true, icon: 'pin' })}
${inp('Equipment', 'HSC-CH01 · Chiller 01 · Carrier 30XA-252', { c: 'c6', select: true, help: true })}${inp('Contact on site', 'Paula Ribeiro · Maintenance manager', { c: 'c6', select: true, help: true, isNew: true })}
<div class="c12 fx-info">${I('info', 16, 'margin-top: 1px')}<span>Only this customer’s active equipment appears. Choosing equipment fills the site with the one it is installed at.</span></div>`, stepFoot(false, b('fx-btn--confirm', 'Continue', 'arrowRight'), 'Next: the service'));
  const { h, inner } = newPage(1, 'New work order', `${stepBar(1, [])}<div style="display: grid; grid-template-columns: minmax(0, 1fr) 360px; gap: 20px; align-items: start">${form}${summary(1)}</div>`);
  B({ file: 'FsmWorkOrderStep1.dc.html', title: 'New work order — step 1', w: 1440, h, body: page(woNav(), inner, h) });
}
{
  const form = stepCard('What needs to be done', 'Type, priority and a title the technician understands at a glance.', `${inp('Type', 'Corrective maintenance', { c: 'c6', req: true, select: true })}${prioPick('HIGH')}<div class="c12 fx-info">${I('sparkles', 16, 'margin-top: 1px')}<span><b>Suggested by “Corrective maintenance”:</b> priority High · 3 h on site · due 24 h after the visit. Applied only to fields you have not changed. <span class="fx-new" style="background: #DCE9FA; color: #1C4F95">New</span></span></div>${inp('Title', 'Chiller 01 tripping on high pressure', { c: 'c12', req: true })}${inp('Description', '', { c: 'c12', ta: true, ph: 'What the customer reported, what to bring…' })}${inp('Customer reference', '', { c: 'c6', ph: 'Ticket or purchase order number', help: true, isNew: true })}`, stepFoot(true, b('fx-btn--confirm', 'Continue', 'arrowRight'), 'Next: technician and date'));
  const { h, inner } = newPage(2, 'New work order', `${stepBar(2, [1])}<div style="display: grid; grid-template-columns: minmax(0, 1fr) 360px; gap: 20px; align-items: start">${form}${summary(2)}</div>`);
  B({ file: 'FsmWorkOrderForm.dc.html', title: 'New work order — step 2', w: 1440, h, body: page(woNav(), inner, h) });
}
const techPick = (sel) => {
  const opt = (k, load, open, note) => `<label style="display: grid; grid-template-columns: 18px minmax(0, 1fr) auto; gap: 12px; align-items: center; padding: 12px 14px; border-radius: 10px; border: 1px solid ${k === sel ? '#A4502B' : '#E3E6EB'}; background: ${k === sel ? '#FDF6F2' : '#FFFFFF'}; cursor: pointer"><input type="radio" name="tech" style="accent-color: #A4502B; margin: 0"${k === sel ? ' defaultChecked="{{ true }}"' : ''}>${who(k)}<span style="display: flex; flex-direction: column; align-items: flex-end"><span style="font-size: 13px; font-weight: 600">${load}</span><span class="fx-small">${open} unfinished${note ? ' · ' + note : ''}</span></span></label>`;
  return `<div class="fx-f c12">${lbl('Technician', { help: true })}<div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px">${opt('RS', 'Free on Nov 16', 4, '')}${opt('JA', 'Free on Nov 16', 5, '')}${opt('BF', '1 on Nov 16 · 08:00', 3, '#1020')}</div><span class="fx-small">Only members whose FSM profile can execute work orders · choosing one needs the “assign” permission.</span></div>`;
};
{
  const form = stepCard('When and by whom', 'With a technician and a date it becomes Scheduled; without them it stays Open.', `${techPick('RS')}${inp('Branch', 'SP-01 · São Paulo', { c: 'c4', select: true, help: true })}${inp('Scheduled for', 'Mon, Nov 16, 2026 · 08:00', { c: 'c4', icon: 'calendar' })}${inp('Estimated duration', '3 h', { c: 'c4', icon: 'clock', isNew: true })}${inp('Due', 'Tue, Nov 17, 2026 · 08:00', { c: 'c4', icon: 'hourglass', help: true })}<div class="c8 fx-info" style="align-self: end">${I('sparkles', 16, 'margin-top: 1px')}<span>Due suggested by the type’s SLA (24 h after the visit). It can’t be earlier than the scheduled date.</span></div>`, stepFoot(true, b('fx-btn--confirm', 'Continue', 'arrowRight'), 'Next: review'));
  const { h, inner } = newPage(3, 'New work order', `${stepBar(3, [1, 2])}<div style="display: grid; grid-template-columns: minmax(0, 1fr) 360px; gap: 20px; align-items: start">${form}${summary(3)}</div>`);
  B({ file: 'FsmWorkOrderStep3.dc.html', title: 'New work order — step 3', w: 1440, h, body: page(woNav(), inner, h) });
}
{
  const blockR = (n, icon, title, rows) => `<section class="fx-card"><div class="fx-cardh"><div style="display: flex; align-items: center; gap: 12px"><span class="fx-tile">${I(icon, 16)}</span><div style="display: flex; flex-direction: column"><span class="fx-small">Step ${n}</span><h2 class="fx-h2" style="font-size: 15px">${title}</h2></div></div>${b('fx-btn--ghost fx-btn--sm', 'Change', 'pencil')}</div><div class="fx-cardb"><dl class="fx-kv" style="grid-template-columns: 160px minmax(0, 1fr)">${rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl></div></section>`;
  const left = `${blockR(1, 'contact', 'Customer and site', [['Customer', 'Hospital Santa Clara Ltda.'], ['Service site', 'Main building — Rua Vergueiro, 2300 · Vila Mariana · São Paulo/SP'], ['Equipment', 'Chiller 01 · <span class="fx-id">HSC-CH01</span>'], ['Contact on site', 'Paula Ribeiro · (11) 98123-4501']])}
${blockR(2, 'clipboard', 'Service', [['Type', 'Corrective maintenance'], ['Priority', prio('HIGH')], ['Title', 'Chiller 01 tripping on high pressure'], ['Description', '<span style="color: #8A92A0">—</span>'], ['Customer reference', '<span style="color: #8A92A0">—</span>']])}
${blockR(3, 'calendar', 'Schedule', [['Technician', who('RS')], ['Branch', 'SP-01 · São Paulo'], ['Scheduled for', 'Mon, Nov 16 · 08:00 → 11:00 (3 h)'], ['Due', 'Tue, Nov 17 · 08:00']])}
<div class="fx-sticky"><span class="fx-small">Everything checks out · it will be <b style="color: #1C4F95">#1032</b> and open as <b style="color: #1C4F95">Scheduled</b></span><div style="display: flex; gap: 8px">${b('', 'Back', 'arrowLeft')}${b('fx-btn--confirm', 'Create work order', 'check')}</div></div>`;
  const right = `<section class="fx-card" style="padding: 20px; display: flex; flex-direction: column; gap: 14px"><span class="fx-cap">After creating</span><label style="display: flex; gap: 10px; align-items: center; font-size: 13.5px"><input type="radio" name="after" defaultChecked="{{ true }}" style="accent-color: #A4502B; margin: 0">Open the new work order</label><label style="display: flex; gap: 10px; align-items: center; font-size: 13.5px"><input type="radio" name="after" style="accent-color: #A4502B; margin: 0">Create another for this customer</label><div class="fx-info">${I('info', 16, 'margin-top: 1px')}<span>Rafael Souza sees it in My work right away. Nothing is sent by e-mail in the V1.</span></div></section>`;
  const { h, inner } = newPage(4, 'New work order', `${stepBar(4, [1, 2, 3])}${twoCol(left, right, 360)}`);
  B({ file: 'FsmWorkOrderStep4.dc.html', title: 'New work order — step 4 review', w: 1440, h: 1240, body: page(woNav(), inner, 1240) });
}
{
  const locked = `<div class="c12 fx-hl" style="flex-direction: row; gap: 10px; align-items: center">${I('lock', 16, 'color: #5B6474')}<span class="fx-small" style="color: #384152">Customer and site are locked: the work order is already In progress (the customer can only change while Open or Scheduled).</span></div>`;
  const form = stepCard('When and by whom', 'Editing #1014 — every step is open; one Save keeps all of them.', `${locked}${techPick('JA')}${inp('Branch', 'CPS-01 · Campinas', { c: 'c4', select: true })}${inp('Scheduled for', 'Sat, Nov 14, 2026 · 09:00', { c: 'c4', icon: 'calendar' })}${inp('Estimated duration', '2 h', { c: 'c4', icon: 'clock', isNew: true })}${inp('Due', 'Sun, Nov 15, 2026 · 18:00', { c: 'c4', icon: 'hourglass', state: 'focus' })}`, `<div style="display: flex; justify-content: space-between; align-items: center; padding: 16px 24px; border-top: 1px solid #E3E6EB; background: #F8F9FB; border-radius: 0 0 12px 12px"><span class="fx-small">Changes in other steps are kept until you save or cancel</span><div style="display: flex; gap: 8px">${b('fx-btn--ghost', 'Cancel')}${b('fx-btn--confirm', 'Save changes', 'check')}</div></div>`);
  const { h, inner } = newPage(3, '#1014 · VRF system quarterly maintenance', `${stepBar(3, [1, 2, 4], true)}<div style="display: grid; grid-template-columns: minmax(0, 1fr) 360px; gap: 20px; align-items: start">${form}<aside class="fx-card" style="padding: 20px; display: flex; flex-direction: column; gap: 12px"><span class="fx-cap">Same steps when editing</span><p class="fx-sub" style="font-size: 13px">Edit opens on the step you came from; every step is reachable (done = saved values). Save is always available. Completed and cancelled work orders can’t be edited.</p><div class="fx-hl"><span class="fx-small">Changing the technician needs the “assign” permission; each change is recorded in History.</span></div></aside></div>`, true);
  B({ file: 'FsmWorkOrderEdit.dc.html', title: 'Edit work order — steps', w: 1440, h, body: page(woNav(), inner, h) });
}

// ================================================================ FSM-07 Customer — view tabs
const custNav = () => navExpanded({ active: 'customers', open: ['records'] });
const CUST_TABS = [['Overview', 'gauge'], ['Details', 'idCard'], ['Sites', 'pin', 2], ['Contacts', 'user', 1], ['Equipment', 'wrench', 4], ['Work orders', 'clipboard', 8]];
const custHead = (sel) => recordHead({
  tile: `<span class="fx-tile fx-tile--lg" style="background: #DCE9FA; color: #1C4F95; font-weight: 700; font-size: 16px">HS</span>`,
  over: 'Customer · <span class="fx-id" style="font-size: 11.5px; letter-spacing: 0">CNPJ 11.222.333/0001-81</span>',
  title: 'Hospital Santa Clara Ltda.',
  chips: `${tone('p-active', 'Active')}<span class="fx-chip">Trade name · Hospital Santa Clara</span><span class="fx-chip">${I('building', 13)}Default branch SP-01 <span class="fx-new" style="margin-left: 2px">New</span></span>`,
  actions: `${b('fx-btn--edit', 'Edit', 'pencil')}${b('fx-btn--create', 'New work order', 'plus')}`,
  facts: [['Open work orders', '4', '1 overdue'], ['Equipment', '4', 'all active'], ['Sites', '2', 'São Paulo'], ['Last completed', 'Oct 30', '#1003 · Generator'], ['First work order', 'Oct 25', '#1001']],
}) + `<div style="padding: 0 10px">${fillTabs(CUST_TABS, sel)}</div></section>`;
const custPage = (file, title, sel, body, h) => {
  const inner = `${crumbs(['Oliveira FSM', 'Records', 'Customers', 'Hospital Santa Clara Ltda.'])}${custHead(sel)}${body}`;
  B({ file, title, w: 1440, h, body: page(custNav(), inner, h) });
};
{
  const woRow = (id, t, s, d, st2) => `<a href="#" class="fx-tr" style="grid-template-columns: minmax(0, 1fr) 120px 110px; min-height: 56px; text-decoration: none"><div class="fx-cell"><span class="fx-ell" style="font-weight: 600">${woT(id, t)}</span><span class="fx-small fx-ell">${s}</span></div><span>${pill(st2)}</span><span style="font-size: 13px">${d}</span></a>`;
  const openWos = card('Open work orders', '4 open · sorted by due date', `<div class="fx-table" style="box-shadow: none">${woRow('#1026', 'Split AC dripping water', 'Corrective · Split AC — Day clinic · no technician', late('2 d late'), 'OPEN')}${woRow('#1017', 'Monthly preventive maintenance', 'Preventive · Chiller 01 · Rafael Souza', 'Today 18:00', 'SCHEDULED')}${woRow('#1018', 'Monthly preventive maintenance', 'Preventive · Chiller 02 · Rafael Souza', 'Nov 16', 'SCHEDULED')}${woRow('#1023', 'Generator monthly test', 'Preventive · Generator · Juliana Alves', 'Nov 21', 'SCHEDULED')}</div>`, { action: b('fx-btn--create fx-btn--sm', 'New', 'plus') });
  const eq = (name, tag, model, site, last) => `<a href="#" class="fx-mcard" style="box-shadow: none"><div style="display: flex; align-items: center; justify-content: space-between"><span class="fx-tile fx-tile--slate" style="width: 28px; height: 28px">${I('wrench', 15)}</span>${tone('p-active', 'Active')}</div><div style="display: flex; flex-direction: column; gap: 2px"><span style="font-weight: 600">${name}</span><span class="fx-id" style="font-size: 12px">${tag} · ${model}</span></div><span class="fx-small">${site} · ${last}</span></a>`;
  const equipment = card('Equipment', '4 units on 2 sites', `<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px">${eq('Chiller 01', 'HSC-CH01', 'Carrier 30XA-252', 'Main building', 'last Oct 25')}${eq('Chiller 02', 'HSC-CH02', 'Carrier 30XA-252', 'Main building', 'last Oct 25')}${eq('Generator', 'HSC-GE01', 'Cummins C500D5', 'Main building', 'last Oct 30')}${eq('Split AC — Day clinic', 'HSC-AC07', 'Daikin FTXS50', 'Day clinic', 'no service yet')}</div>`, { action: linkA('All equipment') });
  const contact = card('Primary contact', '', `<div style="display: flex; align-items: center; gap: 12px">${av('PR', 'av2 fx-av--lg')}<div style="display: flex; flex-direction: column; flex-grow: 1"><span style="font-weight: 600">Paula Ribeiro</span><span class="fx-small">Maintenance manager</span></div></div><dl class="fx-kv" style="margin-top: 14px; grid-template-columns: 70px minmax(0, 1fr)"><dt>Mobile</dt><dd class="fx-num">(11) 98123-4501</dd><dt>Company</dt><dd class="fx-num">(11) 3456-1200</dd><dt>Email</dt><dd class="fx-ell">manutencao@santaclara.example</dd></dl>`, { action: linkA('1 contact') });
  const sites = card('Sites', '', `<div class="fx-divide" style="display: flex; flex-direction: column">${[['Main building', 'Rua Vergueiro, 2300 · Vila Mariana', 'Primary · 3 equipment'], ['Day clinic', 'Rua Sena Madureira, 450 · Vila Clementino', '1 equipment']].map(([n, a, s]) => `<div style="display: flex; gap: 12px; padding: 10px 0"><span class="fx-tile fx-tile--slate" style="width: 28px; height: 28px">${I('pin', 15)}</span><div style="display: flex; flex-direction: column; min-width: 0"><span style="font-weight: 600; font-size: 13.5px">${n}</span><span class="fx-small fx-ell">${a}</span><span class="fx-small">${s}</span></div></div>`).join('')}</div>`, { action: linkA('2 sites') });
  const instr = `<div class="fx-callout">${I('info', 17, 'color: #A4502B; margin-top: 2px')}<span><b>Service instructions · shown on every work order</b>Service entrance on Rua Domingos de Morais. [Example] Badge required in the plant room; quiet hours 22:00–06:00.</span></div>`;
  custPage('FsmCustomerRecord.dc.html', 'Customer — Overview tab', 0, twoCol(openWos + equipment, instr + contact + sites, 360), 1280);
}
// Details — read-only, the same sections as edit
const CUST_DETAILS_RO = `${sec('idCard', 'Identification', 'Who the customer is. The document must be unique in the company.', `${ro('Name', 'Hospital Santa Clara Ltda.', { c: 'c8', req: true })}${ro('Trade name', 'Hospital Santa Clara', { c: 'c4' })}${ro('Document type', 'CNPJ', { c: 'c3' })}${ro('CNPJ', '11.222.333/0001-81', { c: 'c3', mono: true })}${ro('State registration', '', { c: 'c3' })}${ro('Municipal registration', '', { c: 'c3' })}${ro('Status', tone('p-active', 'Active'), { c: 'c3' })}`)}
${sec('mail', 'Contact', 'How the office reaches the customer. Site contacts live in Contacts.', `${ro('Email', 'manutencao@santaclara.example', { c: 'c6' })}${ro('Phone', '(11) 3456-1200', { c: 'c3', mono: true })}${ro('Mobile', '(11) 98765-4321', { c: 'c3', mono: true })}`, { opt: true })}
${sec('clipboard', 'Service', 'What every technician must know before arriving, and who usually serves this customer.', `${ro('Service instructions', 'Service entrance on Rua Domingos de Morais. [Example] Badge required in the plant room; quiet hours 22:00–06:00.', { c: 'c8', multi: true, help: true })}${ro('Default branch', 'SP-01 · São Paulo', { c: 'c4', help: true })}`, { isNew: true, opt: true })}
${sec('file', 'Notes', 'Internal notes — not shown to technicians.', `${ro('Notes', '', { c: 'c12' })}`, { opt: true })}`;
{
  custPage('FsmCustomerDetails.dc.html', 'Customer — Details tab', 1, stack(CUST_DETAILS_RO, 1128), 1320);
}
const SITES = [
  { label: 'Main building', type: 'Service', primary: true, zip: '04102-000', street: 'Rua Vergueiro', num: '2300', comp: '', dist: 'Vila Mariana', city: 'São Paulo', st: 'SP', ref: 'Service entrance on Rua Domingos de Morais', hours: '[Example] 24 h · plant room 07:00–19:00', eq: 'HSC-CH01 · HSC-CH02 · HSC-GE01', open: '#1017 · #1018 · #1023' },
  { label: 'Day clinic', type: 'Service', primary: false, zip: '04021-000', street: 'Rua Sena Madureira', num: '450', comp: '', dist: 'Vila Clementino', city: 'São Paulo', st: 'SP', ref: '', hours: '', eq: 'HSC-AC07', open: '#1026' },
];
{
  const siteCard = (s) => `<section class="fx-card" style="display: flex; flex-direction: column"><div class="fx-cardh"><div style="display: flex; gap: 12px; align-items: center"><span class="fx-tile fx-tile--slate">${I('pin', 17)}</span><div style="display: flex; flex-direction: column"><span style="display: flex; gap: 8px; align-items: center"><h2 class="fx-h2" style="font-size: 15px">${s.label}</h2>${s.primary ? tone('p-sched', 'Primary') : ''}</span><span class="fx-small">${s.type} address</span></div></div>${b('fx-btn--sm', 'Open in Maps', 'map')}</div><div class="fx-cardb"><div class="fx-grid">${ro('Address', `${s.street}, ${s.num} · ${s.dist}`, { c: 'c8' })}${ro('CEP', s.zip, { c: 'c4', mono: true })}${ro('City / state', `${s.city}/${s.st}`, { c: 'c6' })}${ro('Complement', s.comp, { c: 'c6' })}${ro('Reference point', s.ref, { c: 'c12' })}${ro('Receives technicians', s.hours, { c: 'c12', isNew: true })}</div><div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 16px"><div class="fx-hl"><span class="fx-small">Equipment here</span><span class="fx-id" style="color: #111827">${s.eq}</span></div><div class="fx-hl"><span class="fx-small">Open work orders</span><span class="fx-id" style="color: #111827">${s.open}</span></div></div></div></section>`;
  custPage('FsmCustomerSites.dc.html', 'Customer — Sites tab', 2, `<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px; align-items: start">${SITES.map(siteCard).join('')}</div><div class="fx-info">${I('info', 16, 'margin-top: 1px')}<span>Exactly one site is primary. A site used by equipment or a work order can’t be removed — change those first.</span></div>`, 1160);
}
{
  const cc = `<section class="fx-card" style="display: flex; flex-direction: column"><div class="fx-cardh"><div style="display: flex; gap: 12px; align-items: center">${av('PR', 'av2 fx-av--lg')}<div style="display: flex; flex-direction: column"><span style="display: flex; gap: 8px; align-items: center"><h2 class="fx-h2" style="font-size: 15px">Paula Ribeiro</h2>${tone('p-sched', 'Primary')}</span><span class="fx-small">Maintenance manager</span></div></div><div style="display: flex; gap: 6px">${b('fx-btn--sm fx-btn--icon', '', 'phone', ' aria-label="Call Paula Ribeiro"')}${b('fx-btn--sm fx-btn--icon', '', 'mail', ' aria-label="Email Paula Ribeiro"')}</div></div><div class="fx-cardb"><div class="fx-grid">${ro('Mobile', '(11) 98123-4501', { c: 'c6', mono: true })}${ro('Phone', '', { c: 'c6' })}${ro('Email', '', { c: 'c12' })}${ro('Notes', '', { c: 'c12' })}</div><div class="fx-hl" style="margin-top: 16px"><span class="fx-small">Contact on site for <b style="color: #111827">0 work orders</b> <span class="fx-new">New</span></span></div></div></section>`;
  custPage('FsmCustomerContacts.dc.html', 'Customer — Contacts tab', 3, `<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px; align-items: start">${cc}<div class="fx-dash" style="padding: 24px; display: flex; flex-direction: column; gap: 8px; align-items: center; justify-content: center; min-height: 220px; text-align: center"><span class="fx-tile fx-tile--slate">${I('user', 17)}</span><span style="font-weight: 600">People the technicians talk to</span><span class="fx-small">Add contacts in Edit — one of them is primary.</span></div></div>`, 1040);
}
{
  const cols = 'grid-template-columns: minmax(0, 1.6fr) minmax(0, 1fr) 100px 110px 120px minmax(0, 1fr) minmax(0, 1fr)';
  const r = (n, tag, model, site, cat, crit, last, next) => [cell2(n, `<span class="fx-id" style="font-size: 12px">${tag}</span> · ${model}`), `<span class="fx-ell">${site}</span>`, `<span>${cat}</span>`, `<span>${tone('p-active', 'Active')}</span>`, `<span>${crit}</span>`, `<span style="font-size: 13px">${last}</span>`, `<span style="font-size: 13px">${next}</span>`];
  const table = tbl(cols, ['Equipment', 'Site', 'Category', 'Status', 'Criticality <span class="fx-new">New</span>', 'Last service', 'Next preventive <span class="fx-new">New</span>'], [
    r('Chiller 01', 'HSC-CH01', 'Carrier 30XA-252', 'Main building', 'HVAC', tone('p-crit', 'High'), 'Oct 25 · #1001', 'Nov 24 · in 9 d'),
    r('Chiller 02', 'HSC-CH02', 'Carrier 30XA-252', 'Main building', 'HVAC', tone('p-crit', 'High'), 'Oct 25 · #1002', 'Nov 24 · in 9 d'),
    r('Generator', 'HSC-GE01', 'Cummins C500D5', 'Main building', 'Power', tone('p-warn', 'Medium'), 'Oct 30 · #1003', '<span style="color: #8A92A0">No interval set</span>'),
    r('Split AC — Day clinic', 'HSC-AC07', 'Daikin FTXS50', 'Day clinic', 'HVAC', tone('p-open', 'Low'), '<span style="color: #8A92A0">—</span>', '<span style="color: #8A92A0">No interval set</span>'),
  ]);
  custPage('FsmCustomerEquipment.dc.html', 'Customer — Equipment tab', 4, `${card('Equipment', '4 units · double-click opens the equipment', table, { action: b('fx-btn--create fx-btn--sm', 'Add equipment', 'plus'), pad: false, style: 'overflow: hidden' })}`, 980);
}
{
  const cols = 'grid-template-columns: minmax(0, 2fr) minmax(0, 1fr) 124px 92px 168px 120px';
  const r = (id, t, s, eq, st2, p, tk, d) => [cell2(woT(id, t), s), `<span class="fx-ell">${eq}</span>`, `<span>${pill(st2)}</span>`, prio(p), who(tk), `<span style="font-size: 13px">${d}</span>`];
  const table = tbl(cols, ['Work order', 'Equipment', 'Status', 'Priority', 'Technician', 'Due / done'], [
    r('#1026', 'Split AC dripping water', 'Corrective maintenance', 'Split AC — Day clinic', 'OPEN', 'NORMAL', null, late('2 d late')),
    r('#1017', 'Monthly preventive maintenance', 'Preventive maintenance', 'Chiller 01', 'SCHEDULED', 'NORMAL', 'RS', 'Today 18:00'),
    r('#1018', 'Monthly preventive maintenance', 'Preventive maintenance', 'Chiller 02', 'SCHEDULED', 'NORMAL', 'RS', 'Nov 16'),
    r('#1023', 'Generator monthly test', 'Preventive maintenance', 'Generator', 'SCHEDULED', 'NORMAL', 'JA', 'Nov 21'),
    r('#1012', 'Install a new split AC in room 12', 'Installation', 'Split AC — Day clinic', 'CANCELLED', 'NORMAL', null, '<span style="color: #8A92A0">Cancelled</span>'),
    r('#1003', 'Generator does not start', 'Corrective maintenance', 'Generator', 'COMPLETED', 'URGENT', 'JA', 'Done Oct 30'),
    r('#1002', 'Monthly preventive maintenance', 'Preventive maintenance', 'Chiller 02', 'COMPLETED', 'NORMAL', 'RS', 'Done Oct 25'),
    r('#1001', 'Monthly preventive maintenance', 'Preventive maintenance', 'Chiller 01', 'COMPLETED', 'NORMAL', 'RS', 'Done Oct 25'),
  ]);
  const filters = `<div style="display: flex; flex-wrap: wrap; gap: 8px; padding: 0 20px 16px">${['OPEN', 'SCHEDULED', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED', 'CANCELLED'].map((s, i) => `<button type="button" class="fx-filt" aria-pressed="false"><i style="background: ${SC[s] ?? '#C3C8D0'}"></i>${PILL[s][1]}<span class="fx-count">${[1, 3, 0, 0, 3, 1][i]}</span></button>`).join('')}</div>`;
  custPage('FsmCustomerWorkOrders.dc.html', 'Customer — Work orders tab', 5, `<section class="fx-card" style="display: flex; flex-direction: column; overflow: hidden"><div class="fx-cardh"><div style="display: flex; flex-direction: column; gap: 2px"><h2 class="fx-h2" style="font-size: 15px">Work orders</h2><span class="fx-small">8 for this customer · newest first</span></div>${b('fx-btn--create fx-btn--sm', 'New work order', 'plus')}</div>${filters}${table.replace('style="box-shadow: none"', 'style="box-shadow: none; border-radius: 0; border-left: none; border-right: none; border-bottom: none"')}</section>`, 1240);
}

// ================================================================ FSM-08 Customer — edit tabs (create uses the same tabs)
const editHead = (sel) => `<section class="fx-card"><div style="display: flex; gap: 16px; padding: 18px 22px; align-items: center"><span class="fx-tile fx-tile--lg" style="background: #DCE9FA; color: #1C4F95; font-weight: 700; font-size: 16px">HS</span><div style="display: flex; flex-direction: column; gap: 2px; flex-grow: 1"><span class="fx-over">Editing customer · creating uses the same three tabs</span><h1 class="fx-h1" style="font-size: 20px; line-height: 26px">Hospital Santa Clara Ltda.</h1></div>${tone('p-warn', 'Unsaved changes')}</div><div style="padding: 0 10px">${fillTabs([['Details', 'idCard'], ['Sites', 'pin', 2], ['Contacts', 'user', '!1'], ['Equipment', 'wrench', 4, 'disabled'], ['Work orders', 'clipboard', 8, 'disabled']], sel)}</div></section>`;
const saveBar = (msg) => `<div class="fx-sticky" style="max-width: 1128px; box-sizing: border-box"><span class="fx-small">${msg}</span><div style="display: flex; gap: 8px">${b('fx-btn--ghost', 'Cancel')}${b('fx-btn--confirm', 'Save changes', 'check')}</div></div>`;
const editPage = (file, title, sel, body, h) => {
  const inner = `${crumbs(['Oliveira FSM', 'Records', 'Customers', 'Hospital Santa Clara Ltda.', 'Edit'])}${editHead(sel)}${body}`;
  B({ file, title, w: 1440, h, body: page(custNav(), inner, h) });
};
{
  const body = stack(`${sec('idCard', 'Identification', 'Who the customer is. The document must be unique in the company.', `${inp('Name', 'Hospital Santa Clara Ltda.', { c: 'c8', req: true })}${inp('Trade name', 'Hospital Santa Clara', { c: 'c4' })}<div class="fx-f c3">${lbl('Document type')}<div class="fx-seg" style="display: grid; grid-template-columns: 1fr 1fr"><button type="button" aria-pressed="false" style="justify-content: center">CPF</button><button type="button" aria-pressed="true" style="justify-content: center">CNPJ</button></div></div>${inp('CNPJ', '11.222.333/0001-81', { c: 'c3', mono: true, state: 'focus' })}${inp('State registration', '', { c: 'c3', ph: 'Optional' })}${inp('Municipal registration', '', { c: 'c3', ph: 'Optional' })}<div class="fx-f c12" style="flex-direction: row; align-items: center; gap: 10px"><span class="fx-switch" role="switch" aria-checked="true" aria-label="Active"></span><span style="font-size: 14px; font-weight: 500">Active</span><span class="fx-small">Inactive customers stay in history but can’t receive new work orders.</span></div>`)}
${sec('mail', 'Contact', 'How the office reaches the customer. Site contacts live in Contacts.', `${inp('Email', 'manutencao@santaclara.example', { c: 'c6', icon: 'mail' })}${inp('Phone', '(11) 3456-1200', { c: 'c3', mono: true })}${inp('Mobile', '(11) 98765-4321', { c: 'c3', mono: true })}`, { opt: true })}
${sec('clipboard', 'Service', 'What every technician must know before arriving, and who usually serves this customer.', `${inp('Service instructions', 'Service entrance on Rua Domingos de Morais. [Example] Badge required in the plant room; quiet hours 22:00–06:00.', { c: 'c8', ta: true, help: true })}${inp('Default branch', 'SP-01 · São Paulo', { c: 'c4', select: true, help: true })}`, { isNew: true, opt: true })}
${sec('file', 'Notes', 'Internal notes — not shown to technicians.', `${inp('Notes', '', { c: 'c12', ta: true, ph: 'Anything the office should remember' })}`, { opt: true })}`, 1128) + saveBar('<b style="color: #B42318">1 contact needs attention</b> · email is not valid');
  editPage('FsmCustomerEdit.dc.html', 'Customer — edit · Details', 0, body, 1320);
}
{
  const siteEdit = (s, i) => `<section class="fx-sec"><div class="fx-sech" style="justify-content: space-between; align-items: center; padding-bottom: 0"><div style="display: flex; gap: 12px; align-items: center"><span class="fx-tile">${I('pin', 17)}</span><span style="display: flex; gap: 8px; align-items: center"><h2 class="fx-h2" style="font-size: 15px">${s.label}</h2>${s.primary ? tone('p-sched', 'Primary') : `<button type="button" class="fx-btn fx-btn--sm fx-btn--ghost">Make primary</button>`}</span></div><button type="button" class="fx-btn fx-btn--danger fx-btn--sm is-disabled" disabled="{{ true }}" title="In use by equipment and work orders">${I('trash', 14)}<span>Remove</span></button></div><div class="fx-secb"><div class="fx-grid">${inp('Type', s.type, { c: 'c3', req: true, select: true })}${inp('Label', s.label, { c: 'c5', help: true })}${inp('CEP', s.zip, { c: 'c4', mono: true, help: true })}${inp('Street', s.street, { c: 'c6' })}${inp('Number', s.num, { c: 'c2' })}${inp('Complement', s.comp, { c: 'c4', ph: 'Block, floor, room' })}${inp('District', s.dist, { c: 'c5' })}${inp('City', s.city, { c: 'c5' })}${inp('State', s.st, { c: 'c2', select: true })}${inp('Reference point', s.ref, { c: 'c7', ph: 'How the technician finds the entrance' })}${inp('Receives technicians', s.hours, { c: 'c5', ph: 'e.g. Mon–Fri 08:00–17:00', isNew: true })}</div><p class="fx-small" style="margin: 14px 0 0">${i === 0 ? 'Used by 3 equipment and 3 open work orders — it can’t be removed.' : 'Used by 1 equipment and 1 open work order — it can’t be removed.'}</p></div></section>`;
  const body = stack(SITES.map(siteEdit).join('') + dashTile('Add site'), 1128) + saveBar('CEP fills street, district, city and state');
  editPage('FsmCustomerEditSites.dc.html', 'Customer — edit · Sites', 1, body, 1460);
}
{
  const contactEdit = `<section class="fx-sec"><div class="fx-sech" style="justify-content: space-between; align-items: center; padding-bottom: 0"><div style="display: flex; gap: 12px; align-items: center">${av('PR', 'av2 fx-av--lg')}<span style="display: flex; gap: 8px; align-items: center"><h2 class="fx-h2" style="font-size: 15px">Paula Ribeiro</h2>${tone('p-sched', 'Primary')}</span></div>${b('fx-btn--danger fx-btn--sm', 'Remove', 'trash')}</div><div class="fx-secb"><div class="fx-grid">${inp('Name', 'Paula Ribeiro', { c: 'c6', req: true })}${inp('Role or department', 'Maintenance manager', { c: 'c6' })}${inp('Email', 'paula.ribeiro@santaclara', { c: 'c6', state: 'error', icon: 'mail' })}${inp('Phone', '', { c: 'c3', ph: '(00) 0000-0000' })}${inp('Mobile', '(11) 98123-4501', { c: 'c3', mono: true })}${inp('Notes', '', { c: 'c12', ta: true, ph: 'Best time to call, who replaces her…' })}</div></div></section>`;
  const body = stack(contactEdit + dashTile('Add contact'), 1128) + saveBar('<b style="color: #B42318">Email is not valid</b> · the toast says the same and focus goes to the field');
  editPage('FsmCustomerEditContacts.dc.html', 'Customer — edit · Contacts', 2, body, 1000);
}

// ================================================================ FSM-09 Equipment — Overview / Details / Service history
const eqNav = () => navExpanded({ active: 'equipment', open: ['records'] });
const eqHead = (sel) => recordHead({
  tile: `<span class="fx-tile fx-tile--lg fx-tile--slate">${I('wrench', 22)}</span>`,
  over: 'Equipment · <span class="fx-id" style="font-size: 11.5px; letter-spacing: 0">HSC-CH01</span> · HVAC',
  title: 'Chiller 01',
  chips: `${tone('p-active', 'Active')}${tone('p-crit', 'High criticality')}<span class="fx-chip">${I('contact', 13)}Hospital Santa Clara Ltda. · Main building</span>`,
  actions: `${b('fx-btn--edit', 'Edit', 'pencil')}${b('fx-btn--create', 'New work order', 'plus')}`,
  facts: [['Model', 'Carrier 30XA-252', ''], ['Serial', '<span class="fx-id" style="font-size: 14px; color: #111827">SN-73810</span>', ''], ['Installed', 'Jan 1, 2021', '4 years 10 months'], ['Warranty', 'Expired', 'ended Jan 1, 2025'], ['Open work orders', '1', '#1017 · due today']],
}) + `<div style="padding: 0 10px">${fillTabs([['Overview', 'gauge'], ['Details', 'idCard'], ['Service history', 'history', 2]], sel)}</div></section>`;
const eqPage = (file, title, sel, body, h) => {
  const inner = `${crumbs(['Oliveira FSM', 'Records', 'Equipment', 'Chiller 01'])}${eqHead(sel)}${body}`;
  B({ file, title, w: 1440, h, body: page(eqNav(), inner, h) });
};
{
  const ring = (pct, color) => {
    const r = 46, c = 2 * Math.PI * r;
    return `<svg width="120" height="120" viewBox="0 0 120 120" role="img" aria-label="${Math.round(pct * 100)}% of the interval used"><circle cx="60" cy="60" r="${r}" fill="none" stroke="#EEF0F3" stroke-width="10"></circle><circle cx="60" cy="60" r="${r}" fill="none" stroke="${color}" stroke-width="10" stroke-linecap="round" stroke-dasharray="${c * pct} ${c}" transform="rotate(-90 60 60)"></circle><text x="60" y="58" text-anchor="middle" font-size="22" font-weight="600" fill="#111827" font-family="Archivo, sans-serif">9 d</text><text x="60" y="76" text-anchor="middle" font-size="11.5" fill="#5B6474" font-family="Archivo, sans-serif">to next</text></svg>`;
  };
  const prev = card('Preventive maintenance', 'Every 30 days · new fields: interval and criticality', `<div style="display: flex; gap: 28px; align-items: center">${ring(0.7, '#2A78D6')}<div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; flex-grow: 1"><div class="fx-hl"><span class="fx-small">Last preventive</span><span style="font-weight: 600">Oct 25, 2026</span><a href="#" class="fx-small" style="color: #A4502B">#1001 · Rafael Souza</a></div><div class="fx-hl"><span class="fx-small">Next due</span><span style="font-weight: 600">Nov 24, 2026</span><span class="fx-small">in 9 days</span></div><div class="fx-hl"><span class="fx-small">Already scheduled</span><span style="font-weight: 600">#1017 · Nov 14</span>${pill('SCHEDULED')}</div></div></div>`);
  const hist = card('Recent service', 'Most recent first', `<div style="display: flex; flex-direction: column">${[['#1017', 'Monthly preventive maintenance', 'Scheduled for Nov 14, 14:00 · Rafael Souza', 'SCHEDULED', ''], ['#1001', 'Monthly preventive maintenance', 'Completed Oct 25 · Rafael Souza', 'COMPLETED', 'Cleaned the coils, replaced 4 filters, checked pressures. · 3 H visit + 4 × Air filter G4']].map(([id, t, s, st2, res], i, arr) => `<div style="display: grid; grid-template-columns: 28px minmax(0, 1fr) auto; gap: 14px; position: relative; padding-bottom: ${i === arr.length - 1 ? 0 : 18}px"><span style="width: 12px; height: 12px; border-radius: 50%; background: ${SC[st2]}; box-shadow: 0 0 0 4px #FFFFFF, 0 0 0 5px #E3E6EB; margin: 5px 0 0 8px; position: relative; z-index: 1"></span>${i < arr.length - 1 ? '<span style="position: absolute; left: 13px; top: 18px; bottom: 0; width: 2px; background: #EEF0F3"></span>' : ''}<div style="display: flex; flex-direction: column; gap: 3px; min-width: 0"><span style="font-weight: 600">${woT(id, t)}</span><span class="fx-small">${s}</span>${res ? `<span style="font-size: 13.5px; color: #384152; margin-top: 4px">${res}</span>` : ''}</div>${pill(st2)}</div>`).join('')}</div>`, { action: linkA('Service history') });
  const warranty = card('Lifecycle', '', `<div style="display: flex; justify-content: space-between" class="fx-small"><span>Installed Jan 2021</span><span>Warranty ended Jan 2025</span></div><div class="fx-meter" style="margin-top: 8px; height: 8px"><span style="width: 100%; background: #C3C8D0"></span></div><div class="fx-hl" style="margin-top: 14px; flex-direction: row; gap: 10px; align-items: center">${I('lock', 16, 'color: #5B6474')}<span class="fx-small" style="color: #384152">Out of warranty — parts and labour are billable.</span></div>`);
  const loc = card('Where it is', '', `<div style="display: flex; gap: 12px"><span class="fx-tile fx-tile--slate">${I('pin', 16)}</span><div style="display: flex; flex-direction: column; min-width: 0"><span style="font-weight: 600">Main building</span><span class="fx-small">Rua Vergueiro, 2300 · Vila Mariana · São Paulo/SP</span><span class="fx-small">Location on site: —</span></div></div>`, { action: linkA('Customer') });
  eqPage('FsmEquipmentRecord.dc.html', 'Equipment — Overview tab', 0, twoCol(prev + hist, loc + warranty, 360), 1200);
}
{
  const body = stack(`${sec('contact', 'Customer and site', 'Whose it is and where it is installed.', `${ro('Customer', '<a href="#" style="color: #A4502B; font-weight: 600; text-decoration: none">Hospital Santa Clara Ltda.</a>', { c: 'c6', req: true })}${ro('Service site', 'Main building — Rua Vergueiro, 2300', { c: 'c6' })}${ro('Location on site', '', { c: 'c12', help: true })}`)}
${sec('idCard', 'Identification', 'How the team recognises it. The tag is unique in the company.', `${ro('Name', 'Chiller 01', { c: 'c6', req: true })}${ro('Tag', 'HSC-CH01', { c: 'c3', mono: true })}${ro('Category', 'HVAC', { c: 'c3' })}${ro('Manufacturer', 'Carrier', { c: 'c4' })}${ro('Model', '30XA-252', { c: 'c4' })}${ro('Serial number', 'SN-73810', { c: 'c4', mono: true })}`)}
${sec('calendar', 'Lifecycle', 'Installation and warranty. The warranty can’t end before the installation.', `${ro('Installed', 'Jan 1, 2021', { c: 'c4' })}${ro('Warranty until', 'Jan 1, 2025 · expired', { c: 'c4' })}${ro('Status', tone('p-active', 'Active'), { c: 'c4', req: true })}`)}
${sec('gauge', 'Maintenance', 'How critical it is and how often it gets preventive maintenance.', `${ro('Criticality', tone('p-crit', 'High'), { c: 'c4', help: true })}${ro('Preventive every', '30 days', { c: 'c4', help: true })}${ro('Next preventive (calculated)', 'Nov 24, 2026', { c: 'c4' })}`, { isNew: true })}
${sec('file', 'Notes', 'Anything the next technician should know.', `${ro('Notes', '', { c: 'c12' })}`, { opt: true })}`, 1128);
  eqPage('FsmEquipmentDetails.dc.html', 'Equipment — Details tab', 1, body, 1500);
}
{
  const cols = 'grid-template-columns: minmax(0, 2fr) 124px 168px 130px minmax(0, 1.6fr) 110px';
  const table = tbl(cols, ['Work order', 'Status', 'Technician', 'Date', 'Outcome', 'Items'], [
    [cell2(woT('#1017', 'Monthly preventive maintenance'), 'Preventive maintenance · SP-01'), `<span>${pill('SCHEDULED')}</span>`, who('RS'), `<span style="font-size: 13px">Nov 14 · 14:00</span>`, `<span class="fx-small">Due today 18:00</span>`, `<span class="fx-num" style="color: #8A92A0">—</span>`],
    [cell2(woT('#1001', 'Monthly preventive maintenance'), 'Preventive maintenance · SP-01'), `<span>${pill('COMPLETED')}</span>`, who('RS'), `<span style="font-size: 13px">Oct 25 · done</span>`, `<span style="font-size: 13px; color: #384152" class="fx-ell">Cleaned the coils, replaced 4 filters, checked pressures.</span>`, `<span class="fx-num" style="font-weight: 600">2 items</span>`],
  ]);
  const stats = `<div style="display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px">${[['Work orders', '2', 'since Oct 2026'], ['Completed', '1', '1 preventive · 0 corrective'], ['Open', '1', '#1017'], ['Last completed', 'Oct 25', '#1001']].map(([l, v, s]) => `<div class="fx-card fx-stat" style="padding: 14px 16px"><span class="fx-small">${l}</span><span style="font-size: 22px; font-weight: 600" class="fx-num">${v}</span><span class="fx-small">${s}</span></div>`).join('')}</div>`;
  const body = `${stats}<section class="fx-card" style="display: flex; flex-direction: column; overflow: hidden"><div class="fx-cardh"><div style="display: flex; flex-direction: column; gap: 2px"><h2 class="fx-h2" style="font-size: 15px">Service history</h2><span class="fx-small">Every work order that named this equipment · newest first</span></div>${seg([['All', 2], ['Preventive', 2], ['Corrective', 0]], 0)}</div>${table.replace('style="box-shadow: none"', 'style="box-shadow: none; border-radius: 0; border-left: none; border-right: none; border-bottom: none"')}</section>`;
  eqPage('FsmEquipmentHistory.dc.html', 'Equipment — Service history tab', 2, body, 1000);
}

// ================================================================ FSM-10 Work order type (approved + two operational fields)
{
  const h = 1120;
  const nav = navExpanded({ active: 'wo-types', open: ['settings'] });
  const sw = (on, label, desc) => `<div class="fx-f c12" style="flex-direction: row; align-items: flex-start; gap: 12px"><span class="fx-switch" role="switch" aria-checked="${on}" aria-label="${label}" style="${on ? '' : 'background: #CDD2DA'}; margin-top: 2px"></span><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 500">${label} <span class="fx-new">New</span></span><span class="fx-small">${desc}</span></span></div>`;
  const inner = `${crumbs(['Oliveira FSM', 'Settings', 'Work order types', 'Corrective maintenance'])}
<div style="display: flex; align-items: flex-end; justify-content: space-between; max-width: 1040px"><div style="display: flex; flex-direction: column; gap: 4px"><span class="fx-over">Work order type</span><h1 class="fx-h1">Corrective maintenance</h1></div>${tone('p-active', 'Active')}</div>
<div style="display: grid; grid-template-columns: minmax(0, 680px) 340px; gap: 20px; align-items: start">
<div style="display: flex; flex-direction: column; gap: 16px">
${sec('tags', 'Type', 'How the type appears in lists and on the work order.', `${inp('Name', 'Corrective maintenance', { c: 'c12', req: true })}${inp('Description', 'Something stopped working or is about to. Diagnose, fix and report what was done.', { c: 'c12', ta: true })}`)}
${sec('sparkles', 'Defaults for new work orders', 'Suggested when someone picks this type; they can still change them.', `${prioPick('HIGH', 'c12')}${inp('Estimated time on site', '3 h', { c: 'c6', icon: 'clock' })}${inp('Due within (SLA)', '24 h after the visit', { c: 'c6', icon: 'hourglass', help: true })}`, { isNew: true })}
${sec('settings', 'Rules', 'How the type behaves in the operation.', `${sw(true, 'Requires equipment', 'A work order of this type can’t be created without choosing the equipment.')}${sw(false, 'Counts as preventive maintenance', 'Completing one resets the equipment’s preventive interval (last / next preventive).')}`)}
<div class="fx-sticky"><span class="fx-small">Used by 12 work orders · can’t be deleted, only deactivated</span><div style="display: flex; gap: 8px">${b('fx-btn--ghost', 'Cancel')}${b('fx-btn--confirm', 'Save changes', 'check')}</div></div>
</div>
<aside class="fx-card" style="padding: 20px; display: flex; flex-direction: column; gap: 12px"><span class="fx-cap">Why these fields</span><ul class="fx-spec"><li><b>Defaults</b> fill priority, duration and due date in step 2–3 of a new work order.</li><li><b>Requires equipment</b> — corrective and preventive work is always on a machine; a technical visit may not be.</li><li><b>Counts as preventive</b> is what lets the equipment page show the last and next preventive without guessing from the type’s name.</li></ul><div class="fx-info">${I('info', 16, 'margin-top: 1px')}<span>Narrow form: records with few fields use a 680 px column.</span></div></aside>
</div>`;
  B({ file: 'FsmSimpleRecord.dc.html', title: 'Work order type — edit (narrow form)', w: 1440, h, body: page(nav, inner, h) });
}

// ================================================================ Mobile
const mBar = `<header class="olv-dark" style="height: 56px; flex-shrink: 0; background: #12151B; display: flex; align-items: center; gap: 8px; padding: 0 8px"><button type="button" class="olv-btn olv-btn--shell olv-btn--icon" aria-label="Open menu" style="width: 44px; height: 44px; background: transparent; border-color: transparent">${I('menu', 20)}</button>${HEADER.match(/<svg[\s\S]*?<\/svg>/)[0]}<button type="button" class="olv-btn olv-btn--shell olv-btn--sm" style="color: #E39A70; height: 32px">FSM</button><span style="flex-grow: 1"></span><button type="button" class="olv-btn olv-btn--shell olv-btn--icon" aria-label="Search" style="width: 44px; height: 44px; background: transparent; border-color: transparent">${I('search', 20)}</button><span style="width: 32px; height: 32px; border-radius: 50%; background: #C8AE72; display: flex; align-items: center; justify-content: center; color: #16223A; margin-right: 6px">${I('user', 16)}</span></header>`;
{
  const h = 1000;
  const mc = (id, s, t, c, when, p, extra = '') => `<a href="#" class="fx-mcard"><div style="display: flex; align-items: center; justify-content: space-between"><span class="fx-id">${id}</span>${pill(s)}</div><span style="font-size: 15.5px; font-weight: 600; line-height: 21px">${t}</span><span class="fx-small">${c}</span><div style="display: flex; align-items: center; justify-content: space-between; font-size: 13px; color: #384152"><span style="display: flex; align-items: center; gap: 6px">${I('clock', 14, 'color: #5B6474')}${when}</span>${prio(p)}</div>${extra}</a>`;
  const body = `<div class="fx" style="width: 390px; height: ${h}px; display: flex; flex-direction: column; overflow: hidden; background: #F2F4F7">${mBar}<div style="padding: 16px; display: flex; flex-direction: column; gap: 14px">
<div style="display: flex; flex-direction: column; gap: 2px"><span class="fx-over">Sunday, Nov 15</span><h1 class="fx-h1" style="font-size: 24px">My work</h1></div>
<div class="fx-seg" style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr))"><button type="button" aria-pressed="true" style="justify-content: center; height: 36px">Today<span class="fx-count">2</span></button><button type="button" aria-pressed="false" style="justify-content: center; height: 36px">Upcoming<span class="fx-count">3</span></button><button type="button" aria-pressed="false" style="justify-content: center; height: 36px">Done</button></div>
<section style="background: #111827; border-radius: 14px; padding: 16px; display: flex; flex-direction: column; gap: 10px; color: #FFFFFF"><div style="display: flex; align-items: center; justify-content: space-between"><span style="font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: #E39A70">Now · in progress</span><span class="fx-id" style="color: #A7AEB9">#1014</span></div><span style="font-size: 17px; font-weight: 600; line-height: 23px">VRF system quarterly maintenance</span><span style="font-size: 13px; color: #C9CCD3">Hotel Vista Verde Ltda. · Campinas</span><div class="fx-meter" style="background: rgba(255,255,255,.14)"><span style="width: 86%; background: #EDA100"></span></div><div style="display: flex; justify-content: space-between; font-size: 12.5px; color: #C9CCD3"><span>Since Nov 14, 09:20</span><span style="color: #FDD27A; font-weight: 600">Due 18:00 · 8 h</span></div><button type="button" class="fx-btn fx-btn--confirm fx-btn--lg" style="width: 100%">${I('arrowRight', 18)}<span>Continue</span></button></section>
<span class="fx-cap">Next today</span>
${mc('#1019', 'SCHEDULED', 'Elevator quarterly inspection', 'Edifício Comercial Faria Lima · Elevator B', 'Today 10:00 · 2 h', 'NORMAL', `<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px"><span class="fx-btn" style="height: 44px">${I('map', 16)}<span>Directions</span></span><span class="fx-btn" style="height: 44px">${I('play', 16)}<span>Start</span></span></div>`)}
<span class="fx-cap">Waiting</span>
${mc('#1016', 'ON_HOLD', 'Rooftop unit tripping the breaker', 'Escola Aprender Mais Ltda. · Campinas', 'Due Nov 16, 18:00', 'HIGH')}
</div></div>`;
  B({ file: 'FsmMobileMyWorkOrders.dc.html', title: 'My work — phone', w: 390, h, body });
}
{
  const h = 1280;
  const body = `<div class="fx" style="width: 390px; height: ${h}px; display: flex; flex-direction: column; overflow: hidden; background: #F2F4F7">${mBar}<div style="padding: 16px; display: flex; flex-direction: column; gap: 14px">
<a href="#" style="display: inline-flex; align-items: center; gap: 6px; color: #384152; font-size: 13.5px; text-decoration: none; height: 32px">${I('arrowLeft', 16)}My work</a>
<section class="fx-card" style="padding: 16px; display: flex; flex-direction: column; gap: 10px"><span class="fx-over"><span class="fx-id" style="font-size: 11.5px; letter-spacing: 0">#1014</span> · Preventive</span><h1 class="fx-h1" style="font-size: 20px; line-height: 26px">VRF system quarterly maintenance</h1><div style="display: flex; gap: 10px; align-items: center">${pill('IN_PROGRESS')}${prio('NORMAL')}</div><div style="display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 4px" aria-label="Step 3 of 4">${['#1BAF7A', '#1BAF7A', '#A4502B', '#E3E6EB'].map((c) => `<span style="height: 4px; border-radius: 999px; background: ${c}"></span>`).join('')}</div><span class="fx-small">In progress since Nov 14, 09:20 · due today 18:00</span></section>
<div style="display: flex; flex-direction: column; gap: 8px"><button type="button" class="fx-btn fx-btn--confirm fx-btn--lg" style="width: 100%">${I('checkCircle', 18)}<span>Complete</span></button><div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px"><button type="button" class="fx-btn fx-btn--lg">${I('pause', 18)}<span>Hold</span></button><button type="button" class="fx-btn fx-btn--lg">${I('message', 18)}<span>Note</span></button></div></div>
<div class="fx-callout" style="font-size: 13px">${I('info', 16, 'color: #A4502B; margin-top: 2px')}<span><b>Service instructions</b>[Example] Report to the maintenance desk first; the roof only with the hotel’s technician.</span></div>
<section class="fx-card" style="padding: 16px; display: flex; flex-direction: column; gap: 12px"><div style="display: flex; gap: 12px"><span class="fx-tile fx-tile--slate">${I('pin', 16)}</span><div style="display: flex; flex-direction: column"><span style="font-weight: 600">Hotel Vista Verde Ltda.</span><span class="fx-small">Av. Dr. Moraes Salles, 1500 · Centro · Campinas</span></div></div><div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px"><a href="#" class="fx-btn fx-btn--lg">${I('phone', 17)}<span>Call</span></a><a href="#" class="fx-btn fx-btn--lg">${I('map', 17)}<span>Directions</span></a></div></section>
<section class="fx-card" style="padding: 16px; display: flex; gap: 12px; align-items: center"><span class="fx-tile fx-tile--slate">${I('wrench', 16)}</span><div style="display: flex; flex-direction: column; flex-grow: 1"><span style="font-weight: 600">VRF system</span><span class="fx-id">HVV-VRF1 · LG Multi V 5</span></div>${I('chevRight', 18, 'color: #A7AEB9')}</section>
<div class="fx-seg" style="display: grid; grid-template-columns: 1fr 1fr"><button type="button" aria-pressed="true" style="justify-content: center; height: 36px">Execution<span class="fx-count">1</span></button><button type="button" aria-pressed="false" style="justify-content: center; height: 36px">History<span class="fx-count">5</span></button></div>
<section class="fx-card" style="padding: 16px; display: flex; flex-direction: column; gap: 12px"><div style="display: flex; justify-content: space-between; gap: 12px"><span style="display: flex; flex-direction: column"><span style="font-weight: 600">Preventive maintenance visit</span><span class="fx-small">Service · 2 H × R$ 180,00</span></span><span class="fx-num" style="font-weight: 600">R$ 360,00</span></div><button type="button" class="fx-btn fx-btn--lg" style="width: 100%">${I('plus', 18)}<span>Add material or service</span></button></section>
</div></div>`;
  B({ file: 'FsmMobileWorkOrder.dc.html', title: 'Work order — phone', w: 390, h, body });
}

fs.writeFileSync(`${SCRATCH}/gen/made3.json`, JSON.stringify(made, null, 2));
console.log(made.map((m) => `${m.file} ${m.w}x${m.h}`).join('\n'));
