// Render FSM boards: measure content and optionally capture PNGs.
// usage: node render.cjs <outDir|-> <board1.dc.html> [board2 …]   (no boards = every Fsm*.dc.html)
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('C:/projetos/qa-portfolio-project/node_modules/playwright');

const ROOT = path.resolve(__dirname, '../canvas/project');
const outDir = process.argv[2] && process.argv[2] !== '-' ? path.resolve(process.argv[2]) : null;
let boards = process.argv.slice(3);
if (!boards.length) boards = fs.readdirSync(ROOT).filter((f) => /^Fsm.*\.dc\.html$/.test(f));
const canvas = JSON.parse(fs.readFileSync(path.join(ROOT, 'canvas.json'), 'utf8'));

const server = http.createServer((req, res) => {
  const p = path.join(ROOT, decodeURIComponent(req.url.split('?')[0]));
  if (!p.startsWith(ROOT) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': p.endsWith('.html') ? 'text/html; charset=utf-8' : 'application/octet-stream' });
  fs.createReadStream(p).pipe(res);
});

server.listen(0, async () => {
  const port = server.address().port;
  const browser = await chromium.launch();
  if (outDir) fs.mkdirSync(outDir, { recursive: true });
  for (const f of boards) {
    const html = fs.readFileSync(path.join(ROOT, f), 'utf8');
    const m = html.match(/style="width: (\d+)px; height: (\d+)px; position: relative; overflow: hidden/);
    const w = +m[1], h = +m[2];
    const page = await browser.newPage({ viewport: { width: w, height: h } });
    await page.goto(`http://127.0.0.1:${port}/${f}`, { waitUntil: 'load' });
    await page.waitForTimeout(300);
    const r = await page.evaluate(() => {
      const root = document.querySelector('.olv');
      const rt = root.getBoundingClientRect();
      let bottom = 0, right = 0;
      for (const el of root.querySelectorAll('*')) {
        const b = el.getBoundingClientRect();
        if (!b.width || !b.height || b.height >= rt.height - 1) continue;
        const cs = getComputedStyle(el);
        if (cs.position === 'absolute' && el.closest('[aria-hidden="true"]')) continue;
        bottom = Math.max(bottom, b.bottom - rt.top);
        right = Math.max(right, b.right - rt.left);
      }
      return { bottom: Math.ceil(bottom), right: Math.ceil(right) };
    });
    const cv = canvas.boards[f];
    console.log(`${f.padEnd(34)} frame ${w}x${h} canvas ${cv ? cv.w + 'x' + cv.h : '—'} content-bottom ${r.bottom} right ${r.right}${r.bottom > h ? '  OVERFLOW' : ''}`);
    if (outDir) await page.screenshot({ path: path.join(outDir, f.replace('.dc.html', '.png')) });
    await page.close();
  }
  await browser.close();
  server.close();
});
