# Board generator (reference only)

Node scripts that produced the FSM boards of the Claude Design canvas (rounds 3 and 4).
`boards3.mjs` writes every FSM-01…FSM-10 / M06–M08 board, `handoff4.mjs` writes FSM-00,
`render.cjs` measures and captures them. `lib.mjs` reads the global bar and base CSS from the
canvas's `ErpPeople.dc.html` and its paths point at a session scratchpad — adjust `SCRATCH` before
running. Board heights were fitted after generation (see `canvas-source/canvas.json`).

Not part of the application; nothing in apps/ imports it.
