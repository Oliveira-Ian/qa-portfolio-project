// FSM-00 · Handoff board for the FSM Design System V2 (round 4 — consolidation).
import fs from 'node:fs';
import { I, board } from './lib.mjs';

const src = fs.readFileSync(new URL('./boards3.mjs', import.meta.url), 'utf8');
const CSS = src.slice(src.indexOf('const CSS = `') + 13, src.indexOf('`;', src.indexOf('const CSS = `')));

const card = (title, sub, inner, style = '') =>
  `<section class="fx-card" style="padding: 22px 24px; display: flex; flex-direction: column; gap: 16px; ${style}"><div style="display: flex; flex-direction: column; gap: 4px"><h2 class="fx-h2">${title}</h2>${sub ? `<p class="fx-sub">${sub}</p>` : ''}</div>${inner}</section>`;
const tag = (t, kind) => {
  const k = { v1: 'background: #F1F3F6; color: #384152', v2: 'background: #FBF1EB; color: #8A4221', same: 'background: #E5F5EE; color: #0F6B4A', pend: 'background: #FDF3DC; color: #6E4A00' }[kind];
  return `<span style="display: inline-flex; align-items: center; height: 22px; padding: 0 8px; border-radius: 999px; font-size: 12px; font-weight: 600; ${k}">${t}</span>`;
};
const grid = (cols, head, rows) =>
  `<div role="table" class="fx-table" style="box-shadow: none"><div role="row" class="fx-tr fx-thead" style="grid-template-columns: ${cols}">${head.map((h) => `<span class="fx-th">${h}</span>`).join('')}</div>${rows
    .map((r) => `<div role="row" class="fx-tr" style="grid-template-columns: ${cols}; min-height: 48px; padding-top: 8px; padding-bottom: 8px; align-items: start; font-size: 13.5px">${r.map((c) => `<span style="min-width: 0; line-height: 20px">${c}</span>`).join('')}</div>`)
    .join('')}</div>`;

const SEP = [
  ['Design system', `${tag('Foundation V1', 'v1')}`, `${tag('Foundation V1', 'v1')}`, `${tag('FSM V2', 'v2')} on top of the Foundation`],
  ['Global bar, account menu, search, Toast, Alert', 'V1', 'V1', `${tag('Shared · V1', 'same')} identical in every product`],
  ['Sidebar', 'F01 · gold accent', 'F01 · olive accent', `${tag('Shared · F01', 'same')} 248 px group cards + rail · terracotta accent`],
  ['Accent', 'Navy #1E2C47 · gold', 'Olive #4F6B3A', 'Terracotta #A4502B — same hue; selection & focus only'],
  ['Ground · ink · borders', 'Beige #F4F2ED · warm greys', 'Beige #F4F2ED · warm greys', 'Slate #F2F4F7 · #111827 · #E3E6EB'],
  ['Confirm button', 'Accent fill', 'Create outline green', 'Mint #44C38A + dark text #053D27 (5.3:1)'],
  ['Status', 'Mono uppercase badge', 'Mono uppercase badge', 'Pill with dot — one hue per work-order status'],
  ['Forms', 'One page, stacked sections', 'One page, stacked sections', 'Equal-width record tabs · work order create and edit in 4 steps'],
  ['View mode', 'Disabled-looking input', 'Disabled-looking input', 'Value on a hairline · full contrast · "—" when empty'],
  ['Type', 'Archivo + Mono · V1 scale', 'Archivo + Mono · V1 scale', 'Same faces · FSM scale (page 24, record 22, card 15, KPI 30)'],
];

const RULES = [
  ['shield', 'Inside /fsm, FSM V2 wins', 'over Foundation V1 for every visual and UX decision in the content area.'],
  ['building', 'Platform and ERP stay on V1', 'nothing in V2 is loaded outside [data-product="fsm"]; shared component defaults never change.'],
  ['blocks', 'V1 boards are kept as they are', 'S17, "Primary · FSM" (04), the FSM column (04b § 12) and the FSM tints (03) are superseded by V2.'],
  ['listChecks', 'Rules beat boards', 'the FSM spec, schemas and API decide behaviour; a board that disagrees adapts.'],
  ['tags', '[Example] and New', '[Example] = illustrative text; New = a field or rule the database does not have yet.'],
];

const IDX = [
  ['Foundations', [['F01', 'Navigation — collapsible groups'], ['FSM-01', 'Foundations'], ['FSM-02', 'Components & states'], ['FSM-00', 'This handoff']]],
  ['Overview · work orders', [['FSM-03', 'Operations overview · /fsm'], ['FSM-04', 'Work orders — list'], ['FSM-05a', 'Work order — Overview'], ['FSM-05b', 'Work order — Execution'], ['FSM-05c', 'Work order — History']]],
  ['Work order — steps', [['FSM-06a', 'Step 1 · Customer and site'], ['FSM-06b', 'Step 2 · Service'], ['FSM-06c', 'Step 3 · Schedule'], ['FSM-06d', 'Step 4 · Review'], ['FSM-06e', 'Edit — same steps']]],
  ['Customer', [['FSM-07a–f', 'View: Overview · Details · Sites · Contacts · Equipment · Work orders'], ['FSM-08a–c', 'Edit / create: Details · Sites · Contacts']]],
  ['Equipment · settings', [['FSM-09a–c', 'Overview · Details · Service history'], ['FSM-10', 'Work order type — narrow form + rules']]],
  ['Phone · 390 px — reference only (D4)', [['M06', 'My work orders'], ['M07', 'Work order'], ['M08', 'Menu drawer']]],
];

const FILES = [
  ['project/handoff/fsm/HANDOFF-FSM.md', 'The spec: precedence, separation, boards → routes, tokens, type, components, layouts, responsive, behaviour, a11y, new fields, glossary, pending decisions'],
  ['project/handoff/fsm/oliveira-fsm-tokens.css', 'Scoped to [data-product="fsm"]: V1 semantics redefined + --fsm-* tokens'],
  ['project/handoff/fsm/oliveira-fsm-components.css', 'Exact board CSS, de-duplicated (superseded rules removed)'],
  ['repo · docs/design/fsm/', 'Mirror of the three files + README (how it maps onto apps/web)'],
  ['repo · docs/oliveira-fsm-design-handoff.zip', 'Snapshot: files + board sources + PNG captures'],
];

const ORDER = [
  ['1', 'Tokens & base', 'Load oliveira-fsm-tokens.css; Button "confirm" variant; read-only field; pills; FSM tabs, segmented, filter chips, stepper — opt-in, defaults untouched'],
  ['2', 'Shell', 'F01 sidebar for every product — each keeps its module names, icons and accent'],
  ['3', 'Data', 'Migration for the 12 fields + 2 type rules; schemas; API; demo seed; isolation tests'],
  ['4', 'Records', 'Customer (6 view / 3 edit tabs), equipment (3 tabs), catalog, type (narrow + rules), branch'],
  ['5', 'Work orders', 'List, record (Overview · Execution · History), create and edit in 4 steps'],
  ['6', 'Dashboard', 'KPIs, charts, dispatch, needs attention; My work orders for desktop and tablet'],
  ['7', 'Close', 'Browser check at 1920 · 1366 · 1024 in EN and pt-BR; Platform and ERP unaffected; docs and canvas in sync'],
];

const body = `<div class="fx" style="padding: 56px 64px; display: flex; flex-direction: column; gap: 24px; box-sizing: border-box; background: #F2F4F7; height: 100%">
<div style="display: flex; flex-direction: column; gap: 10px; max-width: 1040px"><span class="fx-over" style="color: #A4502B">FSM-00 · Oliveira FSM design system V2 · handoff — approved Nov 15, 2026</span><h1 class="fx-h1" style="font-size: 36px; line-height: 44px">The FSM gets its own workspace — on the same Foundation</h1><p class="fx-sub" style="font-size: 16px; line-height: 25px">Everything on the rows titled “Oliveira FSM · Design System v2” is the official reference for building the Oliveira FSM frontend. The Oliveira Platform and the Oliveira ERP keep Foundation Design System V1 unchanged; the brand, the global bar and the shared components’ defaults are not touched.</p></div>
${card('Product separation', 'What each product uses. Green = shared and identical; terracotta = FSM only.', grid('210px minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1.4fr)', ['Layer', 'Oliveira Platform', 'Oliveira ERP', 'Oliveira FSM'], SEP.map((r) => [`<b style="font-weight: 600">${r[0]}</b>`, r[1], r[2], r[3]])))}
<div style="display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 20px; align-items: start">
${card('Precedence', 'How to resolve a conflict between sources.', `<div class="fx-divide" style="display: flex; flex-direction: column">${RULES.map(([ic, t, d]) => `<div style="display: flex; gap: 12px; padding: 12px 0"><span class="fx-tile">${I(ic, 16)}</span><div style="display: flex; flex-direction: column; gap: 2px; min-width: 0"><span style="font-weight: 600; font-size: 14px">${t}</span><span class="fx-small" style="font-size: 13px">${d}</span></div></div>`).join('')}</div>`)}
${card('Files', 'Read them from the canvas with the artifact tools — no export needed. The repository keeps a mirror and a snapshot.', `<div class="fx-divide" style="display: flex; flex-direction: column">${FILES.map(([f, d]) => `<div style="display: flex; flex-direction: column; gap: 3px; padding: 11px 0"><span class="fx-id" style="color: #111827">${f}</span><span class="fx-small" style="font-size: 13px">${d}</span></div>`).join('')}</div>`)}
</div>
${card('Boards', '30 boards, in reading order. Routes are today’s (ROUTES in apps/web); nothing is renamed.', `<div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px">${IDX.map(([g, items]) => `<div class="fx-hl" style="gap: 8px; padding: 14px 16px"><span class="fx-over">${g}</span>${items.map(([id, t]) => `<div style="display: grid; grid-template-columns: 84px minmax(0, 1fr); gap: 8px; font-size: 13.5px; line-height: 20px"><span class="fx-id" style="color: #8A4221">${id}</span><span>${t}</span></div>`).join('')}</div>`).join('')}</div>`)}
<div style="display: grid; grid-template-columns: minmax(0, 1.5fr) minmax(0, 1fr); gap: 20px; align-items: start">
${card('Implementation order', 'After approval, one phase at a time; each ends with lint, typecheck, build and a browser check.', `<div class="fx-divide" style="display: flex; flex-direction: column">${ORDER.map(([n, t, d]) => `<div style="display: grid; grid-template-columns: 28px 150px minmax(0, 1fr); gap: 12px; padding: 10px 0; align-items: start; font-size: 13.5px; line-height: 20px"><span class="fx-step__n" style="width: 24px; height: 24px; font-size: 12px">${n}</span><b style="font-weight: 600">${t}</b><span class="fx-small" style="font-size: 13px; line-height: 20px">${d}</span></div>`).join('')}</div>`)}
${card('Pending', 'Decisions that are not the designer’s to make alone.', `<div style="display: flex; flex-direction: column; gap: 12px">
<div class="fx-hl"><span style="display: flex; align-items: center; gap: 8px; font-weight: 600">${tag('D1', 'same')} F01 is the standard of every product</span><span class="fx-small" style="font-size: 13px; line-height: 19px">Decided. Same structure in Platform, ERP and FSM; each keeps its module names, icons and accent. Foundation docs updated in place.</span></div>
<div class="fx-hl"><span style="display: flex; align-items: center; gap: 8px; font-weight: 600">${tag('D2', 'same')} Steps for editing a work order</span><span class="fx-small" style="font-size: 13px; line-height: 19px">Approved. Replaces “single form, never steps” for the FSM work order only.</span></div>
<div class="fx-hl"><span style="display: flex; align-items: center; gap: 8px; font-weight: 600">${tag('D3', 'v1')} 1024 and 768 px</span><span class="fx-small" style="font-size: 13px; line-height: 19px">Specified in HANDOFF-FSM § 6, not drawn — verified in the browser during implementation.</span></div>
<div class="fx-hl"><span style="display: flex; align-items: center; gap: 8px; font-weight: 600">${tag('D4', 'pend')} Phones are out of the web’s scope</span><span class="fx-small" style="font-size: 13px; line-height: 19px">Decided. The web targets desktop and tablet; M06–M08 stay as reference for a future mobile app.</span></div>
</div>`)}
</div>
</div>`;

const h = Number(process.argv[2] || 2400);
console.log(board({ file: 'FsmHandoff.dc.html', title: 'FSM-00 · Handoff — Oliveira FSM Design System V2', w: 1440, h, body, css: CSS, bg: '#F2F4F7' }));
