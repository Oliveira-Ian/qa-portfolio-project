// Shared pieces for the Oliveira FSM boards (Design canvas, .dc.html).
import fs from 'node:fs';
import path from 'node:path';

export const SCRATCH = 'C:/Users/IANOLI~1/AppData/Local/Temp/claude/4b251c4bcdc5ce37/809e96e4-3a07-4e3a-ad5d-e6184b3941ae/scratchpad';
const SRC = `${SCRATCH}/artifact-files/cd32f28d-6dd6-42c4-8479-f87802e37bf1/project/ErpPeople.dc.html`;
export const OUT = `${SCRATCH}/canvas/project`;

const src = fs.readFileSync(SRC, 'utf8').split('\n');
// lines 11..210 = fonts link + <style> + the Design System's component CSS (without </style>)
const BASE_CSS = src.slice(10, 210).join('\n');
const markup = src.slice(212, 236).join('\n');
const HEADER_ERP = markup.match(/<header[\s\S]*?<\/header>/)[0];

export const HEADER = HEADER_ERP.replace('style="color: #A3BE85;', 'style="color: #E39A70;').replace(
  '<span>ERP</span>',
  '<span>FSM</span>',
);
if (HEADER === HEADER_ERP) throw new Error('header replace failed');

const FSM_CSS = `
/* ---------- Oliveira FSM proposal (Nov 2026) ---------- */
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
.mono{font-family:'JetBrains Mono',ui-monospace,monospace}
.fsm-over{font-family:'JetBrains Mono',ui-monospace,monospace;font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:#9CA0A8}
.fsm-nav{width:248px;flex-shrink:0;background:#1A1E26;border-right:1px solid #2A2F39;display:flex;flex-direction:column;gap:6px;padding:14px 10px 12px;box-sizing:border-box}
.fsm-nav a,.fsm-rail a,.fsm-flyout a{text-decoration:none}
.fsm-navitem{display:flex;align-items:center;gap:12px;height:40px;padding:0 10px 0 8px;border-radius:8px;color:#C9CCD3;font-size:14px;position:relative;border:none;background:transparent;font-family:inherit;cursor:pointer;width:100%;box-sizing:border-box;text-align:left}
.fsm-navitem:hover,.fsm-navitem.is-hover{background:#1F242D;color:#FFFFFF}
.fsm-navitem.is-active{background:#262A31;color:#FFFFFF;font-weight:500}
.fsm-navitem.is-active .fsm-gicon{background:rgba(227,154,112,.16);color:#E39A70}
.fsm-marker{position:absolute;left:0;top:10px;bottom:10px;width:3px;border-radius:0 3px 3px 0;background:#E39A70}
.fsm-group{border-radius:10px;border:1px solid transparent}
.fsm-group.is-open{background:#151920;border-color:#2A2F39;padding-bottom:6px}
.fsm-ghead{width:100%;display:flex;align-items:center;gap:12px;height:44px;padding:0 10px 0 7px;border:none;background:transparent;color:#E6E8EC;font-family:inherit;font-size:14px;font-weight:500;border-radius:9px;cursor:pointer;text-align:left;box-sizing:border-box}
.fsm-ghead:hover,.fsm-ghead.is-hover{background:#1F242D;color:#FFFFFF}
.fsm-ghead.is-focus{outline:2px solid #C8AE72;outline-offset:-2px}
.fsm-gicon{width:28px;height:28px;border-radius:7px;background:#262A31;display:flex;align-items:center;justify-content:center;color:#C9CCD3;flex-shrink:0}
.fsm-group.is-current .fsm-gicon{background:rgba(227,154,112,.16);color:#E39A70}
.fsm-chev{margin-left:auto;color:#9CA0A8;display:flex;transition:transform .16s ease}
.fsm-group.is-open .fsm-chev{transform:rotate(90deg)}
.fsm-gitems{position:relative;display:flex;flex-direction:column;gap:2px;padding:2px 6px 0 32px}
.fsm-gitems::before{content:"";position:absolute;left:21px;top:4px;bottom:4px;width:1px;background:#2F3541}
.fsm-sub{display:flex;align-items:center;gap:10px;height:34px;padding:0 10px;border-radius:6px;color:#C9CCD3;font-size:13.5px;position:relative}
.fsm-sub:hover,.fsm-sub.is-hover{background:#1F242D;color:#FFFFFF}
.fsm-sub.is-active{background:#262A31;color:#FFFFFF;font-weight:500}
.fsm-sub.is-active::before{content:"";position:absolute;left:-12px;top:8px;bottom:8px;width:3px;border-radius:3px;background:#E39A70}
.fsm-sub svg{color:#9CA0A8}
.fsm-sub.is-active svg{color:#E39A70}
.fsm-navfoot{margin-top:auto;border-top:1px solid #2A2F39;padding-top:10px}
.fsm-kbd{font-family:'JetBrains Mono',ui-monospace,monospace;font-size:10.5px;color:#9CA0A8;border:1px solid #3A404B;border-bottom-width:2px;border-radius:4px;padding:0 5px;margin-left:auto;line-height:16px}
.fsm-rail{width:64px;flex-shrink:0;background:#1A1E26;border-right:1px solid #2A2F39;display:flex;flex-direction:column;align-items:center;gap:6px;padding:14px 0 12px;position:relative;box-sizing:border-box}
.fsm-rbtn{width:44px;height:44px;border-radius:9px;display:flex;align-items:center;justify-content:center;color:#C9CCD3;background:transparent;border:none;position:relative;cursor:pointer;flex-shrink:0}
.fsm-rbtn:hover,.fsm-rbtn.is-hover{background:#262A31;color:#FFFFFF}
.fsm-rbtn.is-current{background:rgba(227,154,112,.14);color:#E39A70}
.fsm-rbtn.is-current .fsm-marker{left:-10px;top:12px;bottom:12px}
.fsm-rbtn.is-focus{box-shadow:0 0 0 2px #1A1E26,0 0 0 4px #C8AE72;background:#262A31;color:#FFFFFF}
.fsm-rdiv{width:28px;height:1px;background:#2A2F39;margin:4px 0}
.fsm-flyout{position:absolute;left:70px;width:236px;background:#1F242D;border:1px solid #2F3541;border-radius:10px;box-shadow:0 12px 32px rgba(0,0,0,.38),0 2px 6px rgba(0,0,0,.2);padding:8px;z-index:5;display:flex;flex-direction:column;gap:2px;box-sizing:border-box}
.fsm-flyout .fsm-sub{padding:0 10px}
.fsm-flyhead{display:flex;align-items:center;gap:10px;padding:6px 8px 8px;border-bottom:1px solid #2F3541;margin-bottom:4px;color:#FFFFFF;font-size:13.5px;font-weight:600}
.fsm-main{flex-grow:1;min-width:0;padding:24px 40px;display:flex;flex-direction:column;gap:16px;overflow:hidden;box-sizing:border-box}
.fsm-crumbs{list-style:none;margin:0;padding:0;display:flex;align-items:center;gap:6px;font-size:13px;color:#5A5E67}
.fsm-crumbs li{display:flex;align-items:center;gap:6px}
.fsm-crumbs a{color:#5A5E67;text-decoration:none}
.fsm-crumbs [aria-current]{color:#16181D;font-weight:500}
.fsm-h1{margin:0;font-size:28px;line-height:34px;font-weight:600;letter-spacing:-0.01em;color:#16181D}
.fsm-h2{margin:0;font-size:18px;line-height:24px;font-weight:600;color:#16181D}
.fsm-h3{margin:0;font-size:15px;line-height:22px;font-weight:600;color:#16181D}
.fsm-meta{font-family:'JetBrains Mono',ui-monospace,monospace;font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#5A5E67}
.fsm-card{background:#FFFFFF;border:1px solid #E4E0D8;border-radius:10px;box-sizing:border-box}
.fsm-muted{color:#5A5E67}
.fsm-st{display:inline-flex;align-items:center;gap:5px;height:22px;padding:0 7px 0 6px;border-radius:4px;border:1px solid;font-family:'JetBrains Mono',ui-monospace,monospace;font-size:10.5px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap;box-sizing:border-box}
.st-open{background:#EEEBE4;color:#3B3F47;border-color:#DCD7CC}
.st-scheduled{background:#E6EDF7;color:#244B80;border-color:#BCCDE6}
.st-progress{background:#F7EEDC;color:#6E470C;border-color:#E6CFA3}
.st-hold{background:#FFFFFF;color:#6E470C;border-color:#D6B47A;border-style:dashed}
.st-done{background:#E6F2EA;color:#1F5E3A;border-color:#B9DCC5}
.st-cancel{background:#F4F2ED;color:#5A5E67;border-color:#E4E0D8}
.st-active{background:#E6F2EA;color:#1F5E3A;border-color:#B9DCC5}
.st-maint{background:#F7EEDC;color:#6E470C;border-color:#E6CFA3}
.st-inactive{background:#EEEBE4;color:#3B3F47;border-color:#DCD7CC}
.fsm-dot{display:inline-flex;align-items:center;gap:7px;font-size:13px;color:#3B3F47}
.fsm-dot i{width:7px;height:7px;border-radius:50%;display:block}
.fsm-pr{display:inline-flex;align-items:center;gap:7px;font-size:13px;color:#3B3F47;white-space:nowrap}
.fsm-pr.pr-high{color:#6E470C;font-weight:500}
.fsm-pr.pr-urgent{color:#8C1D17;font-weight:600}
.fsm-late{display:inline-flex;align-items:center;gap:6px;color:#B3261E;font-weight:500}
.fsm-crit{display:inline-flex;align-items:center;gap:5px;height:22px;padding:0 8px;border-radius:999px;font-size:12px;font-weight:500;white-space:nowrap}
.crit-high{background:#F9E7E5;color:#8C1D17;box-shadow:inset 0 0 0 1px #E8B4AF}
.crit-med{background:#E6EDF7;color:#244B80;box-shadow:inset 0 0 0 1px #BCCDE6}
.crit-low{background:#EEEBE4;color:#3B3F47;box-shadow:inset 0 0 0 1px #DCD7CC}
.fsm-btn--create{background:#FFFFFF;color:#1F5E3A;border-color:#A9D3B8;box-shadow:0 1px 2px rgba(18,21,27,.06)}
.fsm-btn--create:hover{background:#F2F8F4;border-color:#7FBF97}
.fsm-btn--edit{background:#FFFFFF;color:#7A4E0C;border-color:#E2C48F;box-shadow:0 1px 2px rgba(18,21,27,.06)}
.fsm-btn--edit:hover{background:#FBF5EA;border-color:#CFA55B}
.fsm-btn--create:disabled,.fsm-btn--edit:disabled{opacity:.5;cursor:not-allowed}
.fsm-th{display:flex;align-items:center;gap:4px;font-size:12.5px;font-weight:600;color:#3B3F47;white-space:nowrap}
.fsm-th svg{color:#8B8F97}
.fsm-row{display:grid;gap:16px;padding:0 16px;align-items:center;border-bottom:1px solid #EFEDE7;font-size:14px;min-height:56px}
.fsm-cell{min-width:0;display:flex;flex-direction:column;justify-content:center;gap:2px}
.fsm-sub2{font-size:12.5px;color:#5A5E67;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fsm-ellip{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fsm-kpi{display:flex;flex-direction:column;gap:10px;padding:16px 18px;text-decoration:none;color:inherit;min-width:0}
.fsm-kpi__top{display:flex;align-items:center;justify-content:space-between;gap:8px}
.fsm-kpi__n{font-family:'JetBrains Mono',ui-monospace,monospace;font-size:30px;line-height:34px;font-weight:500;color:#16181D}
.fsm-kpi__go{display:flex;align-items:center;gap:4px;font-size:12.5px;color:#5A5E67}
.fsm-ico{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.fsm-idx{display:flex;flex-direction:column;gap:2px;width:208px;flex-shrink:0}
.fsm-idx a{display:flex;align-items:center;gap:10px;height:34px;padding:0 12px;border-radius:6px;font-size:13.5px;color:#3B3F47;text-decoration:none;position:relative}
.fsm-idx a:hover{background:rgba(18,21,27,.05)}
.fsm-idx a[aria-current]{color:#16181D;font-weight:600;background:#FFFFFF;box-shadow:inset 0 0 0 1px #E4E0D8}
.fsm-idx a[aria-current]::before{content:"";position:absolute;left:0;top:9px;bottom:9px;width:3px;border-radius:0 3px 3px 0;background:var(--acc)}
.fsm-idx .err{width:7px;height:7px;border-radius:50%;background:#B3261E;margin-left:auto}
.fsm-sec{padding:24px 28px;display:flex;flex-direction:column;gap:18px;border-bottom:1px solid #EFEDE7}
.fsm-sec:last-child{border-bottom:none}
.fsm-sechead{display:flex;align-items:center;gap:8px}
.fsm-grid2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px 24px}
.fsm-grid4{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:18px 20px}
.fsm-span2{grid-column:span 2}
.fsm-span4{grid-column:span 4}
.fsm-opt{font-family:'JetBrains Mono',ui-monospace,monospace;font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:#5A5E67;font-weight:500}
.fsm-req{color:#B3261E;margin-left:3px}
.fsm-i{display:inline-flex;color:#8B8F97;vertical-align:middle}
.fsm-ro{display:flex;align-items:center;min-height:40px;padding:0 12px;border:1px solid #E1DDD4;border-radius:6px;background:#F8F7F3;color:#16181D;font-size:14.5px;box-sizing:border-box;gap:8px}
.fsm-ro.is-empty{color:#8B8F97}
.fsm-ro.is-multi{align-items:flex-start;padding:10px 12px;line-height:1.5;min-height:64px}
.fsm-ta{width:100%;min-height:84px;padding:10px 12px;border:1px solid #9A958B;border-radius:6px;background:#FFFFFF;font-family:'Archivo',system-ui,sans-serif;font-size:14.5px;color:#16181D;resize:none;box-sizing:border-box;line-height:1.5}
.fsm-ta::placeholder{color:#8B8F97}
.fsm-seg{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.fsm-seg button{height:40px;border:1px solid #D3CEC4;border-radius:6px;background:#FFFFFF;font-family:inherit;font-size:14px;color:#3B3F47;display:flex;align-items:center;justify-content:center;gap:7px;cursor:pointer}
.fsm-seg button[aria-pressed=true]{border-color:var(--acc);background:var(--acc-50);color:var(--acc-800);font-weight:600;box-shadow:inset 0 0 0 1px var(--acc)}
.fsm-hint{display:flex;align-items:center;gap:8px;padding:10px 12px;border-radius:8px;background:#E6EDF7;color:#244B80;font-size:13px;border:1px solid #BCCDE6}
.fsm-callout{display:flex;gap:12px;padding:14px 16px;border-radius:8px;background:#E6EDF7;border:1px solid #BCCDE6;color:#16181D;font-size:14px;line-height:1.5}
.fsm-callout b{display:block;color:#244B80;font-size:12.5px;margin-bottom:2px}
.fsm-tabcount-err{font-family:'JetBrains Mono',ui-monospace,monospace;font-size:11px;font-weight:600;padding:2px 7px;border-radius:999px;background:#F9E7E5;color:#8C1D17}
.fsm-step{display:flex;align-items:center;gap:0}
.fsm-step__item{display:flex;align-items:center;gap:8px;font-size:13px;color:#5A5E67;white-space:nowrap}
.fsm-step__dot{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:1.5px solid #C9C4B9;background:#FFFFFF;color:#FFFFFF;flex-shrink:0;box-sizing:border-box}
.fsm-step__item.is-done .fsm-step__dot{background:#2D7A4F;border-color:#2D7A4F}
.fsm-step__item.is-done{color:#3B3F47}
.fsm-step__item.is-current .fsm-step__dot{border-color:var(--acc);box-shadow:0 0 0 4px var(--acc-50)}
.fsm-step__item.is-current .fsm-step__dot::after{content:"";width:8px;height:8px;border-radius:50%;background:var(--acc)}
.fsm-step__item.is-current{color:#16181D;font-weight:600}
.fsm-step__line{width:44px;height:2px;background:#E1DDD4;margin:0 10px;flex-shrink:0}
.fsm-step__line.is-done{background:#2D7A4F}
.fsm-dl{display:grid;grid-template-columns:110px minmax(0,1fr);gap:10px 12px;font-size:13.5px;margin:0}
.fsm-dl dt{color:#5A5E67}
.fsm-dl dd{margin:0;color:#16181D;min-width:0}
.fsm-avatar{width:28px;height:28px;border-radius:50%;background:#F0D8C9;color:#71361B;font-size:11.5px;font-weight:600;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.fsm-tl{display:flex;flex-direction:column;gap:0}
.fsm-tl__item{display:grid;grid-template-columns:32px minmax(0,1fr);gap:12px;position:relative;padding-bottom:16px}
.fsm-tl__item::before{content:"";position:absolute;left:15px;top:32px;bottom:0;width:1px;background:#E4E0D8}
.fsm-tl__item:last-child::before{display:none}
.fsm-tl__ico{width:32px;height:32px;border-radius:50%;border:1px solid #E4E0D8;background:#FFFFFF;display:flex;align-items:center;justify-content:center;color:#5A5E67}
.fsm-spec{font-size:13.5px;line-height:1.55;color:#3B3F47;margin:0}
.fsm-spec li{margin-bottom:4px}
.fsm-frame{border:1px dashed #C9C4B9;border-radius:12px;padding:16px;display:flex;flex-direction:column;gap:12px;background:#FBFAF7}
.fsm-cap{font-family:'JetBrains Mono',ui-monospace,monospace;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:#5A5E67}
.fsm-mcard{background:#FFFFFF;border:1px solid #E4E0D8;border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:8px;text-decoration:none;color:inherit}
`;

export const HELMET = `<helmet>\n${BASE_CSS}\n${FSM_CSS}\n</style>\n</helmet>`;

// ---------- icons (lucide, ISC) ----------
const RAW = {
  dashboard: '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
  clipboard: '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/>',
  userCheck: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/>',
  database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5V19A9 3 0 0 0 21 19V5"/><path d="M3 12A9 3 0 0 0 21 12"/>',
  contact: '<path d="M16 2v2"/><path d="M7 22v-2a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v2"/><path d="M8 2v2"/><circle cx="12" cy="11" r="3"/><rect x="3" y="4" width="18" height="18" rx="2"/>',
  wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  package: '<path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"/><path d="M12 22V12"/><path d="m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7"/><path d="m7.5 4.27 9 5.15"/>',
  settings: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  shield: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  tags: '<path d="m15 5 6.3 6.3a2.4 2.4 0 0 1 0 3.4L17 19"/><path d="M9.586 5.586A2 2 0 0 0 8.172 5H3a1 1 0 0 0-1 1v5.172a2 2 0 0 0 .586 1.414L8.29 18.29a2.426 2.426 0 0 0 3.42 0l3.58-3.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="6.5" cy="9.5" r=".5"/>',
  blocks: '<rect width="7" height="7" x="14" y="3" rx="1"/><path d="M10 21V8a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1H3"/>',
  key: '<path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z"/><circle cx="16.5" cy="7.5" r=".5"/>',
  listChecks: '<path d="m3 17 2 2 4-4"/><path d="m3 7 2 2 4-4"/><path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/>',
  chevDown: '<path d="m6 9 6 6 6-6"/>',
  chevRight: '<path d="m9 18 6-6-6-6"/>',
  panelClose: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m16 15-3-3 3-3"/>',
  panelOpen: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m14 9 3 3-3 3"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  pencil: '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
  filter: '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
  circleDashed: '<path d="M10.1 2.182a10 10 0 0 1 3.8 0"/><path d="M13.9 21.818a10 10 0 0 1-3.8 0"/><path d="M17.609 3.721a10 10 0 0 1 2.69 2.7"/><path d="M2.182 13.9a10 10 0 0 1 0-3.8"/><path d="M20.279 17.609a10 10 0 0 1-2.7 2.69"/><path d="M21.818 10.1a10 10 0 0 1 0 3.8"/><path d="M3.721 6.391a10 10 0 0 1 2.7-2.69"/><path d="M6.391 20.279a10 10 0 0 1-2.69-2.7"/>',
  calClock: '<path d="M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.5"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h5"/><path d="M17.5 17.5 16 16.3V14"/><circle cx="16" cy="16" r="6"/>',
  play: '<circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/>',
  pause: '<circle cx="12" cy="12" r="10"/><line x1="10" x2="10" y1="15" y2="9"/><line x1="14" x2="14" y1="15" y2="9"/>',
  checkCircle: '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
  xCircle: '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>',
  alarm: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2"/><path d="M5 3 2 6"/><path d="m22 6-3-3"/>',
  alert: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  pin: '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  arrowLeft: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  arrowRight: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
  sliders: '<line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
  sort: '<path d="m21 16-4 4-4-4"/><path d="M17 20V4"/><path d="m3 8 4-4 4 4"/><path d="M7 4v16"/>',
  building: '<rect width="16" height="20" x="4" y="2" rx="2" ry="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M12 6h.01"/><path d="M12 10h.01"/><path d="M12 14h.01"/><path d="M16 10h.01"/><path d="M16 14h.01"/><path d="M8 10h.01"/><path d="M8 14h.01"/>',
  user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  menu: '<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>',
  message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  calendar: '<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/>',
  arrows: '<path d="m16 3 4 4-4 4"/><path d="M20 7H4"/><path d="m8 21-4-4 4-4"/><path d="M4 17h16"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  more: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  wrenchCal: '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="m9 16 2 2 4-4"/>',
  shieldAlert: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="M12 8v4"/><path d="M12 16h.01"/>',
  hash: '<line x1="4" x2="20" y1="9" y2="9"/><line x1="4" x2="20" y1="15" y2="15"/><line x1="10" x2="8" y1="3" y2="21"/><line x1="16" x2="14" y1="3" y2="21"/>',
  timer: '<line x1="10" x2="14" y1="2" y2="2"/><line x1="12" x2="15" y1="14" y2="11"/><circle cx="12" cy="14" r="8"/>',
};

const closeTags = (s) => s.replace(/<(\w+)([^>]*?)\s*\/>/g, '<$1$2></$1>');
export const ICONS = Object.fromEntries(Object.entries(RAW).map(([k, v]) => [k, closeTags(v)]));

export function I(name, size = 18, style = '') {
  if (!ICONS[name]) throw new Error(`icon ${name}`);
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="display: block; flex-shrink: 0${style ? '; ' + style : ''}">${ICONS[name]}</svg>`;
}

// ---------- navigation catalog (FSM) ----------
export const NAV = [
  { key: 'operations', label: 'Operations', icon: 'clipboard', items: [['work-orders', 'Work orders', 'clipboard'], ['my-work-orders', 'My work orders', 'userCheck']] },
  { key: 'records', label: 'Records', icon: 'database', items: [['customers', 'Customers', 'contact'], ['equipment', 'Equipment', 'wrench'], ['products', 'Products &amp; services', 'package']] },
  { key: 'settings', label: 'Settings', icon: 'settings', items: [['wo-types', 'Work order types', 'tags'], ['branches', 'Branches', 'blocks']] },
  { key: 'access', label: 'Access', icon: 'shield', items: [['profiles', 'Access profiles', 'key'], ['users', 'Users', 'listChecks']] },
];

export function navExpanded({ active = 'work-orders', open = ['operations'], hover = null, focus = null, height = null } = {}) {
  const current = NAV.find((g) => g.items.some(([k]) => k === active))?.key;
  const overview = `<a href="#" class="fsm-navitem${active === 'overview' ? ' is-active' : ''}"${active === 'overview' ? ' aria-current="page"' : ''}>${active === 'overview' ? '<span class="fsm-marker"></span>' : ''}<span class="fsm-gicon">${I('dashboard', 16)}</span><span>Overview</span></a>`;
  const groups = NAV.map((g) => {
    const isOpen = open.includes(g.key);
    const cls = ['fsm-group', isOpen ? 'is-open' : '', g.key === current ? 'is-current' : ''].filter(Boolean).join(' ');
    const headCls = ['fsm-ghead', hover === g.key ? 'is-hover' : '', focus === g.key ? 'is-focus' : ''].filter(Boolean).join(' ');
    const items = isOpen
      ? `<div class="fsm-gitems" id="nav-${g.key}">${g.items
          .map(([k, label, icon]) => `<a href="#" class="fsm-sub${k === active ? ' is-active' : ''}${hover === k ? ' is-hover' : ''}"${k === active ? ' aria-current="page"' : ''}>${I(icon, 16)}<span class="fsm-ellip">${label}</span></a>`)
          .join('')}</div>`
      : '';
    return `<div class="${cls}"><button type="button" class="${headCls}" aria-expanded="${isOpen}" aria-controls="nav-${g.key}"><span class="fsm-gicon">${I(g.icon, 16)}</span><span>${g.label}</span><span class="fsm-chev">${I('chevRight', 16)}</span></button>${items}</div>`;
  }).join('');
  const foot = `<div class="fsm-navfoot"><button type="button" class="fsm-navitem" aria-label="Collapse menu" aria-expanded="true"><span class="fsm-gicon" style="background: transparent">${I('panelClose', 18)}</span><span>Collapse menu</span><span class="fsm-kbd">Ctrl B</span></button></div>`;
  return `<nav class="fsm-nav olv-dark" aria-label="Oliveira FSM"${height ? ` style="height: ${height}px"` : ''}>${overview}<div style="height: 4px"></div>${groups}${foot}</nav>`;
}

export function navRail({ active = 'work-orders', flyout = null, focus = null, height = null } = {}) {
  const current = NAV.find((g) => g.items.some(([k]) => k === active))?.key;
  const btn = (key, icon, label) => {
    const cls = ['fsm-rbtn', key === current || (key === 'overview' && active === 'overview') ? 'is-current' : '', focus === key ? 'is-focus' : ''].filter(Boolean).join(' ');
    const marker = key === current || (key === 'overview' && active === 'overview') ? '<span class="fsm-marker"></span>' : '';
    return `<button type="button" class="${cls}" aria-label="${label}"${key !== 'overview' ? ` aria-haspopup="menu" aria-expanded="${flyout === key}"` : ''}>${marker}${I(icon, 20)}</button>`;
  };
  let fly = '';
  if (flyout) {
    const idx = NAV.findIndex((g) => g.key === flyout);
    const g = NAV[idx];
    const top = 14 + 44 + 6 + 9 + 6 + idx * 50 - 8;
    fly = `<div class="fsm-flyout" role="menu" aria-label="${g.label}" style="top: ${top}px"><div class="fsm-flyhead"><span class="fsm-gicon" style="width: 24px; height: 24px">${I(g.icon, 14)}</span>${g.label}</div>${g.items
      .map(([k, label, icon], i) => `<a href="#" role="menuitem" class="fsm-sub${k === active ? ' is-active' : ''}${i === 0 && k !== active ? ' is-hover' : ''}" style="padding-left: 10px">${I(icon, 16)}<span>${label}</span></a>`)
      .join('')}</div>`;
  }
  return `<nav class="fsm-rail olv-dark" aria-label="Oliveira FSM"${height ? ` style="height: ${height}px"` : ''}>${btn('overview', 'dashboard', 'Overview')}<span class="fsm-rdiv"></span>${NAV.map((g) => btn(g.key, g.icon, g.label)).join('')}<div style="margin-top: auto; border-top: 1px solid #2A2F39; padding-top: 10px; width: 100%; display: flex; justify-content: center"><button type="button" class="fsm-rbtn" aria-label="Expand menu" aria-expanded="false">${I('panelOpen', 20)}</button></div>${fly}</nav>`;
}

// ---------- page pieces ----------
export function crumbs(list) {
  return `<nav aria-label="Breadcrumb"><ol class="fsm-crumbs">${list
    .map((c, i) => (i === list.length - 1 ? `<li><span aria-current="page">${c}</span></li>` : `<li><a href="#">${c}</a>${I('chevRight', 14, 'color: #8B8F97')}</li>`))
    .join('')}</ol></nav>`;
}

export const ST = {
  OPEN: ['st-open', 'circleDashed', 'Open'],
  SCHEDULED: ['st-scheduled', 'calClock', 'Scheduled'],
  IN_PROGRESS: ['st-progress', 'play', 'In progress'],
  ON_HOLD: ['st-hold', 'pause', 'On hold'],
  COMPLETED: ['st-done', 'checkCircle', 'Completed'],
  CANCELLED: ['st-cancel', 'xCircle', 'Cancelled'],
};
export const st = (s) => `<span class="fsm-st ${ST[s][0]}">${I(ST[s][1], 12)}${ST[s][2]}</span>`;

export function bars(level, color) {
  const n = { LOW: 1, NORMAL: 2, HIGH: 3, URGENT: 3 }[level];
  return `<svg width="14" height="12" viewBox="0 0 14 12" aria-hidden="true" style="display: block; flex-shrink: 0"><rect x="0" y="8" width="3" height="4" rx="1" fill="${n >= 1 ? color : '#D3CEC4'}"></rect><rect x="5" y="5" width="3" height="7" rx="1" fill="${n >= 2 ? color : '#D3CEC4'}"></rect><rect x="10" y="1" width="3" height="11" rx="1" fill="${n >= 3 ? color : '#D3CEC4'}"></rect></svg>`;
}
export function pr(level) {
  const map = { LOW: ['', '#8B8F97', 'Low'], NORMAL: ['', '#5A5E67', 'Normal'], HIGH: [' pr-high', '#9A6412', 'High'], URGENT: [' pr-urgent', '#B3261E', 'Urgent'] };
  const [cls, color, label] = map[level];
  return `<span class="fsm-pr${cls}">${level === 'URGENT' ? I('alert', 14, 'color: #B3261E') : bars(level, color)}${label}</span>`;
}

export const late = (txt) => `<span class="fsm-late">${I('alarm', 14)}<span>${txt}</span><span class="sr">Overdue</span></span>`;

export const btn = (variant, label, icon = null, extra = '') =>
  `<button type="button" class="olv-btn ${variant}"${extra}>${icon ? I(icon, 16) : ''}<span>${label}</span></button>`;

export function board({ file, title, w, h, body, product = 'fsm', bg = '#F4F2ED', css = '' }) {
  const helmet = css ? HELMET.replace('\n</style>\n</helmet>', `\n${css}\n</style>\n</helmet>`) : HELMET;
  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>${title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
${helmet}
<div class="olv" data-product="${product}" lang="en" style="width: ${w}px; height: ${h}px; position: relative; overflow: hidden; background: ${bg}; color: #16181D; font-family: 'Archivo', system-ui, sans-serif">
${body}
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":${w},"height":${h}}}'>
class Component extends DCLogic {
  renderVals() {
    return {};
  }
}
</script>
</body>
</html>
`;
  // sanity: no self-closed non-void tags, balanced div count
  const opens = (html.match(/<div\b/g) || []).length;
  const closes = (html.match(/<\/div>/g) || []).length;
  if (opens !== closes) throw new Error(`${file}: div ${opens} vs ${closes}`);
  fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, file), html);
  return { file, w, h };
}

export function shell({ nav, main, h }) {
  return `<div style="width: 100%; height: ${h}px; display: flex; flex-direction: column; position: relative; overflow: hidden">${HEADER}<div style="display: flex; flex-grow: 1; min-height: 0">${nav}<main class="fsm-main">${main}</main></div></div>`;
}
