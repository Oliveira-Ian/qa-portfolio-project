const fs = require('fs');
const lines = fs.readFileSync('boards2.mjs', 'utf8').split('\n');
const seg = (a, b) => lines.slice(a - 1, b).join('\n');
const parts = {};
let cur = null;
for (const l of fs.readFileSync('segments3.js', 'utf8').split('\n')) {
  const m = l.match(/^\/\/@@ (\w+)/);
  if (m) { cur = m[1]; parts[cur] = []; continue; }
  if (cur) parts[cur].push(l);
}
const P = (k) => parts[k].join('\n');
let head = seg(1, 270);
const extraCss = `
.fx-btn--confirm{background:#44C38A !important;border-color:#2FA56F !important;color:#053D27 !important;font-weight:600;box-shadow:0 1px 2px rgba(16,24,40,.10),inset 0 1px 0 rgba(255,255,255,.25)}
.fx-btn--confirm:hover,.fx-btn--confirm.is-hover{background:#36B27A !important;border-color:#25915F !important}
.fx-btn--confirm.is-focus{box-shadow:0 0 0 2px #FFFFFF,0 0 0 4px #1F8A5B !important}
.fx-tabs[data-fill]{display:flex}
.fx-tabs[data-fill] .fx-tab{flex:1 1 0;justify-content:center}
`;
const marker = '\n`;\n\n// ---------------------------------------------------------------- tiny helpers';
if (!head.includes(marker)) throw new Error('css marker');
head = head.replace(marker, extraCss + marker);
let found = seg(271, 312).replace(
  'The product colour marks selection and the one next step: the primary button, the selected tab, the current step, focus. Never a background for large areas, never a status.',
  'The product colour marks selection: the selected tab, the current step, focus, links. Confirming actions (Complete, Save, Continue, Create) use the mint confirm green — see FSM-02. Never a background for large areas, never a status.');
let comps = seg(313, 351);
const r = (s, a, b) => { if (!s.includes(a)) throw new Error('missing ' + a.slice(0, 60)); return s.split(a).join(b); };
comps = r(comps, "['Primary', 'fx-btn--primary', 'Complete', 'checkCircle']", "['Confirm', 'fx-btn--primary', 'Complete', 'checkCircle']");
comps = r(comps, "One accent button per region: the next step. Create green, edit amber, destructive red — as decided — now on the FSM surfaces.", "Confirm (mint green, dark text — AA 5.3:1) for Complete, Save, Continue and Create; create outline green, edit amber, destructive red. Terracotta is no longer a button colour: it marks selection and focus.");
comps = r(comps, "Clicking a done step goes back; Continue validates only the current step.", "Clicking a done step goes back; Continue validates only the current step. The same steps are used to create and to edit a work order.");
comps = r(comps, "${blk('Buttons',", "${blk('Section tabs — reusable for long records', 'Equal-width tabs across the card, used where one record is split by subject (customer edit: Details · Sites · Contacts). Not used by work orders, which keep the stepper.', fillTabs([['Customer and site', 'contact'], ['Service', 'clipboard', '!1'], ['Schedule', 'calendar'], ['References', 'file']], 1).replace(' style=\"border-bottom: none; border-top: 1px solid #E3E6EB\"', ''))}\n${blk('Buttons',");
let list = seg(406, 437);
let mobile = seg(575, 605).split('Due 18:00 · 15 h').join('Due 18:00 · 8 h');
let tail = seg(606, lines.length).replace('made2.json', 'made3.json');
let out = [head, P('HELPERS'), found, comps.replace('const h = 2080;', 'const h = 2260;'), P('DASHBOARD'), list, P('WORKORDER'), P('NEWWO'), P('CUSTOMER'), P('CUSTEDIT'), P('EQUIPMENT'), P('SIMPLE'), mobile, tail].join('\n');
out = out.split('fx-btn--primary').join('fx-btn--confirm');
// keep the original primary CSS selectors harmlessly renamed; confirm rules appended later win
fs.writeFileSync('boards3.mjs', out);
console.log('assembled', out.length);
